import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { NextFunction, Request, Response } from 'express';
import { getMediBridgeDb } from './db.ts';
import type { AdminAuthStatus } from '../src/types/healthcare.ts';

const ADMIN_CONFIG_FILE = path.resolve('/tmp', 'medibridge_admin_auth.json');
const SESSION_TTL_MS = 8 * 60 * 60 * 1000; // 8 hours
const SESSION_SECRET =
  process.env.ADMIN_SESSION_SECRET?.trim() || crypto.randomBytes(32).toString('hex');

interface StoredAdminHash {
  salt: string;
  hashHex: string;
  createdAt: string;
}

function getEnvPasscode(): string {
  return (process.env.ADMIN_PASSCODE || '').trim().replace(/^['"]|['"]$/g, '');
}

function hashPasscode(passcode: string, saltHex?: string): { salt: string; hashHex: string } {
  const salt = saltHex || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(passcode, salt, 64);
  return { salt, hashHex: derived.toString('hex') };
}

function verifyPasscodeAgainstHash(passcode: string, stored: StoredAdminHash): boolean {
  const { hashHex } = hashPasscode(passcode, stored.salt);
  const a = Buffer.from(hashHex, 'hex');
  const b = Buffer.from(stored.hashHex, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function verifyPlaintextConstantTime(input: string, expected: string): boolean {
  const a = crypto.createHash('sha256').update(input).digest();
  const b = crypto.createHash('sha256').update(expected).digest();
  return crypto.timingSafeEqual(a, b);
}

async function readClaimedAdminHash(): Promise<StoredAdminHash | null> {
  const db = await getMediBridgeDb();
  if (db) {
    try {
      const col = db.collection('admin_config');
      const doc = await col.findOne({ configKey: 'admin_passcode' });
      if (doc && typeof doc.salt === 'string' && typeof doc.hashHex === 'string') {
        return {
          salt: doc.salt,
          hashHex: doc.hashHex,
          createdAt: String(doc.createdAt || ''),
        };
      }
    } catch {
      // Fallback to preview file check
    }
  }

  try {
    if (fs.existsSync(ADMIN_CONFIG_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(ADMIN_CONFIG_FILE, 'utf8')) as Partial<StoredAdminHash>;
      if (typeof parsed.salt === 'string' && typeof parsed.hashHex === 'string') {
        return {
          salt: parsed.salt,
          hashHex: parsed.hashHex,
          createdAt: String(parsed.createdAt || ''),
        };
      }
    }
  } catch {
    // Ignore read failure
  }
  return null;
}

async function saveClaimedAdminHash(record: StoredAdminHash): Promise<boolean> {
  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('admin_config');
    const existing = await col.findOne({ configKey: 'admin_passcode' });
    if (existing) return false;
    await col.insertOne({
      configKey: 'admin_passcode',
      salt: record.salt,
      hashHex: record.hashHex,
      createdAt: record.createdAt,
    });
    return true;
  }

  if (fs.existsSync(ADMIN_CONFIG_FILE)) {
    return false;
  }
  fs.writeFileSync(ADMIN_CONFIG_FILE, JSON.stringify(record), { mode: 0o600 });
  return true;
}

function signAdminToken(): string {
  const payload = {
    role: 'admin',
    exp: Date.now() + SESSION_TTL_MS,
    nonce: crypto.randomBytes(8).toString('hex'),
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifyAdminToken(token: string): boolean {
  const parts = token.split('.');
  if (parts.length !== 2) return false;
  const [encoded, sig] = parts;
  if (!encoded || !sig) return false;

  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return false;
  }

  try {
    const decoded = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as {
      role?: string;
      exp?: number;
    };
    return decoded.role === 'admin' && typeof decoded.exp === 'number' && decoded.exp > Date.now();
  } catch {
    return false;
  }
}

export async function getAdminAuthStatus(bearerToken?: string): Promise<AdminAuthStatus> {
  const envPass = getEnvPasscode();
  const claimed = envPass ? null : await readClaimedAdminHash();
  const configuredViaEnv = Boolean(envPass);
  const claimedInStore = Boolean(claimed);
  const authenticated = bearerToken ? verifyAdminToken(bearerToken) : false;

  return {
    configuredViaEnv,
    claimedInStore,
    needsInitialSetup: !configuredViaEnv && !claimedInStore,
    authenticated,
  };
}

export async function setupInitialAdminPasscode(passcode: string): Promise<{ token: string }> {
  const envPass = getEnvPasscode();
  if (envPass) {
    throw new Error('ADMIN_PASSCODE is already configured via environment secrets.');
  }

  if (passcode.length < 8) {
    throw new Error('Admin passcode must be at least 8 characters long.');
  }

  const { salt, hashHex } = hashPasscode(passcode);
  const saved = await saveClaimedAdminHash({
    salt,
    hashHex,
    createdAt: new Date().toISOString(),
  });

  if (!saved) {
    throw new Error('Admin passcode has already been claimed. Please sign in.');
  }

  return { token: signAdminToken() };
}

export async function authenticateAdminPasscode(passcode: string): Promise<{ token: string }> {
  const envPass = getEnvPasscode();
  if (envPass) {
    if (!verifyPlaintextConstantTime(passcode, envPass)) {
      throw new Error('Invalid admin passcode.');
    }
    return { token: signAdminToken() };
  }

  const claimed = await readClaimedAdminHash();
  if (!claimed) {
    throw new Error('Admin passcode has not been set up yet.');
  }

  if (!verifyPasscodeAgainstHash(passcode, claimed)) {
    throw new Error('Invalid admin passcode.');
  }

  return { token: signAdminToken() };
}

export function extractBearerToken(req: Request): string {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return '';
  return header.slice('Bearer '.length).trim();
}

export function requireAdminAuth(req: Request, res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  if (!token || !verifyAdminToken(token)) {
    res.status(401).json({
      error: 'Admin authentication required. Please sign in to the Admin Dashboard.',
    });
    return;
  }
  next();
}
