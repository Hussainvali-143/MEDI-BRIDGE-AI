import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { NextFunction, Request, Response } from 'express';
import { getMediBridgeDb } from './db.ts';
import {
  assertSafeMutationOrigin,
  resolveAuthenticatedPatientFromRequest,
} from './patientAuth.ts';
import type { AuthenticatedUser } from '../src/types/healthcare.ts';

const USER_PREVIEW_FILE = path.resolve('/tmp', 'medibridge_users_preview.json');
const USER_SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const USER_SESSION_SECRET =
  process.env.USER_SESSION_SECRET?.trim() ||
  process.env.ADMIN_SESSION_SECRET?.trim() ||
  crypto.randomBytes(32).toString('hex');

interface StoredUserRecord {
  id: string;
  fullName: string;
  email: string;
  patientId?: string;
  salt: string;
  hashHex: string;
  createdAt: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthenticatedUser;
}

function hashPassword(password: string, saltHex?: string): { salt: string; hashHex: string } {
  const salt = saltHex || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64);
  return { salt, hashHex: derived.toString('hex') };
}

function verifyPassword(password: string, salt: string, hashHex: string): boolean {
  const derived = crypto.scryptSync(password, salt, 64);
  const a = Buffer.from(derived.toString('hex'), 'hex');
  const b = Buffer.from(hashHex, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function readPreviewUsers(): StoredUserRecord[] {
  try {
    if (fs.existsSync(USER_PREVIEW_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(USER_PREVIEW_FILE, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch {
    // Ignore corrupt preview file
  }
  return [];
}

function writePreviewUsers(users: StoredUserRecord[]): void {
  fs.writeFileSync(USER_PREVIEW_FILE, JSON.stringify(users, null, 2), { mode: 0o600 });
}

function signUserToken(user: AuthenticatedUser): string {
  const payload = {
    sub: user.id,
    email: user.email,
    fullName: user.fullName,
    patientId: user.patientId || undefined,
    role: 'user',
    exp: Date.now() + USER_SESSION_TTL_MS,
    nonce: crypto.randomBytes(8).toString('hex'),
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto
    .createHmac('sha256', USER_SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifyUserToken(token: string): AuthenticatedUser | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  if (!encoded || !sig) return null;

  const expectedSig = crypto
    .createHmac('sha256', USER_SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return null;
  }

  try {
    const decoded = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as {
      sub?: string;
      email?: string;
      fullName?: string;
      patientId?: string;
      role?: string;
      exp?: number;
    };
    if (
      decoded.role !== 'user' ||
      typeof decoded.sub !== 'string' ||
      typeof decoded.email !== 'string' ||
      typeof decoded.fullName !== 'string' ||
      typeof decoded.exp !== 'number' ||
      decoded.exp <= Date.now()
    ) {
      return null;
    }
    return {
      id: decoded.sub,
      email: decoded.email,
      fullName: decoded.fullName,
      patientId: decoded.patientId,
    };
  } catch {
    return null;
  }
}

export function extractUserBearerToken(req: Request): string {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return '';
  return header.slice('Bearer '.length).trim();
}

export async function requireUserAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const token = extractUserBearerToken(req);
  if (token) {
    const user = verifyUserToken(token);
    if (user) {
      req.user = user;
      next();
      return;
    }
  }

  try {
    if (!assertSafeMutationOrigin(req)) {
      res.status(403).json({
        error: 'Cross-site request validation failed. Please retry from the MediBridge application.',
      });
      return;
    }
    const patientSession = await resolveAuthenticatedPatientFromRequest(req);
    if (patientSession) {
      req.user = {
        id: patientSession.patient.patientId,
        fullName: patientSession.patient.fullName,
        email: patientSession.patient.email || '',
        patientId: patientSession.patient.patientId,
      };
      next();
      return;
    }
  } catch {
    // Fall through to 401
  }

  res.status(401).json({
    error: 'Please log in with your Patient ID and password to manage your saved reminders and contacts.',
  });
}

export async function registerUserAccount(input: {
  fullName: string;
  email: string;
  password: string;
  patientId?: string;
}): Promise<{ user: AuthenticatedUser; token: string }> {
  const cleanEmail = input.email.trim().toLowerCase();
  const cleanName = input.fullName.trim();
  const cleanPatientId = input.patientId?.trim() || undefined;

  if (cleanName.length < 2) {
    throw new Error('Full name must be at least 2 characters.');
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    throw new Error('Please enter a valid email address.');
  }
  if (input.password.length < 8) {
    throw new Error('Password must be at least 8 characters long.');
  }

  const { salt, hashHex } = hashPassword(input.password);
  const userId = `USR-${crypto.randomBytes(6).toString('hex').toUpperCase()}`;
  const createdAt = new Date().toISOString();

  const record: StoredUserRecord = {
    id: userId,
    fullName: cleanName,
    email: cleanEmail,
    patientId: cleanPatientId,
    salt,
    hashHex,
    createdAt,
  };

  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('users');
    const existing = await col.findOne({ email: cleanEmail });
    if (existing) {
      throw new Error('An account with this email already exists. Please sign in instead.');
    }
    await col.insertOne({ ...record });
  } else {
    const users = readPreviewUsers();
    if (users.some((u) => u.email === cleanEmail)) {
      throw new Error('An account with this email already exists. Please sign in instead.');
    }
    users.push(record);
    writePreviewUsers(users);
  }

  const user: AuthenticatedUser = {
    id: userId,
    fullName: cleanName,
    email: cleanEmail,
    patientId: cleanPatientId,
  };
  return { user, token: signUserToken(user) };
}

export async function loginUserAccount(input: {
  email: string;
  password: string;
}): Promise<{ user: AuthenticatedUser; token: string }> {
  const cleanEmail = input.email.trim().toLowerCase();
  if (!cleanEmail || !input.password) {
    throw new Error('Email and password are required.');
  }

  let matched: StoredUserRecord | null = null;
  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('users');
    const doc = await col.findOne({ email: cleanEmail });
    if (doc && typeof doc.salt === 'string' && typeof doc.hashHex === 'string') {
      matched = {
        id: String(doc.id || doc._id),
        fullName: String(doc.fullName || ''),
        email: String(doc.email || cleanEmail),
        patientId: typeof doc.patientId === 'string' ? doc.patientId : undefined,
        salt: doc.salt,
        hashHex: doc.hashHex,
        createdAt: String(doc.createdAt || ''),
      };
    }
  } else {
    const users = readPreviewUsers();
    matched = users.find((u) => u.email === cleanEmail) || null;
  }

  if (!matched || !verifyPassword(input.password, matched.salt, matched.hashHex)) {
    throw new Error('Invalid email or password.');
  }

  const user: AuthenticatedUser = {
    id: matched.id,
    fullName: matched.fullName,
    email: matched.email,
    patientId: matched.patientId,
  };
  return { user, token: signUserToken(user) };
}
