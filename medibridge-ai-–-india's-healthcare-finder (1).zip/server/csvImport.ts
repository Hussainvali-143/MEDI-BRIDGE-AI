import crypto from 'node:crypto';
import { parse } from 'csv-parse/sync';
import type { AnyBulkWriteOperation, Document } from 'mongodb';
import { getConfiguredDbName, getMediBridgeDb, getOrCreateWriteCollection } from './db.ts';
import type {
  CsvColumnMapping,
  HospitalCsvPreviewResponse,
  HospitalImportProgressEvent,
  HospitalImportTargetField,
  MappedHospitalPreviewRow,
} from '../src/types/healthcare.ts';

const BATCH_SIZE = 500;

const COLUMN_ALIASES: Record<HospitalImportTargetField, string[]> = {
  name: [
    'name',
    'hospitalname',
    'hospital',
    'facilityname',
    'healthfacilityname',
    'institutionname',
    'hname',
    'centre',
    'clinicname',
  ],
  state: ['state', 'statename', 'stateut', 'stname'],
  district: ['district', 'districtname', 'dist', 'distname'],
  city: ['city', 'cityname', 'town', 'townname', 'village', 'subdistrict', 'taluk', 'block', 'citytown', 'municipality'],
  pincode: ['pincode', 'pin', 'postalcode', 'zipcode', 'zip', 'areacode'],
  address: [
    'address',
    'fulladdress',
    'streetaddress',
    'addressline',
    'addressoriginalfirstline',
    'location',
    'completeaddress',
  ],
  phone: [
    'phone',
    'telephone',
    'phonenumber',
    'contactnumber',
    'contact',
    'contactno',
    'mobile',
    'mobilenumber',
    'landline',
    'helpline',
    'emergencynum',
    'telephoneno',
  ],
  facilityType: [
    'facilitytype',
    'type',
    'hospitaltype',
    'category',
    'hospitalcategory',
    'caretype',
    'facilitycategory',
    'discipline',
    'sector',
  ],
  latitude: ['latitude', 'lat', 'geolat', 'locationlatitude', 'y'],
  longitude: ['longitude', 'lon', 'lng', 'long', 'geolong', 'locationlongitude', 'x'],
  sourceId: [
    'sourceid',
    'ninid',
    'hfrid',
    'facilityid',
    'hospitalid',
    'srno',
    'serialno',
    'id',
    'recordid',
    'code',
    'registrationnumber',
  ],
};

function normalizeHeaderKey(header: string): string {
  return header.toLowerCase().replace(/[^a-z0-9]/g, '');
}

export function detectCsvColumnMapping(
  headers: string[],
  overrides?: Partial<Record<HospitalImportTargetField, string | null>>
): CsvColumnMapping {
  const normalizedToOriginal = new Map<string, string>();
  for (const h of headers) {
    const norm = normalizeHeaderKey(h);
    if (norm && !normalizedToOriginal.has(norm)) {
      normalizedToOriginal.set(norm, h);
    }
  }

  const mapping: CsvColumnMapping = {
    name: null,
    state: null,
    district: null,
    city: null,
    pincode: null,
    address: null,
    phone: null,
    facilityType: null,
    latitude: null,
    longitude: null,
    sourceId: null,
  };

  const fields = Object.keys(COLUMN_ALIASES) as HospitalImportTargetField[];
  for (const field of fields) {
    // 1. Check user override first if header exists
    if (overrides && field in overrides) {
      const chosen = overrides[field];
      if (!chosen) {
        mapping[field] = null;
        continue;
      }
      if (headers.includes(chosen)) {
        mapping[field] = chosen;
        continue;
      }
    }

    // 2. Exact alias match
    const aliases = COLUMN_ALIASES[field];
    let matched: string | null = null;
    for (const alias of aliases) {
      const hit = normalizedToOriginal.get(alias);
      if (hit) {
        matched = hit;
        break;
      }
    }

    // 3. Substring fallback if no exact alias hit
    if (!matched) {
      for (const h of headers) {
        const norm = normalizeHeaderKey(h);
        if (aliases.some((alias) => alias.length >= 4 && norm.includes(alias))) {
          matched = h;
          break;
        }
      }
    }

    mapping[field] = matched;
  }

  return mapping;
}

function parseCoordinate(raw: string, min: number, max: number): number | null {
  const clean = raw.trim();
  if (!clean) return null;
  const num = Number(clean);
  if (!Number.isFinite(num) || num < min || num > max) return null;
  return num;
}

function cleanCell(row: Record<string, string>, colName: string | null): string {
  if (!colName) return '';
  const val = row[colName];
  if (typeof val !== 'string') return '';
  return val.trim();
}

function normalizePincode(raw: string): string {
  const digits = raw.replace(/\D/g, '');
  if (digits.length === 6) return digits;
  return raw.trim();
}

function mapCsvRow(
  row: Record<string, string>,
  rowNumber: number,
  mapping: CsvColumnMapping
): MappedHospitalPreviewRow {
  const name = cleanCell(row, mapping.name);
  const state = cleanCell(row, mapping.state);
  const district = cleanCell(row, mapping.district);
  const city = cleanCell(row, mapping.city);
  const pincode = normalizePincode(cleanCell(row, mapping.pincode));
  const address = cleanCell(row, mapping.address);
  const phone = cleanCell(row, mapping.phone);
  const facilityType = cleanCell(row, mapping.facilityType);
  const latitude = parseCoordinate(cleanCell(row, mapping.latitude), -90, 90);
  const longitude = parseCoordinate(cleanCell(row, mapping.longitude), -180, 180);
  const rawSourceId = cleanCell(row, mapping.sourceId);
  const sourceId = rawSourceId ? rawSourceId : null;

  const valid = name.length > 0;
  return {
    rowNumber,
    sourceId,
    name,
    state,
    district,
    city,
    pincode,
    address,
    phone,
    facilityType,
    latitude,
    longitude,
    verified: false,
    valid,
    validationIssue: valid ? undefined : 'Missing hospital name',
  };
}

function buildImportFingerprint(row: MappedHospitalPreviewRow): string {
  const canonical = [
    row.name.toLowerCase(),
    row.state.toLowerCase(),
    row.district.toLowerCase(),
    row.city.toLowerCase(),
    row.pincode.toLowerCase(),
    row.address.toLowerCase(),
  ].join('|');
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

function parseCsvRecords(buffer: Buffer): { headers: string[]; records: Array<Record<string, string>> } {
  const records = parse(buffer, {
    columns: (headerRow: string[]) => headerRow.map((h) => String(h ?? '').trim()),
    skip_empty_lines: true,
    bom: true,
    trim: true,
    relax_column_count: true,
    relax_quotes: true,
  }) as Array<Record<string, string>>;

  const headers = records.length > 0 ? Object.keys(records[0]).filter(Boolean) : [];
  return { headers, records };
}

export async function previewHospitalCsv(
  buffer: Buffer,
  fileName: string,
  overrides?: Partial<Record<HospitalImportTargetField, string | null>>
): Promise<HospitalCsvPreviewResponse> {
  const { headers, records } = parseCsvRecords(buffer);
  const mapping = detectCsvColumnMapping(headers, overrides);
  const previewSlice = records.slice(0, 10);
  const previewRows = previewSlice.map((row, idx) => mapCsvRow(row, idx + 1, mapping));
  const db = await getMediBridgeDb();

  return {
    fileName,
    totalRows: records.length,
    headers,
    columnMapping: mapping,
    previewRows,
    invalidRowCountInPreview: previewRows.filter((r) => !r.valid).length,
    databaseConnected: Boolean(db),
    targetDatabase: getConfiguredDbName(),
    targetCollection: 'Hospitals',
  };
}

export async function importHospitalCsvToMongo(
  buffer: Buffer,
  fileName: string,
  overrides: Partial<Record<HospitalImportTargetField, string | null>> | undefined,
  onProgress: (evt: HospitalImportProgressEvent) => void
): Promise<HospitalImportProgressEvent> {
  const db = await getMediBridgeDb();
  if (!db) {
    throw new Error(
      'MongoDB Atlas (Medi_Bridge) is not connected. Verify MONGODB_URI and Atlas connectivity before importing.'
    );
  }

  const { headers, records } = parseCsvRecords(buffer);
  if (records.length === 0) {
    throw new Error('The uploaded CSV file contains no data rows.');
  }

  const mapping = detectCsvColumnMapping(headers, overrides);
  if (!mapping.name) {
    throw new Error(
      'Could not detect a hospital name column in the CSV. Map the "name" column before importing.'
    );
  }

  const col = await getOrCreateWriteCollection(
    db,
    ['Hospitals', 'hospitals', 'hospital', 'facilities'],
    'Hospitals'
  );

  // Ensure sparse unique indexes only if safe or rely on deterministic bulkWrite filters
  const totalRows = records.length;
  const totalBatches = Math.ceil(totalRows / BATCH_SIZE);
  let processedRows = 0;
  let insertedCount = 0;
  let skippedCount = 0;
  let failedCount = 0;
  const sampleErrors: string[] = [];

  const seenSourceIds = new Set<string>();
  const seenFingerprints = new Set<string>();
  const importedAt = new Date().toISOString();

  for (let batchIdx = 0; batchIdx < totalBatches; batchIdx++) {
    const start = batchIdx * BATCH_SIZE;
    const chunk = records.slice(start, start + BATCH_SIZE);
    const mappedChunk = chunk.map((rawRow, idx) => mapCsvRow(rawRow, start + idx + 1, mapping));

    const ops: Array<AnyBulkWriteOperation<Document>> = [];
    const batchCandidateRows: MappedHospitalPreviewRow[] = [];

    // Pre-check existing sourceIds and fingerprints in MongoDB for accurate duplicate skipping without modifying existing docs
    const chunkSourceIds = mappedChunk
      .map((r) => r.sourceId)
      .filter((id): id is string => Boolean(id));
    const chunkFingerprints = mappedChunk
      .filter((r) => r.valid && !r.sourceId)
      .map((r) => buildImportFingerprint(r));

    const existingSourceIds = new Set<string>();
    if (chunkSourceIds.length > 0) {
      const existingDocs = await col
        .find({ sourceId: { $in: chunkSourceIds } }, { projection: { sourceId: 1 } })
        .toArray();
      for (const doc of existingDocs) {
        if (typeof doc.sourceId === 'string' && doc.sourceId) {
          existingSourceIds.add(doc.sourceId);
        }
      }
    }

    const existingFingerprints = new Set<string>();
    if (chunkFingerprints.length > 0) {
      const existingDocs = await col
        .find({ importFingerprint: { $in: chunkFingerprints } }, { projection: { importFingerprint: 1 } })
        .toArray();
      for (const doc of existingDocs) {
        if (typeof doc.importFingerprint === 'string' && doc.importFingerprint) {
          existingFingerprints.add(doc.importFingerprint);
        }
      }
    }

    for (const row of mappedChunk) {
      if (!row.valid) {
        failedCount++;
        if (sampleErrors.length < 25) {
          sampleErrors.push(`Row ${row.rowNumber}: ${row.validationIssue || 'Invalid row'}`);
        }
        continue;
      }

      const fingerprint = buildImportFingerprint(row);

      if (row.sourceId) {
        if (seenSourceIds.has(row.sourceId) || existingSourceIds.has(row.sourceId)) {
          skippedCount++;
          continue;
        }
        seenSourceIds.add(row.sourceId);
      } else {
        if (seenFingerprints.has(fingerprint) || existingFingerprints.has(fingerprint)) {
          skippedCount++;
          continue;
        }
        seenFingerprints.add(fingerprint);
      }

      const documentToInsert: Document = {
        name: row.name,
        state: row.state,
        district: row.district,
        city: row.city,
        pincode: row.pincode,
        address: row.address,
        phone: row.phone,
        facilityType: row.facilityType,
        latitude: row.latitude,
        longitude: row.longitude,
        verified: false,
        verificationStatus: 'unverified',
        importFingerprint: fingerprint,
        importSourceFile: fileName,
        importedAt,
      };
      if (row.sourceId) {
        documentToInsert.sourceId = row.sourceId;
      }

      const dedupFilter = row.sourceId
        ? { sourceId: row.sourceId }
        : { importFingerprint: fingerprint };

      ops.push({
        updateOne: {
          filter: dedupFilter,
          update: { $setOnInsert: documentToInsert },
          upsert: true,
        },
      });
      batchCandidateRows.push(row);
    }

    if (ops.length > 0) {
      try {
        const result = await col.bulkWrite(ops, { ordered: false });
        const batchInserted = result.upsertedCount;
        const batchSkipped = ops.length - batchInserted;
        insertedCount += batchInserted;
        skippedCount += batchSkipped;
      } catch (err: unknown) {
        // Handle partial batch errors if bulkWrite reports writeErrors
        const bulkErr = err as {
          result?: { upsertedCount?: number; matchedCount?: number };
          writeErrors?: Array<{ index: number; errmsg?: string }>;
          message?: string;
        };
        const batchInserted = bulkErr?.result?.upsertedCount ?? 0;
        const writeErrors = Array.isArray(bulkErr?.writeErrors) ? bulkErr.writeErrors : [];
        insertedCount += batchInserted;
        failedCount += writeErrors.length > 0 ? writeErrors.length : ops.length - batchInserted;

        if (writeErrors.length > 0) {
          for (const we of writeErrors) {
            if (sampleErrors.length < 25) {
              const failedRow = batchCandidateRows[we.index];
              sampleErrors.push(
                `Row ${failedRow?.rowNumber ?? '?'}: ${we.errmsg || 'Write failed'}`
              );
            }
          }
        } else if (sampleErrors.length < 25) {
          sampleErrors.push(
            `Batch ${batchIdx + 1}: ${bulkErr?.message || 'Batch write failed'}`
          );
        }
      }
    }

    processedRows += chunk.length;
    onProgress({
      type: 'progress',
      totalRows,
      processedRows,
      insertedCount,
      skippedCount,
      failedCount,
      currentBatch: batchIdx + 1,
      totalBatches,
      sampleErrors,
    });
  }

  return {
    type: 'complete',
    totalRows,
    processedRows,
    insertedCount,
    skippedCount,
    failedCount,
    currentBatch: totalBatches,
    totalBatches,
    sampleErrors,
  };
}
