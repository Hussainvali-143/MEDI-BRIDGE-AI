import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { NextFunction, Request, Response } from 'express';
import type { Collection, Document } from 'mongodb';
import { getMediBridgeDb, getOrCreateWriteCollection } from './db.ts';
import type { PatientAccountProfile, PatientAccountStatus } from '../src/types/healthcare.ts';

export const PATIENT_SESSION_COOKIE_NAME = 'mb_patient_session';
export const PATIENT_SESSION_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours

const PATIENT_PREVIEW_FILE = path.resolve('/tmp', 'medibridge_patient_accounts_preview.json');
const PATIENT_SESSIONS_PREVIEW_FILE = path.resolve('/tmp', 'medibridge_patient_sessions_preview.json');

const SESSION_SECRET =
  process.env.PATIENT_SESSION_SECRET?.trim() ||
  process.env.USER_SESSION_SECRET?.trim() ||
  process.env.ADMIN_SESSION_SECRET?.trim() ||
  crypto.randomBytes(32).toString('hex');

const SCRYPT_N = 16384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const SCRYPT_KEYLEN = 64;

// Precomputed dummy hash for constant-time login failure parity when Patient ID is not found
const DUMMY_PASSWORD_HASH =
  'scrypt$16384$8$1$00112233445566778899aabbccddeeff$' + '00'.repeat(64);

interface StoredPatientAccount {
  patientId: string;
  fullName: string;
  dateOfBirth: string;
  age?: number;
  gender?: string;
  mobileNumber: string;
  normalizedMobile: string;
  email?: string;
  emailLower?: string;
  address?: string;
  passwordHash: string;
  registrationDate: string;
  createdAt: string;
  updatedAt: string;
  accountStatus: PatientAccountStatus;
  storageMode: 'mongodb' | 'preview';
}

interface StoredPatientSession {
  jti: string;
  patientId: string;
  createdAt: string;
  expiresAtMs: number;
  expiresAtDate: Date;
  revoked: boolean;
}

export interface PatientAuthenticatedRequest extends Request {
  patient?: PatientAccountProfile;
  patientSessionJti?: string;
}

export class HttpStatusError extends Error {
  status: number;
  retryAfterSeconds?: number;
  constructor(status: number, message: string, retryAfterSeconds?: number) {
    super(message);
    this.status = status;
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

// --- Password Hashing (Async scrypt + timingSafeEqual) ---

function deriveScrypt(password: string, saltHex: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    crypto.scrypt(
      password,
      saltHex,
      SCRYPT_KEYLEN,
      { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P },
      (err, derivedKey) => {
        if (err) reject(err);
        else resolve(derivedKey);
      }
    );
  });
}

export async function hashPatientPassword(password: string): Promise<string> {
  const saltHex = crypto.randomBytes(16).toString('hex');
  const derived = await deriveScrypt(password, saltHex);
  return `scrypt$${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${saltHex}$${derived.toString('hex')}`;
}

export async function verifyPatientPassword(
  password: string,
  storedHash: string
): Promise<boolean> {
  const parts = storedHash.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') {
    await deriveScrypt(password, '00112233445566778899aabbccddeeff');
    return false;
  }
  const [, , , , saltHex, hashHex] = parts;
  if (!saltHex || !hashHex) return false;
  try {
    const derived = await deriveScrypt(password, saltHex);
    const expected = Buffer.from(hashHex, 'hex');
    if (derived.length !== expected.length) return false;
    return crypto.timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

// --- Input Validation & Normalization ---

export function cleanText(value: unknown, maxLen: number): string {
  if (typeof value !== 'string') return '';
  return value.replace(/\s+/g, ' ').trim().slice(0, maxLen);
}

export function normalizeMobileDigits(raw: string): string {
  const digits = raw.replace(/\D/g, '');
  // Standardize Indian +91 / 0-prefixed 10-digit mobiles so 9876543210 and +91 9876543210 match
  if (digits.length === 12 && digits.startsWith('91')) {
    return digits.slice(2);
  }
  if (digits.length === 11 && digits.startsWith('0')) {
    return digits.slice(1);
  }
  return digits;
}

export function validateMobileNumber(raw: unknown): {
  mobileNumber: string;
  normalizedMobile: string;
} {
  const mobileNumber = cleanText(raw, 24);
  if (!/^[+\d\s()-]{8,20}$/.test(mobileNumber)) {
    throw new HttpStatusError(
      400,
      'Please enter a valid mobile number (10 to 15 digits, e.g., +91 9876543210).'
    );
  }
  const digitsOnly = mobileNumber.replace(/\D/g, '');
  const normalizedMobile = normalizeMobileDigits(mobileNumber);
  if (digitsOnly.length < 10 || digitsOnly.length > 15 || normalizedMobile.length < 10) {
    throw new HttpStatusError(
      400,
      'Mobile number must contain between 10 and 15 digits.'
    );
  }
  return { mobileNumber, normalizedMobile };
}

export function validateDateOfBirth(raw: unknown): { dateOfBirth: string; age: number } {
  const dob = cleanText(raw, 20);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dob)) {
    throw new HttpStatusError(400, 'Date of birth must be in YYYY-MM-DD format.');
  }
  const parsed = new Date(`${dob}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== dob) {
    throw new HttpStatusError(400, 'Please enter a valid calendar date of birth.');
  }
  const now = new Date();
  const minDate = new Date('1900-01-01T00:00:00Z');
  if (parsed > now || parsed < minDate) {
    throw new HttpStatusError(400, 'Date of birth cannot be in the future or before 1900.');
  }
  let age = now.getUTCFullYear() - parsed.getUTCFullYear();
  const monthDiff = now.getUTCMonth() - parsed.getUTCMonth();
  if (monthDiff < 0 || (monthDiff === 0 && now.getUTCDate() < parsed.getUTCDate())) {
    age--;
  }
  return { dateOfBirth: dob, age: Math.max(0, age) };
}

export function validateOptionalEmail(raw: unknown): {
  email?: string;
  emailLower?: string;
} {
  const email = cleanText(raw, 140);
  if (!email) return {};
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new HttpStatusError(400, 'Please enter a valid email address.');
  }
  return { email, emailLower: email.toLowerCase() };
}

export function validatePasswordStrength(passwordRaw: unknown, confirmRaw: unknown): string {
  if (typeof passwordRaw !== 'string' || typeof confirmRaw !== 'string') {
    throw new HttpStatusError(400, 'Password and confirm password are required.');
  }
  if (passwordRaw.length < 8 || passwordRaw.length > 128) {
    throw new HttpStatusError(400, 'Password must be between 8 and 128 characters long.');
  }
  if (passwordRaw !== confirmRaw) {
    throw new HttpStatusError(400, 'Password and Confirm Password do not match.');
  }
  return passwordRaw;
}

// --- Sanitizer (Never leaks passwordHash or internal auth fields) ---

function toSafePatientProfile(
  doc: Partial<StoredPatientAccount> & Document,
  storageMode: 'mongodb' | 'preview'
): PatientAccountProfile {
  const registrationDate = String(
    doc.registrationDate || doc.createdAt || new Date().toISOString()
  );
  const rawStatus = String(doc.accountStatus || 'active');
  const accountStatus: PatientAccountStatus = rawStatus === 'suspended' ? 'suspended' : 'active';
  return {
    patientId: String(doc.patientId || ''),
    fullName: String(doc.fullName || ''),
    dateOfBirth: String(doc.dateOfBirth || ''),
    age: typeof doc.age === 'number' && Number.isFinite(doc.age) ? doc.age : undefined,
    gender: doc.gender ? String(doc.gender) : undefined,
    mobileNumber: String(doc.mobileNumber || doc.phone || ''),
    email: doc.email ? String(doc.email) : undefined,
    address: doc.address ? String(doc.address) : undefined,
    registrationDate,
    accountStatus,
    storageMode,
  };
}

// --- Preview Fallback Stores (only when MongoDB is disconnected) ---

function readPreviewPatients(): StoredPatientAccount[] {
  try {
    if (fs.existsSync(PATIENT_PREVIEW_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(PATIENT_PREVIEW_FILE, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    }
  } catch {
    // Ignore corrupt fallback file
  }
  return [];
}

function writePreviewPatients(records: StoredPatientAccount[]): void {
  fs.writeFileSync(PATIENT_PREVIEW_FILE, JSON.stringify(records, null, 2), { mode: 0o600 });
}

function readPreviewSessions(): Record<string, StoredPatientSession> {
  try {
    if (fs.existsSync(PATIENT_SESSIONS_PREVIEW_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(PATIENT_SESSIONS_PREVIEW_FILE, 'utf8'));
      return parsed && typeof parsed === 'object' ? parsed : {};
    }
  } catch {
    // Ignore corrupt fallback file
  }
  return {};
}

function writePreviewSessions(sessions: Record<string, StoredPatientSession>): void {
  fs.writeFileSync(PATIENT_SESSIONS_PREVIEW_FILE, JSON.stringify(sessions), { mode: 0o600 });
}

// --- MongoDB Indexes & Atomic Patient ID Generation ---

let patientIndexesReady = false;

async function ensurePatientIndexes(col: Collection<Document>): Promise<void> {
  if (patientIndexesReady) return;
  await Promise.all([
    col.createIndex({ patientId: 1 }, { unique: true, sparse: true, background: true }),
    col.createIndex({ normalizedMobile: 1 }, { unique: true, sparse: true, background: true }),
    col.createIndex({ emailLower: 1 }, { unique: true, sparse: true, background: true }),
  ]);
  patientIndexesReady = true;
}

async function generateNextPatientId(): Promise<string> {
  const year = new Date().getUTCFullYear();
  const db = await getMediBridgeDb();

  if (db) {
    const counters = db.collection<{ _id: string; seq: number }>('counters');
    const counterId = `patient_id_${year}`;

    // Initialize counter safely above any existing MBP-YYYY-* records on first use
    const existingCounter = await counters.findOne({ _id: counterId });
    if (!existingCounter) {
      const patientsCol = await getOrCreateWriteCollection(
        db,
        ['patients', 'Patients', 'patient'],
        'patients'
      );
      const latest = await patientsCol
        .find({ patientId: { $regex: `^MBP-${year}-\\d+$` } })
        .sort({ patientId: -1 })
        .limit(1)
        .toArray();
      let initialMax = 0;
      if (latest[0]?.patientId) {
        const match = String(latest[0].patientId).match(/-(\d+)$/);
        if (match) initialMax = Number(match[1]) || 0;
      }
      await counters.updateOne(
        { _id: counterId },
        { $setOnInsert: { seq: initialMax } },
        { upsert: true }
      );
    }

    const updated = await counters.findOneAndUpdate(
      { _id: counterId },
      { $inc: { seq: 1 } },
      { upsert: true, returnDocument: 'after' }
    );
    const seq = updated?.seq || 1;
    return `MBP-${year}-${String(seq).padStart(6, '0')}`;
  }

  // Preview fallback atomic counter
  const records = readPreviewPatients();
  let maxSeq = 0;
  for (const r of records) {
    const m = r.patientId.match(new RegExp(`^MBP-${year}-(\\d+)$`));
    if (m) {
      const n = Number(m[1]) || 0;
      if (n > maxSeq) maxSeq = n;
    }
  }
  return `MBP-${year}-${String(maxSeq + 1).padStart(6, '0')}`;
}

// --- Rate Limiting for Patient Login ---

interface RateBucket {
  failures: number;
  windowStart: number;
  blockedUntil: number;
}

const loginRateBuckets = new Map<string, RateBucket>();
const RATE_WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILURES_PER_ID = 5;
const MAX_FAILURES_PER_IP = 15;

export function getClientIp(req: Request): string {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd.trim()) {
    return fwd.split(',')[0].trim();
  }
  return req.ip || req.socket?.remoteAddress || 'unknown';
}

function checkRateBucket(key: string, maxFailures: number): void {
  const now = Date.now();
  const bucket = loginRateBuckets.get(key);
  if (!bucket) return;

  if (bucket.blockedUntil > now) {
    const retryAfter = Math.max(1, Math.ceil((bucket.blockedUntil - now) / 1000));
    throw new HttpStatusError(
      429,
      `Too many failed login attempts. Please wait ${retryAfter} seconds before trying again.`,
      retryAfter
    );
  }
  if (now - bucket.windowStart > RATE_WINDOW_MS) {
    loginRateBuckets.delete(key);
  } else if (bucket.failures >= maxFailures) {
    bucket.blockedUntil = bucket.windowStart + RATE_WINDOW_MS;
    const retryAfter = Math.max(1, Math.ceil((bucket.blockedUntil - now) / 1000));
    throw new HttpStatusError(
      429,
      `Too many failed login attempts. Please wait ${retryAfter} seconds before trying again.`,
      retryAfter
    );
  }
}

function recordLoginFailure(key: string, maxFailures: number): void {
  const now = Date.now();
  const existing = loginRateBuckets.get(key);
  if (!existing || now - existing.windowStart > RATE_WINDOW_MS) {
    loginRateBuckets.set(key, { failures: 1, windowStart: now, blockedUntil: 0 });
    return;
  }
  existing.failures += 1;
  if (existing.failures >= maxFailures) {
    existing.blockedUntil = now + RATE_WINDOW_MS;
  }
}

function clearLoginFailures(key: string): void {
  loginRateBuckets.delete(key);
}

// --- Cookie Parsing, Signing & Revocation ---

function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookieHeader) return out;
  for (const part of cookieHeader.split(';')) {
    const eqIdx = part.indexOf('=');
    if (eqIdx === -1) continue;
    const key = part.slice(0, eqIdx).trim();
    const val = part.slice(eqIdx + 1).trim();
    if (key) {
      try {
        out[key] = decodeURIComponent(val);
      } catch {
        out[key] = val;
      }
    }
  }
  return out;
}

function signSessionPayload(patientId: string, jti: string, expiresAtMs: number): string {
  const payload = {
    sub: patientId,
    jti,
    role: 'patient',
    iat: Date.now(),
    exp: expiresAtMs,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySignedSessionCookieValue(
  rawCookie: string
): { patientId: string; jti: string; exp: number } | null {
  const parts = rawCookie.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  if (!encoded || !sig) return null;

  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return null;
  }

  try {
    const decoded = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as {
      sub?: string;
      jti?: string;
      role?: string;
      exp?: number;
    };
    if (
      decoded.role !== 'patient' ||
      typeof decoded.sub !== 'string' ||
      typeof decoded.jti !== 'string' ||
      typeof decoded.exp !== 'number' ||
      decoded.exp <= Date.now()
    ) {
      return null;
    }
    return { patientId: decoded.sub, jti: decoded.jti, exp: decoded.exp };
  } catch {
    return null;
  }
}

let sessionIndexesReady = false;

async function persistSessionRecord(record: StoredPatientSession): Promise<void> {
  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('patient_sessions');
    if (!sessionIndexesReady) {
      await Promise.all([
        col.createIndex({ jti: 1 }, { unique: true, background: true }),
        col.createIndex({ expiresAtDate: 1 }, { expireAfterSeconds: 0, background: true }),
      ]);
      sessionIndexesReady = true;
    }
    await col.insertOne({ ...record });
    return;
  }
  const map = readPreviewSessions();
  map[record.jti] = record;
  writePreviewSessions(map);
}

async function isSessionActive(jti: string, patientId: string): Promise<boolean> {
  const now = Date.now();
  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('patient_sessions');
    const doc = await col.findOne({ jti, patientId });
    if (!doc) return false;
    if (doc.revoked === true) return false;
    const expMs = Number(doc.expiresAtMs || 0);
    return expMs > now;
  }
  const map = readPreviewSessions();
  const sess = map[jti];
  return Boolean(sess && sess.patientId === patientId && !sess.revoked && sess.expiresAtMs > now);
}

async function revokeSessionRecord(jti: string): Promise<void> {
  const db = await getMediBridgeDb();
  if (db) {
    await db
      .collection('patient_sessions')
      .updateOne({ jti }, { $set: { revoked: true, revokedAt: new Date().toISOString() } });
    return;
  }
  const map = readPreviewSessions();
  if (map[jti]) {
    map[jti].revoked = true;
    writePreviewSessions(map);
  }
}

function isRequestHttps(req: Request): boolean {
  if (req.secure) return true;
  const proto = req.headers['x-forwarded-proto'];
  if (typeof proto === 'string') {
    return proto.split(',')[0].trim().toLowerCase() === 'https';
  }
  return false;
}

function buildCookieHeader(req: Request, value: string, maxAgeSeconds: number): string {
  const parts = [
    `${PATIENT_SESSION_COOKIE_NAME}=${encodeURIComponent(value)}`,
    'Path=/',
    'HttpOnly',
    `Max-Age=${maxAgeSeconds}`,
  ];
  if (isRequestHttps(req)) {
    parts.push('Secure', 'SameSite=None', 'Partitioned');
  } else {
    parts.push('SameSite=Lax');
  }
  return parts.join('; ');
}

export async function createPatientSessionCookie(
  req: Request,
  res: Response,
  patientId: string,
  ttlMs = PATIENT_SESSION_TTL_MS
): Promise<void> {
  const jti = crypto.randomBytes(16).toString('hex');
  const expiresAtMs = Date.now() + ttlMs;
  const createdAt = new Date().toISOString();

  await persistSessionRecord({
    jti,
    patientId,
    createdAt,
    expiresAtMs,
    expiresAtDate: new Date(expiresAtMs),
    revoked: false,
  });

  const signedValue = signSessionPayload(patientId, jti, expiresAtMs);
  const maxAgeSeconds = Math.max(1, Math.floor(ttlMs / 1000));
  res.append('Set-Cookie', buildCookieHeader(req, signedValue, maxAgeSeconds));
}

export async function clearPatientSessionCookie(req: Request, res: Response): Promise<void> {
  const cookies = parseCookies(req.headers.cookie);
  const raw = cookies[PATIENT_SESSION_COOKIE_NAME];
  if (raw) {
    const parsed = verifySignedSessionCookieValue(raw);
    if (parsed) {
      await revokeSessionRecord(parsed.jti).catch(() => {});
    }
  }
  res.append('Set-Cookie', buildCookieHeader(req, '', 0));
}

// --- CSRF Check for Cookie-Authenticated Mutations ---

export function assertSafeMutationOrigin(req: Request): boolean {
  const method = req.method.toUpperCase();
  if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
    return true;
  }
  if (req.headers['x-requested-with']) {
    return true;
  }
  const origin = req.headers.origin;
  if (typeof origin === 'string' && origin.trim()) {
    try {
      const originHost = new URL(origin).host.toLowerCase();
      const forwardedHost = String(req.headers['x-forwarded-host'] || '').split(',')[0].trim().toLowerCase();
      const host = String(req.headers.host || '').trim().toLowerCase();
      if ((forwardedHost && originHost === forwardedHost) || (host && originHost === host)) {
        return true;
      }
    } catch {
      return false;
    }
    return false;
  }
  return false;
}

// --- Public Business Operations ---

export async function registerPatientAccount(input: {
  fullName: unknown;
  dateOfBirth: unknown;
  gender?: unknown;
  mobileNumber: unknown;
  email?: unknown;
  address?: unknown;
  password: unknown;
  confirmPassword: unknown;
}): Promise<PatientAccountProfile> {
  const fullName = cleanText(input.fullName, 120);
  if (fullName.length < 2) {
    throw new HttpStatusError(400, 'Full name must be at least 2 characters long.');
  }

  const { dateOfBirth, age } = validateDateOfBirth(input.dateOfBirth);
  const gender = cleanText(input.gender, 40) || undefined;
  const { mobileNumber, normalizedMobile } = validateMobileNumber(input.mobileNumber);
  const { email, emailLower } = validateOptionalEmail(input.email);
  const address = cleanText(input.address, 240) || undefined;
  const password = validatePasswordStrength(input.password, input.confirmPassword);

  const passwordHash = await hashPatientPassword(password);
  const now = new Date().toISOString();
  const db = await getMediBridgeDb();

  if (db) {
    const col = await getOrCreateWriteCollection(
      db,
      ['patients', 'Patients', 'patient'],
      'patients'
    );
    await ensurePatientIndexes(col);

    // Check duplicates against both normalizedMobile and legacy phone numbers (and email)
    const dupOr: Document[] = [
      { normalizedMobile },
      { phone: mobileNumber },
      { phone: { $regex: `${normalizedMobile}$` } },
    ];
    if (emailLower) {
      dupOr.push({ emailLower }, { email: { $regex: `^${emailLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, $options: 'i' } });
    }
    const existing = await col.findOne({ $or: dupOr });
    if (existing) {
      throw new HttpStatusError(
        409,
        'An account with this mobile number or email address already exists. Please log in with your Patient ID.'
      );
    }

    const patientId = await generateNextPatientId();
    const doc: StoredPatientAccount = {
      patientId,
      fullName,
      dateOfBirth,
      age,
      ...(gender ? { gender } : {}),
      mobileNumber,
      normalizedMobile,
      ...(email ? { email, emailLower } : {}),
      ...(address ? { address } : {}),
      passwordHash,
      registrationDate: now,
      createdAt: now,
      updatedAt: now,
      accountStatus: 'active',
      storageMode: 'mongodb',
    };

    try {
      await col.insertOne({ ...doc });
    } catch (err) {
      if ((err as { code?: number })?.code === 11000) {
        throw new HttpStatusError(
          409,
          'An account with this mobile number or email address already exists. Please log in with your Patient ID.'
        );
      }
      throw err;
    }

    return toSafePatientProfile(doc, 'mongodb');
  }

  // Preview fallback storage
  const records = readPreviewPatients();
  const duplicate = records.some(
    (r) =>
      r.normalizedMobile === normalizedMobile ||
      (emailLower && r.emailLower === emailLower)
  );
  if (duplicate) {
    throw new HttpStatusError(
      409,
      'An account with this mobile number or email address already exists. Please log in with your Patient ID.'
    );
  }

  const patientId = await generateNextPatientId();
  const record: StoredPatientAccount = {
    patientId,
    fullName,
    dateOfBirth,
    age,
    gender,
    mobileNumber,
    normalizedMobile,
    email,
    emailLower,
    address,
    passwordHash,
    registrationDate: now,
    createdAt: now,
    updatedAt: now,
    accountStatus: 'active',
    storageMode: 'preview',
  };
  records.unshift(record);
  writePreviewPatients(records);
  return toSafePatientProfile(record, 'preview');
}

export async function loginPatientAccount(
  req: Request,
  input: { patientId: unknown; password: unknown }
): Promise<PatientAccountProfile> {
  const rawPatientId = cleanText(input.patientId, 60).toUpperCase();
  const password = typeof input.password === 'string' ? input.password : '';

  const clientIp = getClientIp(req);
  const ipKey = `ip:${clientIp}`;
  const comboKey = `id:${clientIp}:${rawPatientId || 'empty'}`;

  checkRateBucket(ipKey, MAX_FAILURES_PER_IP);
  checkRateBucket(comboKey, MAX_FAILURES_PER_ID);

  if (!rawPatientId || !password) {
    recordLoginFailure(ipKey, MAX_FAILURES_PER_IP);
    recordLoginFailure(comboKey, MAX_FAILURES_PER_ID);
    throw new HttpStatusError(400, 'Patient ID and password are required.');
  }

  let matchedDoc: Document | null = null;
  let storageMode: 'mongodb' | 'preview' = 'preview';
  const db = await getMediBridgeDb();

  if (db) {
    storageMode = 'mongodb';
    const col = await getOrCreateWriteCollection(
      db,
      ['patients', 'Patients', 'patient'],
      'patients'
    );
    matchedDoc = await col.findOne({ patientId: rawPatientId });
  } else {
    const records = readPreviewPatients();
    matchedDoc =
      (records.find((r) => r.patientId.toUpperCase() === rawPatientId) as unknown as Document) ||
      null;
  }

  const storedHash =
    matchedDoc && typeof matchedDoc.passwordHash === 'string'
      ? matchedDoc.passwordHash
      : DUMMY_PASSWORD_HASH;

  const passwordValid = await verifyPatientPassword(password, storedHash);
  if (!matchedDoc || typeof matchedDoc.passwordHash !== 'string' || !passwordValid) {
    recordLoginFailure(ipKey, MAX_FAILURES_PER_IP);
    recordLoginFailure(comboKey, MAX_FAILURES_PER_ID);
    throw new HttpStatusError(401, 'Invalid Patient ID or password.');
  }

  if (matchedDoc.accountStatus === 'suspended') {
    throw new HttpStatusError(
      403,
      'This patient account is currently suspended. Please contact MediBridge support.'
    );
  }

  clearLoginFailures(ipKey);
  clearLoginFailures(comboKey);
  return toSafePatientProfile(matchedDoc, storageMode);
}

export async function getPatientProfileById(
  patientId: string
): Promise<PatientAccountProfile | null> {
  const db = await getMediBridgeDb();
  if (db) {
    const col = await getOrCreateWriteCollection(
      db,
      ['patients', 'Patients', 'patient'],
      'patients'
    );
    const doc = await col.findOne({ patientId: patientId.trim().toUpperCase() });
    if (!doc || typeof doc.passwordHash !== 'string') return null;
    if (doc.accountStatus === 'suspended') return null;
    return toSafePatientProfile(doc, 'mongodb');
  }
  const records = readPreviewPatients();
  const found = records.find((r) => r.patientId === patientId.trim().toUpperCase());
  if (!found || found.accountStatus === 'suspended') return null;
  return toSafePatientProfile(found as unknown as Document, 'preview');
}

export async function updatePatientProfileById(
  patientId: string,
  input: {
    fullName?: unknown;
    dateOfBirth?: unknown;
    gender?: unknown;
    mobileNumber?: unknown;
    email?: unknown;
    address?: unknown;
  }
): Promise<PatientAccountProfile | null> {
  const existing = await getPatientProfileById(patientId);
  if (!existing) return null;

  const updates: Document = {
    updatedAt: new Date().toISOString(),
  };

  if (input.fullName !== undefined) {
    const fullName = cleanText(input.fullName, 120);
    if (fullName.length < 2) {
      throw new HttpStatusError(400, 'Full name must be at least 2 characters long.');
    }
    updates.fullName = fullName;
  }

  if (input.dateOfBirth !== undefined) {
    const { dateOfBirth, age } = validateDateOfBirth(input.dateOfBirth);
    updates.dateOfBirth = dateOfBirth;
    updates.age = age;
  }

  if (input.gender !== undefined) {
    const gender = cleanText(input.gender, 40);
    updates.gender = gender || '';
  }

  if (input.mobileNumber !== undefined) {
    const { mobileNumber, normalizedMobile } = validateMobileNumber(input.mobileNumber);
    updates.mobileNumber = mobileNumber;
    updates.normalizedMobile = normalizedMobile;
  }

  if (input.email !== undefined) {
    const { email, emailLower } = validateOptionalEmail(input.email);
    updates.email = email || '';
    updates.emailLower = emailLower || null;
  }

  if (input.address !== undefined) {
    updates.address = cleanText(input.address, 240);
  }

  const db = await getMediBridgeDb();
  if (db) {
    const col = await getOrCreateWriteCollection(
      db,
      ['patients', 'Patients', 'patient'],
      'patients'
    );
    await ensurePatientIndexes(col);

    // Check uniqueness for mobile or email excluding self
    const dupClauses: Document[] = [];
    if (updates.normalizedMobile) {
      dupClauses.push({ normalizedMobile: updates.normalizedMobile });
    }
    if (updates.emailLower) {
      dupClauses.push({ emailLower: updates.emailLower });
    }
    if (dupClauses.length > 0) {
      const conflict = await col.findOne({
        patientId: { $ne: patientId },
        $or: dupClauses,
      });
      if (conflict) {
        throw new HttpStatusError(
          409,
          'Another patient account already uses that mobile number or email address.'
        );
      }
    }

    const updateOp: Document = { $set: { ...updates } };
    if (updates.emailLower === null) {
      delete updateOp.$set.emailLower;
      delete updateOp.$set.email;
      updateOp.$unset = { emailLower: '', email: '' };
    }

    const updatedDoc = await col.findOneAndUpdate(
      { patientId },
      updateOp,
      { returnDocument: 'after' }
    );
    return updatedDoc ? toSafePatientProfile(updatedDoc, 'mongodb') : null;
  }

  // Preview store update
  const records = readPreviewPatients();
  const idx = records.findIndex((r) => r.patientId === patientId);
  if (idx === -1) return null;

  if (
    updates.normalizedMobile &&
    records.some((r, i) => i !== idx && r.normalizedMobile === updates.normalizedMobile)
  ) {
    throw new HttpStatusError(
      409,
      'Another patient account already uses that mobile number or email address.'
    );
  }
  if (
    updates.emailLower &&
    records.some((r, i) => i !== idx && r.emailLower === updates.emailLower)
  ) {
    throw new HttpStatusError(
      409,
      'Another patient account already uses that mobile number or email address.'
    );
  }

  records[idx] = {
    ...records[idx],
    ...(updates.fullName !== undefined ? { fullName: String(updates.fullName) } : {}),
    ...(updates.dateOfBirth !== undefined
      ? { dateOfBirth: String(updates.dateOfBirth), age: Number(updates.age) }
      : {}),
    ...(updates.gender !== undefined
      ? { gender: updates.gender ? String(updates.gender) : undefined }
      : {}),
    ...(updates.mobileNumber !== undefined
      ? {
          mobileNumber: String(updates.mobileNumber),
          normalizedMobile: String(updates.normalizedMobile),
        }
      : {}),
    ...(input.email !== undefined
      ? {
          email: updates.email ? String(updates.email) : undefined,
          emailLower: updates.emailLower ? String(updates.emailLower) : undefined,
        }
      : {}),
    ...(updates.address !== undefined
      ? { address: updates.address ? String(updates.address) : undefined }
      : {}),
    updatedAt: String(updates.updatedAt),
  };
  writePreviewPatients(records);
  return toSafePatientProfile(records[idx] as unknown as Document, 'preview');
}

// --- Middleware & Session Verification ---

export async function resolveAuthenticatedPatientFromRequest(
  req: Request
): Promise<{ patient: PatientAccountProfile; jti: string } | null> {
  const cookies = parseCookies(req.headers.cookie);
  const rawCookie = cookies[PATIENT_SESSION_COOKIE_NAME];
  if (!rawCookie) return null;

  const verified = verifySignedSessionCookieValue(rawCookie);
  if (!verified) return null;

  const active = await isSessionActive(verified.jti, verified.patientId);
  if (!active) return null;

  const patient = await getPatientProfileById(verified.patientId);
  if (!patient) return null;

  return { patient, jti: verified.jti };
}

export async function requirePatientAuth(
  req: PatientAuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!assertSafeMutationOrigin(req)) {
      res.status(403).json({
        error: 'Cross-site request validation failed. Please retry from the MediBridge application.',
      });
      return;
    }

    const resolved = await resolveAuthenticatedPatientFromRequest(req);
    if (!resolved) {
      res.status(401).json({
        error: 'Patient authentication required. Please log in with your Patient ID and password.',
      });
      return;
    }

    req.patient = resolved.patient;
    req.patientSessionJti = resolved.jti;
    next();
  } catch {
    res.status(401).json({
      error: 'Unable to verify patient session. Please log in again.',
    });
  }
}
