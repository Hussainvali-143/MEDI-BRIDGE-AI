import { GoogleGenAI, Type } from '@google/genai';
import type {
  EducationalHealthTest,
  EducationalHealthTopic,
  EducationalMedicineInfo,
  GroundingSource,
  HospitalRecord,
  WebHospitalSearchResponse,
} from '../src/types/healthcare.ts';

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured. Please check Settings > Secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function mapGeminiError(err: unknown): Error {
  const msg = err instanceof Error ? err.message : String(err);
  const lower = msg.toLowerCase();
  if (
    msg.includes('403') ||
    msg.includes('PERMISSION_DENIED') ||
    msg.includes('API_KEY_INVALID') ||
    lower.includes('api key not valid') ||
    lower.includes('api_key_invalid')
  ) {
    return new Error('Gemini API key missing or invalid. Please check your key in Settings > Secrets.');
  }
  if (msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED')) {
    return new Error('Gemini API rate limit reached. Please wait a moment and try again.');
  }
  if (msg.includes('503') || msg.includes('UNAVAILABLE') || lower.includes('high demand')) {
    return new Error('The educational AI service is temporarily busy. Please try again in a few moments.');
  }
  if (
    msg.includes('INVALID_ARGUMENT') ||
    lower.includes('unable to process') ||
    lower.includes('document has no pages') ||
    lower.includes('cannot read')
  ) {
    return new Error(
      'The uploaded PDF or image could not be processed. Please upload a valid, unencrypted PDF, JPG, JPEG, or PNG medical report.'
    );
  }
  return new Error(msg || 'Unable to fetch AI educational information.');
}

function safeParseAiJson<T>(rawText: string | undefined, fallbackError: string): T {
  const cleaned = (rawText ?? '')
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/, '')
    .trim();
  if (!cleaned) {
    throw new Error(fallbackError);
  }
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    throw new Error(fallbackError);
  }
}

export async function lookupMedicineEducation(medicineName: string): Promise<EducationalMedicineInfo> {
  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Provide clear, accurate, neutral patient-facing educational information about the medicine: "${medicineName}" (relevant to Indian clinical practice where applicable, e.g. generic molecule and common clinical context).`,
      config: {
        systemInstruction:
          'You are a clinical pharmacology educator. Provide objective, educational medicine information. Never prescribe dosages, never diagnose, and always emphasize consulting a licensed doctor or pharmacist.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            medicineName: { type: Type.STRING },
            activeIngredients: { type: Type.STRING },
            drugClass: { type: Type.STRING },
            generalUses: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            howTypicallyTaken: { type: Type.STRING },
            commonSideEffects: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            importantPrecautions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            whenToSeekUrgentHelp: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            disclaimer: { type: Type.STRING },
          },
          required: [
            'medicineName',
            'activeIngredients',
            'drugClass',
            'generalUses',
            'howTypicallyTaken',
            'commonSideEffects',
            'importantPrecautions',
            'whenToSeekUrgentHelp',
            'disclaimer',
          ],
        },
      },
    });

    const jsonText = (response.text ?? '{}').trim();
    const parsed = JSON.parse(jsonText) as EducationalMedicineInfo;
    return {
      ...parsed,
      disclaimer:
        parsed.disclaimer ||
        'Educational reference only. Not a substitute for professional medical advice, prescription, or pharmacist guidance.',
    };
  } catch (err) {
    throw mapGeminiError(err);
  }
}

export async function explainHealthTopic(topicName: string): Promise<EducationalHealthTopic> {
  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Explain the health topic "${topicName}" in clear, accessible educational language for patients and families in India.`,
      config: {
        systemInstruction:
          'You are a public health educator. Provide evidence-based, non-alarmist educational health explanations. Do not diagnose individual patients or prescribe treatments.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            category: { type: Type.STRING },
            overview: { type: Type.STRING },
            commonCausesAndRiskFactors: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            commonSymptoms: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            preventiveAndSelfCareGuidance: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            whenToConsultDoctor: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            disclaimer: { type: Type.STRING },
          },
          required: [
            'topic',
            'category',
            'overview',
            'commonCausesAndRiskFactors',
            'commonSymptoms',
            'preventiveAndSelfCareGuidance',
            'whenToConsultDoctor',
            'disclaimer',
          ],
        },
      },
    });

    const jsonText = (response.text ?? '{}').trim();
    const parsed = JSON.parse(jsonText) as EducationalHealthTopic;
    return {
      ...parsed,
      disclaimer:
        parsed.disclaimer ||
        'This health topic guide is strictly educational and does not constitute medical advice or diagnosis.',
    };
  } catch (err) {
    throw mapGeminiError(err);
  }
}

const HEALTH_TEST_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    testName: { type: Type.STRING },
    commonAliases: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    category: { type: Type.STRING },
    whatItMeasures: { type: Type.STRING },
    generalPurpose: { type: Type.STRING },
    commonParameters: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          parameter: { type: Type.STRING },
          roleInBody: { type: Type.STRING },
        },
        required: ['parameter', 'roleInBody'],
      },
    },
    generalPreparationNotes: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    questionsForDoctor: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    nonDiagnosticNotice: { type: Type.STRING },
  },
  required: [
    'testName',
    'commonAliases',
    'category',
    'whatItMeasures',
    'generalPurpose',
    'commonParameters',
    'generalPreparationNotes',
    'questionsForDoctor',
    'nonDiagnosticNotice',
  ],
};

const HEALTH_TEST_SYSTEM_INSTRUCTION =
  'You are a medical laboratory literacy educator. Explain common medical test names and their general purpose clearly. STRICT RULE: NEVER diagnose any disease, never state whether a patient has a medical condition or whether their numeric results are healthy/unhealthy, never recommend treatments, and always instruct the user to review actual report values with a qualified physician.';

async function withTransientRetry<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    const lower = msg.toLowerCase();
    const isTransient = msg.includes('503') || msg.includes('UNAVAILABLE') || lower.includes('high demand');
    if (!isTransient) throw err;
    await new Promise((resolve) => setTimeout(resolve, 800));
    return await fn();
  }
}

export async function educateHealthTest(testName: string, question?: string): Promise<EducationalHealthTest> {
  try {
    const ai = getAiClient();
    const prompt = question
      ? `Explain the medical laboratory/diagnostic test "${testName}" and address this general educational question without diagnosing: "${question}".`
      : `Explain the medical laboratory/diagnostic test "${testName}", what it measures, and its general clinical purpose.`;

    const response = await withTransientRetry(() =>
      ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          systemInstruction: HEALTH_TEST_SYSTEM_INSTRUCTION,
          responseMimeType: 'application/json',
          responseSchema: HEALTH_TEST_RESPONSE_SCHEMA,
        },
      })
    );

    const parsed = safeParseAiJson<EducationalHealthTest>(
      response.text,
      'Received an invalid response format while generating test education.'
    );
    return {
      ...parsed,
      nonDiagnosticNotice:
        'Educational Test Guide Only — This tool explains general test purposes and does not diagnose diseases or interpret personal medical reports.',
    };
  } catch (err) {
    throw mapGeminiError(err);
  }
}

export async function educateHealthTestDocument(params: {
  buffer: Buffer;
  mimeType: 'application/pdf' | 'image/jpeg' | 'image/png';
  question?: string;
}): Promise<EducationalHealthTest> {
  try {
    const ai = getAiClient();
    const prompt = params.question
      ? `Identify the laboratory or diagnostic test panel names and test parameters shown in this uploaded medical report document, and explain their general educational purpose without diagnosing any disease or interpreting patient health status. Also address this general question strictly from an educational perspective: "${params.question}". Do not repeat personal patient names, addresses, or phone numbers.`
      : 'Identify the laboratory or diagnostic test panel names and test parameters shown in this uploaded medical report document, and explain what those tests measure and their general educational purpose without diagnosing any disease or interpreting whether numeric values indicate illness. Do not repeat personal patient names, addresses, or phone numbers.';

    const documentPart = {
      inlineData: {
        mimeType: params.mimeType,
        data: params.buffer.toString('base64'),
      },
    };

    const response = await withTransientRetry(() =>
      ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: {
          parts: [documentPart, { text: prompt }],
        },
        config: {
          systemInstruction: HEALTH_TEST_SYSTEM_INSTRUCTION,
          responseMimeType: 'application/json',
          responseSchema: HEALTH_TEST_RESPONSE_SCHEMA,
        },
      })
    );

    const parsed = safeParseAiJson<EducationalHealthTest>(
      response.text,
      'Could not extract structured educational test details from the uploaded document. Ensure the PDF or image is clear and readable.'
    );
    return {
      ...parsed,
      nonDiagnosticNotice:
        'Educational Test Guide Only — This tool explains test names and parameters shown in your report without diagnosing diseases or storing your document. Always review actual values with a qualified physician.',
    };
  } catch (err) {
    throw mapGeminiError(err);
  }
}

export async function searchPublicHospitalsGrounded(filters: {
  q?: string;
  state?: string;
  district?: string;
  city?: string;
  pinCode?: string;
  facilityType?: string;
}): Promise<WebHospitalSearchResponse> {
  try {
    const ai = getAiClient();
    const locationParts = [
      filters.q ? `Query: ${filters.q}` : '',
      filters.facilityType ? `Facility Type: ${filters.facilityType}` : '',
      filters.city ? `City: ${filters.city}` : '',
      filters.district ? `District: ${filters.district}` : '',
      filters.state ? `State: ${filters.state}` : '',
      filters.pinCode ? `PIN Code: ${filters.pinCode}` : '',
    ]
      .filter(Boolean)
      .join(', ');

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Find real hospitals in India matching: ${locationParts}.
Return ONLY a valid JSON array of up to 6 hospitals found directly in the search results. Each item must have keys: "name", "address", "city", "district", "state", "pinCode", "contactNumber", "facilityType".
CRITICAL RULES:
- Do NOT invent any hospital name, address, PIN code, or phone number.
- If a phone number, PIN code, or street address is not explicitly verified in the search results, write "Not listed in public search".
- Only output JSON array, no markdown fences if possible.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const rawText = (response.text ?? '').trim();
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
    const sources: GroundingSource[] = [];
    const seenUris = new Set<string>();

    for (const chunk of chunks) {
      const web = chunk.web;
      if (web?.uri && !seenUris.has(web.uri)) {
        seenUris.add(web.uri);
        sources.push({
          title: web.title || web.uri,
          uri: web.uri,
        });
      }
    }

    let parsedItems: Array<Record<string, unknown>> = [];
    const jsonMatch = rawText.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      try {
        const candidate = JSON.parse(jsonMatch[0]);
        if (Array.isArray(candidate)) {
          parsedItems = candidate;
        }
      } catch {
        parsedItems = [];
      }
    }

    const results: HospitalRecord[] = parsedItems
      .filter((item) => typeof item?.name === 'string' && String(item.name).trim().length > 0)
      .map((item, idx) => ({
        id: `web-${idx}-${Date.now()}`,
        name: String(item.name).trim(),
        address: String(item.address || 'Not listed in public search'),
        city: String(item.city || filters.city || ''),
        district: String(item.district || filters.district || ''),
        state: String(item.state || filters.state || ''),
        pinCode: String(item.pinCode || filters.pinCode || 'Not listed'),
        contactNumber: String(item.contactNumber || 'Not listed in public search'),
        facilityType: String(item.facilityType || filters.facilityType || 'Hospital / Medical Facility'),
        verified: false,
        sourceLabel: 'Unverified Public Web Search',
        sourceUrl: sources[idx]?.uri || sources[0]?.uri,
      }));

    return {
      results,
      sources,
      note:
        results.length > 0
          ? 'Public web search results retrieved with source grounding.'
          : 'No structured hospital records could be extracted from public search results. Review the cited sources below or refine your State/District/City/PIN search.',
      disclaimer:
        'Unverified external information retrieved from public web search. Always verify facility address, contact numbers, and current availability directly with the hospital before visiting.',
    };
  } catch (err) {
    throw mapGeminiError(err);
  }
}
