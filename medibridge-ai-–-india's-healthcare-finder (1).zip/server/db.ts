import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { MongoClient, ObjectId, ServerApiVersion } from 'mongodb';
import type { Db, Collection, Document } from 'mongodb';
import type {
  AppointmentRecord,
  AppointmentStatus,
  CuratedHealthTopic,
  CuratedTestRecord,
  DatabaseStatus,
  DoctorRecord,
  EmergencyContactRecord,
  HospitalRecord,
  MedicineDatabaseRecord,
  MedicineReminderRecord,
  PatientRecord,
  ReminderActionStatus,
} from '../src/types/healthcare.ts';

export function getConfiguredDbName(): string {
  const raw = (process.env.MONGODB_DB_NAME || 'Medi_Bridge').trim().replace(/^['"]|['"]$/g, '');
  return raw || 'Medi_Bridge';
}

function getCleanedMongoUri(): string {
  const raw = process.env.MONGODB_URI || '';
  return raw.trim().replace(/^['"]|['"]$/g, '');
}

function getUriScheme(uri: string): 'mongodb+srv' | 'mongodb' | 'invalid' | 'unset' {
  if (!uri) return 'unset';
  if (uri.startsWith('mongodb+srv://')) return 'mongodb+srv';
  if (uri.startsWith('mongodb://')) return 'mongodb';
  return 'invalid';
}

type UriDiagnostics = NonNullable<DatabaseStatus['envVarsDetected']['uriDiagnostics']>;

function inspectMongoUriSafely(rawEnv: string, cleanedUri: string): UriDiagnostics {
  const rawTrimmed = rawEnv.trim();
  const rawHadWhitespace = rawEnv !== rawTrimmed || /\s/.test(cleanedUri);
  const rawHadSurroundingQuotes =
    (rawTrimmed.startsWith('"') && rawTrimmed.endsWith('"')) ||
    (rawTrimmed.startsWith("'") && rawTrimmed.endsWith("'"));

  const withoutScheme = cleanedUri.replace(/^mongodb(?:\+srv)?:\/\//, '');
  const slashIdx = withoutScheme.indexOf('/');
  const queryIdx = withoutScheme.indexOf('?');
  const endAuthorityIdx =
    slashIdx === -1 ? (queryIdx === -1 ? withoutScheme.length : queryIdx) : slashIdx;
  const authority = withoutScheme.slice(0, endAuthorityIdx);
  const afterAuthority = withoutScheme.slice(endAuthorityIdx);

  const atMatches = authority.match(/@/g) || [];
  const multipleAtSigns = atMatches.length > 1;
  const lastAtIdx = authority.lastIndexOf('@');
  const hasAt = lastAtIdx !== -1;

  const credentials = hasAt ? authority.slice(0, lastAtIdx) : '';
  const firstColonIdx = credentials.indexOf(':');
  const hasUsernameAndPassword = hasAt && firstColonIdx > 0 && firstColonIdx < credentials.length - 1;

  const rawUser = firstColonIdx !== -1 ? credentials.slice(0, firstColonIdx) : credentials;
  const rawPass = firstColonIdx !== -1 ? credentials.slice(firstColonIdx + 1) : '';
  const multipleColonsInCredentials = (credentials.match(/:/g) || []).length > 1;

  const hasAngleBracketPlaceholder =
    /[<>]/.test(rawUser) || /[<>]/.test(rawPass) || /<password>|<db_password>|<username>/i.test(cleanedUri);

  // Reserved URI characters that must be percent-encoded if present in password/username
  const hasUnencodedReservedInPass = /[@:/?#[\]\s]/.test(rawPass);
  const hasUnencodedNonStandardPercent = /%(?![0-9A-Fa-f]{2})/.test(rawPass) || /%(?![0-9A-Fa-f]{2})/.test(rawUser);

  let hasMalformedPercentEncoding = hasUnencodedNonStandardPercent;
  try {
    if (rawUser) decodeURIComponent(rawUser);
    if (rawPass) decodeURIComponent(rawPass);
  } catch {
    hasMalformedPercentEncoding = true;
  }

  let authSourceParam: string | null = null;
  let uriParsesCleanly = false;
  try {
    const testUrl = new URL(cleanedUri.replace(/^mongodb(?:\+srv)?:\/\//, 'https://'));
    authSourceParam = testUrl.searchParams.get('authSource');
    uriParsesCleanly = hasUsernameAndPassword && !multipleAtSigns && !multipleColonsInCredentials && !hasMalformedPercentEncoding && !hasAngleBracketPlaceholder;
  } catch {
    uriParsesCleanly = false;
    const qMatch = afterAuthority.match(/[?&]authSource=([^&#]+)/i);
    authSourceParam = qMatch ? qMatch[1] : null;
  }

  return {
    rawHadSurroundingQuotes,
    rawHadWhitespace,
    hasUsernameAndPassword,
    hasAngleBracketPlaceholder,
    hasUnencodedSpecialCharsInPassword: hasUnencodedReservedInPass || multipleAtSigns || multipleColonsInCredentials,
    hasMalformedPercentEncoding,
    multipleAtSigns,
    multipleColonsInCredentials,
    authSourceParam,
    uriParsesCleanly,
  };
}

function classifyConnectionError(
  errMsg: string | null,
  uriSet: boolean,
  diag?: UriDiagnostics
): {
  errorCategory: DatabaseStatus['errorCategory'];
  diagnosticHint: string | null;
} {
  if (!uriSet) {
    return {
      errorCategory: 'missing_env',
      diagnosticHint: 'Add MONGODB_URI and MONGODB_DB_NAME=Medi_Bridge in Settings > Secrets, then restart or retry.',
    };
  }
  if (!errMsg) {
    return { errorCategory: null, diagnosticHint: null };
  }
  const lower = errMsg.toLowerCase();
  if (
    lower.includes('ssl alert number 80') ||
    lower.includes('tlsv1 alert internal error') ||
    lower.includes('ssl routines')
  ) {
    return {
      errorCategory: 'atlas_tls_or_ip_whitelist',
      diagnosticHint:
        'Backend successfully read MONGODB_URI and MONGODB_DB_NAME, but MongoDB Atlas aborted the TLS handshake (SSL alert 80). This usually means the Cloud Run outbound IP is blocked by MongoDB Atlas Network Access. In MongoDB Atlas, open Security → Network Access → Add IP Address → Allow Access from Anywhere (0.0.0.0/0), save, and click Retry Connection.',
    };
  }
  if (lower.includes('authentication failed') || lower.includes('bad auth') || lower.includes('auth failed')) {
    const reasons: string[] = [];
    if (diag?.hasAngleBracketPlaceholder) {
      reasons.push('The URI still contains angle brackets (< or >), such as <db_password> — remove the < > brackets around your password.');
    }
    if (diag?.hasUnencodedSpecialCharsInPassword || diag?.hasMalformedPercentEncoding) {
      reasons.push('The password contains unencoded special characters (such as @, :, /, ?, #, or %) that must be URL-encoded (e.g., @ → %40, : → %3A, % → %25).');
    }
    if (diag?.authSourceParam && diag.authSourceParam !== 'admin') {
      reasons.push(`The URI specifies authSource=${diag.authSourceParam}, whereas MongoDB Atlas Database Access SCRAM users authenticate against authSource=admin.`);
    }
    if (diag?.rawHadWhitespace) {
      reasons.push('The URI contains extra whitespace or newline characters.');
    }
    if (reasons.length === 0) {
      reasons.push(
        'The URI syntax parses cleanly, which means MongoDB Atlas rejected the username or password. Verify in MongoDB Atlas → Security → Database Access that the username in MONGODB_URI matches a Database User (not your Atlas email login) and reset/re-copy the password cleanly, URL-encoding any special characters.'
      );
    }
    return {
      errorCategory: 'auth_failed',
      diagnosticHint: reasons.join(' '),
    };
  }
  if (lower.includes('enotfound') || lower.includes('querysrv') || lower.includes('ereused') || lower.includes('dns')) {
    return {
      errorCategory: 'dns_srv_failed',
      diagnosticHint:
        'Could not resolve the MongoDB Atlas cluster hostname from MONGODB_URI. Verify the cluster address in your Atlas connection string.',
    };
  }
  if (lower.includes('timed out') || lower.includes('server selection')) {
    return {
      errorCategory: 'network_timeout',
      diagnosticHint:
        'Connection to MongoDB Atlas timed out. Ensure 0.0.0.0/0 is enabled in Atlas Network Access and the cluster is not paused.',
    };
  }
  return {
    errorCategory: 'unknown',
    diagnosticHint: 'Verify your MONGODB_URI format and MongoDB Atlas Network Access settings.',
  };
}

const PREVIEW_STORE_PATH = path.resolve('/tmp', 'medibridge_preview_store.json');

interface PreviewStoreData {
  patients: PatientRecord[];
  appointments: AppointmentRecord[];
}

let mongoClient: MongoClient | null = null;
let mongoDb: Db | null = null;
let lastConnectionError: string | null = null;

export function escapeRegex(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function asCleanString(value: unknown, maxLen = 200): string {
  if (typeof value !== 'string') return '';
  return value.trim().slice(0, maxLen);
}

function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.map((item) => String(item).trim()).filter(Boolean);
  }
  if (typeof value === 'string' && value.trim()) {
    return value
      .split(/[,;|]/)
      .map((item) => item.trim())
      .filter(Boolean);
  }
  return [];
}

function readPreviewStore(): PreviewStoreData {
  try {
    if (fs.existsSync(PREVIEW_STORE_PATH)) {
      const raw = fs.readFileSync(PREVIEW_STORE_PATH, 'utf8');
      const parsed = JSON.parse(raw) as Partial<PreviewStoreData>;
      return {
        patients: Array.isArray(parsed.patients) ? parsed.patients : [],
        appointments: Array.isArray(parsed.appointments) ? parsed.appointments : [],
      };
    }
  } catch {
    // Return empty preview store if unreadable
  }
  return { patients: [], appointments: [] };
}

function writePreviewStore(data: PreviewStoreData): void {
  try {
    fs.writeFileSync(PREVIEW_STORE_PATH, JSON.stringify(data, null, 2), 'utf8');
  } catch {
    // Best-effort persistence in preview mode
  }
}

export async function resetMongoConnection(): Promise<void> {
  if (mongoClient) {
    try {
      await mongoClient.close();
    } catch {
      // Ignore close error
    }
  }
  mongoClient = null;
  mongoDb = null;
  lastConnectionError = null;
}

export async function getMediBridgeDb(forceRetry = false): Promise<Db | null> {
  const uri = getCleanedMongoUri();
  const dbName = getConfiguredDbName();
  if (!uri) {
    lastConnectionError = 'MONGODB_URI is not configured in Secrets.';
    return null;
  }

  if (forceRetry) {
    await resetMongoConnection();
  }

  if (mongoDb && mongoClient) {
    return mongoDb;
  }

  try {
    const client = new MongoClient(uri, {
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 8000,
      connectTimeoutMS: 8000,
      family: 4,
      autoSelectFamily: false,
      serverApi: {
        version: ServerApiVersion.v1,
        strict: false,
        deprecationErrors: false,
      },
    });
    await client.connect();
    const db = client.db(dbName);
    await db.command({ ping: 1 });
    mongoClient = client;
    mongoDb = db;
    lastConnectionError = null;
    return mongoDb;
  } catch (err) {
    lastConnectionError = err instanceof Error ? err.message : 'Unable to connect to MongoDB Atlas.';
    mongoClient = null;
    mongoDb = null;
    return null;
  }
}

async function resolveCollection(db: Db, candidates: string[]): Promise<Collection<Document> | null> {
  const existing = await db.listCollections({}, { nameOnly: true }).toArray();
  const names = existing.map((c) => c.name);
  for (const candidate of candidates) {
    if (names.includes(candidate)) {
      return db.collection(candidate);
    }
  }
  const lowerMap = new Map(names.map((n) => [n.toLowerCase(), n]));
  for (const candidate of candidates) {
    const matched = lowerMap.get(candidate.toLowerCase());
    if (matched) {
      return db.collection(matched);
    }
  }
  return null;
}

export async function getOrCreateWriteCollection(db: Db, candidates: string[], defaultName: string): Promise<Collection<Document>> {
  const existing = await resolveCollection(db, candidates);
  return existing ?? db.collection(defaultName);
}

function isDocVerified(doc: Document): boolean {
  if (typeof doc.verified === 'boolean') return doc.verified;
  if (typeof doc.isVerified === 'boolean') return doc.isVerified;
  if (typeof doc.is_verified === 'boolean') return doc.is_verified;
  const status = String(doc.verificationStatus || doc.verification_status || doc.status || '').toLowerCase();
  return status === 'verified' || status === 'approved';
}

function sanitizeHttpUrl(raw: unknown): string | undefined {
  if (typeof raw !== 'string' || !raw.trim()) return undefined;
  try {
    const parsed = new URL(raw.trim());
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.toString();
    }
  } catch {
    // Reject invalid URLs
  }
  return undefined;
}

function normalizeHospital(doc: Document): HospitalRecord {
  const verified = isDocVerified(doc);
  const name = String(doc.name || doc.hospitalName || doc.hospital_name || doc.facilityName || 'Unnamed Healthcare Facility');
  const rawAddress = String(doc.address || doc.fullAddress || doc.streetAddress || doc.location || '').trim();
  const address = rawAddress || 'Address not listed';
  const city = String(doc.city || doc.town || '');
  const district = String(doc.district || doc.taluk || '');
  const state = String(doc.state || '');
  const pinCode = String(doc.pinCode || doc.pincode || doc.pin || doc.postalCode || '');
  const rawPhone = String(doc.contactNumber || doc.phone || doc.contact || doc.phoneNumber || doc.helpline || '').trim();
  const contactNumber = rawPhone || 'Not listed';
  const emergencyNumber = doc.emergencyNumber ? String(doc.emergencyNumber) : undefined;
  const rawFacilityType = String(doc.facilityType || doc.type || doc.category || doc.hospitalType || '').trim();
  const facilityType = rawFacilityType || 'Healthcare Facility';
  const website = sanitizeHttpUrl(doc.website);
  const officialSourceUrl = sanitizeHttpUrl(doc.officialSourceUrl);
  const officialSourceName =
    typeof doc.officialSourceName === 'string' && doc.officialSourceName.trim()
      ? doc.officialSourceName.trim()
      : undefined;
  const verificationNotes =
    typeof doc.verificationNotes === 'string' && doc.verificationNotes.trim()
      ? doc.verificationNotes.trim()
      : undefined;
  const verifiedAt =
    typeof doc.verifiedAt === 'string' && doc.verifiedAt.trim() ? doc.verifiedAt.trim() : undefined;
  const verifiedBy =
    typeof doc.verifiedBy === 'string' && doc.verifiedBy.trim() ? doc.verifiedBy.trim() : undefined;
  const latitude = typeof doc.latitude === 'number' && Number.isFinite(doc.latitude) ? doc.latitude : null;
  const longitude = typeof doc.longitude === 'number' && Number.isFinite(doc.longitude) ? doc.longitude : null;
  const sourceId = typeof doc.sourceId === 'string' && doc.sourceId.trim() ? doc.sourceId.trim() : undefined;

  return {
    id: String(doc._id || crypto.randomUUID()),
    name,
    address,
    city,
    district,
    state,
    pinCode,
    contactNumber,
    emergencyNumber,
    facilityType,
    verified,
    sourceLabel: verified
      ? officialSourceName
        ? `Verified via ${officialSourceName}`
        : 'Medi_Bridge Verified Record'
      : 'Medi_Bridge Unverified Record',
    sourceUrl: officialSourceUrl || website,
    specialties: asStringArray(doc.specialties || doc.departments),
    website,
    latitude,
    longitude,
    sourceId,
    officialSourceName,
    officialSourceUrl,
    verificationNotes,
    verifiedAt,
    verifiedBy,
  };
}

function normalizeDoctor(doc: Document): DoctorRecord {
  const verified = isDocVerified(doc);
  return {
    id: String(doc._id || crypto.randomUUID()),
    name: String(doc.name || doc.doctorName || doc.fullName || 'Unnamed Practitioner'),
    specialty: String(doc.specialty || doc.speciality || doc.department || 'General Medicine'),
    qualification: doc.qualification || doc.degree ? String(doc.qualification || doc.degree) : undefined,
    hospitalAffiliation: String(doc.hospitalAffiliation || doc.hospitalName || doc.hospital || doc.clinic || 'Affiliation not listed'),
    city: String(doc.city || ''),
    state: String(doc.state || ''),
    contactNumber: String(doc.contactNumber || doc.phone || doc.verifiedContact || doc.contact || 'Not listed'),
    email: doc.email ? String(doc.email) : undefined,
    consultationHours: doc.consultationHours || doc.timings ? String(doc.consultationHours || doc.timings) : undefined,
    verified,
    sourceLabel: verified ? 'Medi_Bridge Verified Contact' : 'Medi_Bridge Unverified Record',
    registrationNumber: doc.registrationNumber || doc.nmcNumber || doc.mciNumber ? String(doc.registrationNumber || doc.nmcNumber || doc.mciNumber) : undefined,
  };
}

function asWarningList(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.map((item) => String(item).trim()).filter(Boolean);
  }
  if (typeof value === 'string' && value.trim()) {
    const trimmed = value.trim();
    if (/[;|]/.test(trimmed)) {
      return trimmed
        .split(/[;|]/)
        .map((item) => item.trim())
        .filter(Boolean);
    }
    return [trimmed];
  }
  return [];
}

function normalizeMedicine(doc: Document): MedicineDatabaseRecord {
  const verified =
    doc.verified === true ||
    doc.pharmacistVerified === true ||
    doc.isVerified === true ||
    doc.is_verified === true ||
    ['verified', 'approved'].includes(String(doc.verificationStatus || '').toLowerCase());
  const brandNames = asStringArray(doc.brandNames || doc.brandName || doc.brands);
  const name = String(doc.name || doc.medicineName || doc.brandName || doc.title || 'Unnamed Medicine').trim();
  const genericName = String(
    doc.genericName || doc.composition || doc.activeIngredient || doc.activeIngredients || doc.salt || ''
  ).trim();
  const strength =
    doc.strength !== undefined && doc.strength !== null && String(doc.strength).trim()
      ? String(doc.strength).trim()
      : undefined;
  const formulation =
    doc.formulation !== undefined && doc.formulation !== null && String(doc.formulation).trim()
      ? String(doc.formulation).trim()
      : undefined;
  const packSize =
    doc.packSize !== undefined && doc.packSize !== null && String(doc.packSize).trim()
      ? String(doc.packSize).trim()
      : undefined;
  const rawForm = doc.dosageForms || doc.dosageForm || doc.form || formulation || packSize;
  const dosageForms =
    rawForm !== undefined && rawForm !== null && String(rawForm).trim()
      ? String(rawForm).trim()
      : undefined;
  const manufacturer =
    typeof doc.manufacturer === 'string' && doc.manufacturer.trim()
      ? doc.manufacturer.trim()
      : undefined;
  const medicineCategory =
    typeof doc.medicineCategory === 'string' && doc.medicineCategory.trim()
      ? doc.medicineCategory.trim()
      : undefined;
  const activeIngredients =
    typeof doc.activeIngredients === 'string' && doc.activeIngredients.trim()
      ? doc.activeIngredients.trim()
      : undefined;
  const prescriptionClassification =
    verified && typeof doc.prescriptionClassification === 'string' && doc.prescriptionClassification.trim()
      ? doc.prescriptionClassification.trim()
      : undefined;
  const officialSourceName =
    typeof doc.officialSourceName === 'string' && doc.officialSourceName.trim()
      ? doc.officialSourceName.trim()
      : undefined;
  const sourceUrl = sanitizeHttpUrl(doc.sourceUrl);
  const lastCheckedDate =
    typeof doc.lastCheckedDate === 'string' && doc.lastCheckedDate.trim()
      ? doc.lastCheckedDate.trim()
      : undefined;
  const rawDrugClass = String(doc.drugClass || doc.category || medicineCategory || '').trim();
  const usedForList = asWarningList(doc.usedFor);
  const commonUses = [
    ...usedForList,
    ...asStringArray(doc.commonUses || doc.uses || doc.indications || doc.generalUses),
  ].filter((v, idx, arr) => Boolean(v) && arr.indexOf(v) === idx);
  const warnings = asWarningList(
    doc.warnings || doc.precautions || doc.safetyWarnings || doc.contraindications || doc.sideEffects
  );
  return {
    id: String(doc._id || crypto.randomUUID()),
    name,
    genericName,
    brandNames,
    drugClass: rawDrugClass || 'MedicineInfo Record',
    medicineCategory,
    strength,
    formulation,
    packSize,
    dosageForms,
    manufacturer,
    activeIngredients,
    prescriptionClassification,
    officialSourceName,
    sourceUrl,
    lastCheckedDate,
    pharmacistNotes: String(
      doc.pharmacistNotes || doc.educationalInfo || doc.description || doc.overview || doc.notes || ''
    ).trim(),
    commonUses,
    warnings,
    verified,
    sourceLabel: verified
      ? officialSourceName
        ? `Verified via ${officialSourceName}`
        : 'Medi_Bridge Verified Medicine Record'
      : 'Medi_Bridge Unverified Medicine Record',
    verifiedBy: doc.verifiedBy ? String(doc.verifiedBy) : verified ? 'Medi_Bridge Pharmacist Panel' : undefined,
    verifiedDate: doc.verifiedDate ? String(doc.verifiedDate) : lastCheckedDate,
  };
}

export async function getDatabaseStatus(forceRetry = false): Promise<DatabaseStatus> {
  const rawEnv = process.env.MONGODB_URI || '';
  const uri = getCleanedMongoUri();
  const dbName = getConfiguredDbName();
  const uriDiagnostics = uri ? inspectMongoUriSafely(rawEnv, uri) : undefined;
  const envVarsDetected = {
    mongodbUriSet: Boolean(uri),
    mongodbUriScheme: getUriScheme(uri),
    mongodbDbName: dbName,
    uriDiagnostics,
  };

  const db = await getMediBridgeDb(forceRetry);
  const preview = readPreviewStore();

  if (!db) {
    const classified = classifyConnectionError(lastConnectionError, Boolean(uri), uriDiagnostics);
    return {
      connected: false,
      databaseName: dbName,
      mode: 'preview',
      collections: [],
      counts: {
        hospitals: 0,
        doctors: 0,
        medicines: 0,
        healthTopics: 0,
        patients: preview.patients.length,
        appointments: preview.appointments.length,
      },
      envVarsDetected,
      errorCategory: classified.errorCategory,
      diagnosticHint: classified.diagnosticHint,
      message: lastConnectionError || 'Configure MONGODB_URI in Settings > Secrets to connect your Medi_Bridge MongoDB Atlas database.',
    };
  }

  try {
    const existing = await db.listCollections({}, { nameOnly: true }).toArray();
    const collections = existing.map((c) => c.name);

    const [hCol, dCol, mCol, tCol, pCol, aCol] = await Promise.all([
      resolveCollection(db, ['hospitals', 'Hospitals', 'hospital', 'facilities']),
      resolveCollection(db, ['doctors', 'Doctors', 'doctor', 'practitioners']),
      resolveCollection(db, ['MedicineInfo', 'medicineInfo', 'medicine_info', 'medicines', 'Medicines', 'medicine', 'drugs']),
      resolveCollection(db, ['health_topics', 'healthTopics', 'HealthTopics', 'topics']),
      resolveCollection(db, ['patients', 'Patients', 'patient']),
      resolveCollection(db, ['appointments', 'Appointments', 'appointment']),
    ]);

    const [hCount, dCount, mCount, tCount, pCount, aCount] = await Promise.all([
      hCol ? hCol.countDocuments() : Promise.resolve(0),
      dCol ? dCol.countDocuments() : Promise.resolve(0),
      mCol ? mCol.countDocuments() : Promise.resolve(0),
      tCol ? tCol.countDocuments() : Promise.resolve(0),
      pCol ? pCol.countDocuments() : Promise.resolve(0),
      aCol ? aCol.countDocuments() : Promise.resolve(0),
    ]);

    return {
      connected: true,
      databaseName: dbName,
      mode: 'mongodb',
      collections,
      counts: {
        hospitals: hCount,
        doctors: dCount,
        medicines: mCount,
        healthTopics: tCount,
        patients: pCount,
        appointments: aCount,
      },
      envVarsDetected,
      errorCategory: null,
      diagnosticHint: null,
      message: `Connected to MongoDB Atlas database "${dbName}" (existing records preserved).`,
    };
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : 'Unable to query Medi_Bridge collections.';
    const classified = classifyConnectionError(errMsg, Boolean(uri), uriDiagnostics);
    return {
      connected: false,
      databaseName: dbName,
      mode: 'preview',
      collections: [],
      counts: {
        hospitals: 0,
        doctors: 0,
        medicines: 0,
        healthTopics: 0,
        patients: preview.patients.length,
        appointments: preview.appointments.length,
      },
      envVarsDetected,
      errorCategory: classified.errorCategory,
      diagnosticHint: classified.diagnosticHint,
      message: errMsg,
    };
  }
}

const VERIFIED_DOC_FILTER: Document = {
  $or: [
    { verified: true },
    { isVerified: true },
    { is_verified: true },
    { verificationStatus: { $in: ['verified', 'Verified', 'approved', 'Approved'] } },
    { verification_status: { $in: ['verified', 'Verified', 'approved', 'Approved'] } },
  ],
};

export async function searchHospitalsInDb(
  filters: {
    q?: string;
    state?: string;
    district?: string;
    city?: string;
    pinCode?: string;
    facilityType?: string;
  },
  statusFilter: 'all' | 'verified' | 'unverified' = 'all'
): Promise<{
  verified: HospitalRecord[];
  unverified: HospitalRecord[];
  databaseConnected: boolean;
  availableStates: string[];
  availableFacilityTypes: string[];
}> {
  const db = await getMediBridgeDb();
  if (!db) {
    return {
      verified: [],
      unverified: [],
      databaseConnected: false,
      availableStates: [],
      availableFacilityTypes: [],
    };
  }

  const col = await resolveCollection(db, ['hospitals', 'Hospitals', 'hospital', 'facilities']);
  if (!col) {
    return {
      verified: [],
      unverified: [],
      databaseConnected: true,
      availableStates: [],
      availableFacilityTypes: [],
    };
  }

  const andClauses: Document[] = [];

  if (filters.state) {
    const cleanState = filters.state.trim();
    const rx = { $regex: escapeRegex(cleanState), $options: 'i' };
    if (/^delhi$/i.test(cleanState)) {
      andClauses.push({
        $or: [
          { state: rx },
          { city: rx },
          { district: rx },
          { address: rx },
        ],
      });
    } else if (/dadra.*daman/i.test(cleanState)) {
      andClauses.push({
        state: { $regex: 'Dadra|Daman|Diu', $options: 'i' },
      });
    } else {
      andClauses.push({ state: rx });
    }
  }
  if (filters.district) {
    const rx = { $regex: escapeRegex(filters.district), $options: 'i' };
    andClauses.push({ $or: [{ district: rx }, { taluk: rx }, { subdistrict: rx }] });
  }
  if (filters.city) {
    const rx = { $regex: escapeRegex(filters.city), $options: 'i' };
    andClauses.push({
      $or: [
        { city: rx },
        { town: rx },
        { address: rx },
        { district: rx },
        { location: rx },
        { subdistrict: rx },
        { block: rx },
        { name: rx },
      ],
    });
  }
  if (filters.pinCode) {
    const rx = { $regex: escapeRegex(filters.pinCode), $options: 'i' };
    andClauses.push({ $or: [{ pinCode: rx }, { pincode: rx }, { pin: rx }, { postalCode: rx }] });
  }
  if (filters.facilityType) {
    const cleanType = filters.facilityType.trim();
    const rx = { $regex: escapeRegex(cleanType), $options: 'i' };
    if (/government hospital|public/i.test(cleanType)) {
      andClauses.push({
        $or: [
          { facilityType: rx },
          { facilityType: { $regex: 'public|government', $options: 'i' } },
          { type: rx },
          { category: rx },
          { hospitalType: rx },
        ],
      });
    } else {
      andClauses.push({ $or: [{ facilityType: rx }, { type: rx }, { category: rx }, { hospitalType: rx }] });
    }
  }
  if (filters.q) {
    const rx = { $regex: escapeRegex(filters.q), $options: 'i' };
    andClauses.push({
      $or: [
        { name: rx },
        { hospitalName: rx },
        { hospital_name: rx },
        { address: rx },
        { city: rx },
        { district: rx },
        { state: rx },
        { pinCode: rx },
        { pincode: rx },
        { facilityType: rx },
      ],
    });
  }

  const verifiedQuery: Document = { $and: [...andClauses, VERIFIED_DOC_FILTER] };
  const unverifiedQuery: Document = { $and: [...andClauses, { $nor: [VERIFIED_DOC_FILTER] }] };

  const [verifiedDocs, unverifiedDocs, statesRaw, typesRaw] = await Promise.all([
    statusFilter === 'unverified'
      ? Promise.resolve([] as Document[])
      : col.find(verifiedQuery).sort({ _id: -1 }).limit(100).toArray(),
    statusFilter === 'verified'
      ? Promise.resolve([] as Document[])
      : col.find(unverifiedQuery).sort({ _id: -1 }).limit(100).toArray(),
    col.distinct('state'),
    col.distinct('facilityType'),
  ]);

  return {
    verified: verifiedDocs.map(normalizeHospital),
    unverified: unverifiedDocs.map(normalizeHospital),
    databaseConnected: true,
    availableStates: statesRaw.map(String).filter((s) => Boolean(s) && s !== '0').sort(),
    availableFacilityTypes: typesRaw.map(String).filter((t) => Boolean(t) && t !== '0').sort(),
  };
}

export async function listHospitalsForAdmin(filters: {
  q?: string;
  state?: string;
  status?: 'all' | 'verified' | 'unverified';
  limit?: number;
}): Promise<{
  hospitals: HospitalRecord[];
  totalCount: number;
  verifiedCount: number;
  unverifiedCount: number;
  databaseConnected: boolean;
}> {
  const db = await getMediBridgeDb();
  if (!db) {
    return {
      hospitals: [],
      totalCount: 0,
      verifiedCount: 0,
      unverifiedCount: 0,
      databaseConnected: false,
    };
  }

  const col = await resolveCollection(db, ['hospitals', 'Hospitals', 'hospital', 'facilities']);
  if (!col) {
    return {
      hospitals: [],
      totalCount: 0,
      verifiedCount: 0,
      unverifiedCount: 0,
      databaseConnected: true,
    };
  }

  const andClauses: Document[] = [];
  if (filters.state) {
    andClauses.push({ state: { $regex: escapeRegex(filters.state), $options: 'i' } });
  }
  if (filters.q) {
    const rx = { $regex: escapeRegex(filters.q), $options: 'i' };
    andClauses.push({
      $or: [
        { name: rx },
        { hospitalName: rx },
        { hospital_name: rx },
        { address: rx },
        { city: rx },
        { district: rx },
        { state: rx },
        { pinCode: rx },
        { pincode: rx },
        { sourceId: rx },
      ],
    });
  }

  if (filters.status === 'verified') {
    andClauses.push(VERIFIED_DOC_FILTER);
  } else if (filters.status === 'unverified') {
    andClauses.push({ $nor: [VERIFIED_DOC_FILTER] });
  }

  const query = andClauses.length > 0 ? { $and: andClauses } : {};
  const safeLimit = Math.min(Math.max(Number(filters.limit) || 40, 1), 100);

  const [docs, totalCount, verifiedCount] = await Promise.all([
    col.find(query).sort({ _id: -1 }).limit(safeLimit).toArray(),
    col.countDocuments(),
    col.countDocuments(VERIFIED_DOC_FILTER),
  ]);

  return {
    hospitals: docs.map(normalizeHospital),
    totalCount,
    verifiedCount,
    unverifiedCount: Math.max(0, totalCount - verifiedCount),
    databaseConnected: true,
  };
}

export async function updateHospitalVerificationStatus(input: {
  id: string;
  verified: boolean;
  checkedOfficialSource?: boolean;
  officialSourceName?: string;
  officialSourceUrl?: string;
  verificationNotes?: string;
  verifiedBy?: string;
}): Promise<HospitalRecord | null> {
  const db = await getMediBridgeDb();
  if (!db) {
    throw new Error('MongoDB Atlas (Medi_Bridge) is not connected.');
  }

  const col = await resolveCollection(db, ['hospitals', 'Hospitals', 'hospital', 'facilities']);
  if (!col) {
    throw new Error('Hospitals collection not found in Medi_Bridge.');
  }

  if (input.verified) {
    if (!input.checkedOfficialSource) {
      throw new Error('Admin must confirm that hospital details were checked against an official source.');
    }
    if (!input.officialSourceName || input.officialSourceName.trim().length < 3) {
      throw new Error('Provide the official source name used to verify this hospital.');
    }
  }

  let validatedUrl: string | undefined;
  if (input.officialSourceUrl && input.officialSourceUrl.trim()) {
    validatedUrl = sanitizeHttpUrl(input.officialSourceUrl);
    if (!validatedUrl) {
      throw new Error('Official source URL must begin with http:// or https://.');
    }
  }

  const idFilter: Document = ObjectId.isValid(input.id)
    ? { $or: [{ _id: new ObjectId(input.id) }, { _id: input.id as unknown as ObjectId }] }
    : { _id: input.id as unknown as ObjectId };

  const now = new Date().toISOString();
  const updateFields: Document = input.verified
    ? {
        verified: true,
        isVerified: true,
        verificationStatus: 'verified',
        officialSourceName: input.officialSourceName!.trim(),
        ...(validatedUrl ? { officialSourceUrl: validatedUrl } : {}),
        ...(input.verificationNotes?.trim() ? { verificationNotes: input.verificationNotes.trim() } : {}),
        verifiedBy: input.verifiedBy || 'Authorized MediBridge Admin',
        verifiedAt: now,
      }
    : {
        verified: false,
        isVerified: false,
        verificationStatus: 'unverified',
        ...(input.verificationNotes?.trim() ? { verificationNotes: input.verificationNotes.trim() } : {}),
        unverifiedAt: now,
      };

  const updatedDoc = await col.findOneAndUpdate(
    idFilter,
    { $set: updateFields },
    { returnDocument: 'after' }
  );

  if (!updatedDoc) {
    return null;
  }

  return normalizeHospital(updatedDoc);
}

export async function searchDoctorsInDb(filters: {
  q?: string;
  specialty?: string;
  hospital?: string;
  city?: string;
  state?: string;
}): Promise<{
  verified: DoctorRecord[];
  unverified: DoctorRecord[];
  databaseConnected: boolean;
  availableSpecialties: string[];
}> {
  const db = await getMediBridgeDb();
  if (!db) {
    return {
      verified: [],
      unverified: [],
      databaseConnected: false,
      availableSpecialties: [],
    };
  }

  const col = await resolveCollection(db, ['doctors', 'Doctors', 'doctor', 'practitioners']);
  if (!col) {
    return {
      verified: [],
      unverified: [],
      databaseConnected: true,
      availableSpecialties: [],
    };
  }

  const andClauses: Document[] = [];
  if (filters.specialty) {
    const rx = { $regex: escapeRegex(filters.specialty), $options: 'i' };
    andClauses.push({ $or: [{ specialty: rx }, { speciality: rx }, { department: rx }] });
  }
  if (filters.hospital) {
    const rx = { $regex: escapeRegex(filters.hospital), $options: 'i' };
    andClauses.push({ $or: [{ hospitalAffiliation: rx }, { hospitalName: rx }, { hospital: rx }] });
  }
  if (filters.city) {
    const rx = { $regex: escapeRegex(filters.city), $options: 'i' };
    andClauses.push({ city: rx });
  }
  if (filters.state) {
    const rx = { $regex: escapeRegex(filters.state), $options: 'i' };
    andClauses.push({ state: rx });
  }
  if (filters.q) {
    const rx = { $regex: escapeRegex(filters.q), $options: 'i' };
    andClauses.push({
      $or: [
        { name: rx },
        { doctorName: rx },
        { fullName: rx },
        { specialty: rx },
        { speciality: rx },
        { hospitalAffiliation: rx },
        { hospitalName: rx },
        { city: rx },
      ],
    });
  }

  const verifiedQuery: Document = { $and: [...andClauses, VERIFIED_DOC_FILTER] };
  const unverifiedQuery: Document = { $and: [...andClauses, { $nor: [VERIFIED_DOC_FILTER] }] };

  const [verifiedDocs, unverifiedDocs, specialtiesRaw] = await Promise.all([
    col.find(verifiedQuery).sort({ _id: -1 }).limit(100).toArray(),
    col.find(unverifiedQuery).sort({ _id: -1 }).limit(100).toArray(),
    col.distinct('specialty'),
  ]);

  return {
    verified: verifiedDocs.map(normalizeDoctor),
    unverified: unverifiedDocs.map(normalizeDoctor),
    databaseConnected: true,
    availableSpecialties: specialtiesRaw.map(String).filter(Boolean).sort(),
  };
}

interface ParsedStrengthToken {
  raw: string;
  num: string;
  unit: string;
}

const FORMULATION_CANONICAL_MAP: Record<string, string> = {
  tablet: 'tablet',
  tablets: 'tablet',
  tab: 'tablet',
  tabs: 'tablet',
  capsule: 'capsule',
  capsules: 'capsule',
  cap: 'capsule',
  caps: 'capsule',
  syrup: 'syrup',
  syrups: 'syrup',
  syp: 'syrup',
  suspension: 'suspension',
  susp: 'suspension',
  injection: 'injection',
  injections: 'injection',
  inj: 'injection',
  drop: 'drops',
  drops: 'drops',
  ointment: 'ointment',
  cream: 'cream',
  gel: 'gel',
  inhaler: 'inhaler',
  powder: 'powder',
  sachet: 'sachet',
  solution: 'solution',
};

const MEDICINE_SPELLING_ALIASES: Record<string, string[]> = {
  paracetamol: ['acetaminophen', 'pcm'],
  acetaminophen: ['paracetamol'],
  pcm: ['paracetamol'],
  amoxicillin: ['amoxycillin'],
  amoxycillin: ['amoxicillin'],
  azithromycin: ['azithromycine'],
  azithromycine: ['azithromycin'],
  cetirizine: ['cetrizine', 'ceterizine'],
  cetrizine: ['cetirizine'],
  ceterizine: ['cetirizine'],
  levocetirizine: ['levocetrizine', 'levoceterizine'],
  levocetrizine: ['levocetirizine'],
  levoceterizine: ['levocetirizine'],
  pantoprazole: ['pantaprazole'],
  pantaprazole: ['pantoprazole'],
  omeprazole: ['omeprazol'],
  omeprazol: ['omeprazole'],
  rabeprazole: ['rabiprazole'],
  rabiprazole: ['rabeprazole'],
  metformin: ['metformine'],
  metformine: ['metformin'],
  atorvastatin: ['atorvastatine'],
  atorvastatine: ['atorvastatin'],
  montelukast: ['montelucast'],
  montelucast: ['montelukast'],
  amlodipine: ['amlodipin'],
  amlodipin: ['amlodipine'],
  ibuprofen: ['ibuprophen'],
  ibuprophen: ['ibuprofen'],
  'ascorbic acid': ['vitamin c'],
  'vitamin c': ['ascorbic acid'],
  cholecalciferol: ['vitamin d3'],
  'vitamin d3': ['cholecalciferol'],
  'vitamin d': ['vitamin d3', 'cholecalciferol'],
  folate: ['folic acid'],
  'folic acid': ['folate'],
};

const STANDALONE_STRENGTH_NUMBERS = new Set([
  '50', '75', '100', '125', '150', '200', '250', '300', '325', '400', '500', '600', '625', '650', '750', '850', '1000',
]);

function normalizeTextForMatch(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9.+]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function levenshteinDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (Math.abs(m - n) > 2) return 3;
  const dp: number[] = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= n; j++) {
      const temp = dp[j];
      if (a[i - 1] === b[j - 1]) {
        dp[j] = prev;
      } else {
        dp[j] = 1 + Math.min(prev, dp[j], dp[j - 1]);
      }
      prev = temp;
    }
  }
  return dp[n];
}

function parseMedicineQuery(rawQuery: string): {
  cleanQuery: string;
  normalizedQuery: string;
  strengths: ParsedStrengthToken[];
  formulations: string[];
  nameTokens: string[];
  expandedNameTerms: string[];
} {
  const cleanQuery = rawQuery.replace(/\s+/g, ' ').trim();
  const normalizedQuery = normalizeTextForMatch(cleanQuery);
  const strengths: ParsedStrengthToken[] = [];
  const formulations: string[] = [];

  let remainder = ` ${cleanQuery.toLowerCase()} `;
  // Extract strength+unit patterns like "500mg", "500 mg", "1 g", "5 ml"
  remainder = remainder.replace(/\b(\d+(?:\.\d+)?)\s*(mg|mcg|g|gm|ml|iu|%)\b/gi, (_m, num: string, unit: string) => {
    const cleanNum = num.trim();
    const cleanUnit = unit.toLowerCase();
    strengths.push({ raw: `${cleanNum}${cleanUnit}`, num: cleanNum, unit: cleanUnit });
    return ' ';
  });

  const rawTokens = normalizeTextForMatch(remainder).split(' ').filter(Boolean);
  const nameTokens: string[] = [];

  for (const tok of rawTokens) {
    if (FORMULATION_CANONICAL_MAP[tok]) {
      const canon = FORMULATION_CANONICAL_MAP[tok];
      if (!formulations.includes(canon)) formulations.push(canon);
      continue;
    }
    if (/^\d+(?:\.\d+)?$/.test(tok) && (STANDALONE_STRENGTH_NUMBERS.has(tok) || nameTokens.length > 0)) {
      // Treat standalone numbers like "650" in "Dolo 650" or "500" in "Paracetamol 500" as strength hints,
      // unless it's part of a vitamin/brand code like D3
      strengths.push({ raw: tok, num: tok, unit: '' });
      continue;
    }
    if (!nameTokens.includes(tok)) {
      nameTokens.push(tok);
    }
  }

  const expandedSet = new Set<string>();
  const joinedName = nameTokens.join(' ');
  if (joinedName) {
    expandedSet.add(joinedName);
    for (const alias of MEDICINE_SPELLING_ALIASES[joinedName] || []) {
      expandedSet.add(alias);
    }
  }
  for (const tok of nameTokens) {
    expandedSet.add(tok);
    for (const alias of MEDICINE_SPELLING_ALIASES[tok] || []) {
      expandedSet.add(alias);
    }
  }
  if (strengths.length > 0 && nameTokens.length === 0) {
    for (const s of strengths) {
      expandedSet.add(s.num);
    }
  }

  return {
    cleanQuery,
    normalizedQuery,
    strengths,
    formulations,
    nameTokens,
    expandedNameTerms: Array.from(expandedSet).filter(Boolean),
  };
}

function extractRecordStrengths(med: MedicineDatabaseRecord): ParsedStrengthToken[] {
  const combined = [med.strength || '', med.dosageForms || '', med.name, ...med.brandNames].join(' ');
  const found: ParsedStrengthToken[] = [];
  const seen = new Set<string>();

  const withUnit = combined.matchAll(/\b(\d+(?:\.\d+)?)\s*(mg|mcg|g|gm|ml|iu|%)\b/gi);
  for (const m of withUnit) {
    const key = `${m[1]}:${m[2].toLowerCase()}`;
    if (!seen.has(key)) {
      seen.add(key);
      found.push({ raw: `${m[1]}${m[2].toLowerCase()}`, num: m[1], unit: m[2].toLowerCase() });
    }
  }

  // Also check standalone 2-4 digit strength numbers on brand/name (e.g. "Dolo 650") unless attached to letters like "D3"
  const standaloneNums = combined.matchAll(/(?:^|\s)(\d{2,4})(?=\s|$)/g);
  for (const m of standaloneNums) {
    const num = m[1];
    if (!found.some((f) => f.num === num)) {
      found.push({ raw: num, num, unit: '' });
    }
  }

  return found;
}

function extractRecordFormulations(med: MedicineDatabaseRecord): string[] {
  const combined = normalizeTextForMatch([med.dosageForms || '', med.name, ...med.brandNames].join(' '));
  const found: string[] = [];
  for (const word of combined.split(' ')) {
    const canon = FORMULATION_CANONICAL_MAP[word];
    if (canon && !found.includes(canon)) {
      found.push(canon);
    }
  }
  return found;
}

export async function searchMedicinesInDb(query: string): Promise<{
  verified: MedicineDatabaseRecord[];
  unverified: MedicineDatabaseRecord[];
  exactMatchesCount: number;
  relatedMatchesCount: number;
  searchSummary: string;
  databaseConnected: boolean;
}> {
  const parsed = parseMedicineQuery(query);
  const db = await getMediBridgeDb();
  if (!db) {
    return {
      verified: [],
      unverified: [],
      exactMatchesCount: 0,
      relatedMatchesCount: 0,
      searchSummary: '',
      databaseConnected: false,
    };
  }
  if (!parsed.cleanQuery) {
    return {
      verified: [],
      unverified: [],
      exactMatchesCount: 0,
      relatedMatchesCount: 0,
      searchSummary: '',
      databaseConnected: true,
    };
  }

  const existing = await db.listCollections({}, { nameOnly: true }).toArray();
  const names = existing.map((c) => c.name);
  const candidateNames = ['MedicineInfo', 'medicineInfo', 'medicine_info', 'medicines', 'Medicines', 'medicine', 'drugs'];
  const matchedCols = candidateNames
    .map((cand) => names.find((n) => n.toLowerCase() === cand.toLowerCase()))
    .filter((v, idx, arr): v is string => Boolean(v) && arr.indexOf(v) === idx);

  if (matchedCols.length === 0) {
    return {
      verified: [],
      unverified: [],
      exactMatchesCount: 0,
      relatedMatchesCount: 0,
      searchSummary: 'No medicine collection found in Medi_Bridge.',
      databaseConnected: true,
    };
  }

  const VERIFIED_MED_FILTER: Document = {
    $or: [
      { verified: true },
      { pharmacistVerified: true },
      { isVerified: true },
      { is_verified: true },
      { verificationStatus: { $in: ['verified', 'Verified', 'approved', 'Approved'] } },
    ],
  };

  const searchTerms = Array.from(
    new Set([
      ...parsed.expandedNameTerms,
      ...parsed.strengths.map((s) => s.num),
      ...parsed.formulations,
    ])
  ).filter(Boolean);

  const searchableFields = [
    'name',
    'medicineName',
    'title',
    'brandName',
    'brandNames',
    'brands',
    'genericName',
    'composition',
    'activeIngredient',
    'activeIngredients',
    'salt',
    'aliases',
    'keywords',
    'manufacturer',
    'medicineCategory',
    'strength',
    'dosageForms',
    'dosageForm',
    'form',
    'formulation',
    'drugClass',
    'category',
  ];

  const orClauses: Document[] = [];
  for (const term of searchTerms) {
    const rx = { $regex: escapeRegex(term), $options: 'i' };
    for (const field of searchableFields) {
      orClauses.push({ [field]: rx });
    }
  }

  const verifiedCollected: Array<{ doc: Document; aliases?: string[] }> = [];
  const unverifiedCollected: Array<{ doc: Document; aliases?: string[] }> = [];

  const textSearchString = Array.from(
    new Set([
      ...parsed.expandedNameTerms,
      ...parsed.strengths.map((s) => s.raw),
    ])
  )
    .join(' ')
    .trim();

  for (const colName of matchedCols) {
    const col = db.collection(colName);
    let usedTextIndex = false;

    if (textSearchString) {
      try {
        const [vTextDocs, uTextDocs] = await Promise.all([
          col
            .find(
              { $text: { $search: textSearchString }, ...VERIFIED_MED_FILTER },
              { projection: { score: { $meta: 'textScore' } } }
            )
            .sort({ score: { $meta: 'textScore' } })
            .limit(40)
            .toArray(),
          col
            .find(
              { $text: { $search: textSearchString }, $nor: [VERIFIED_MED_FILTER] },
              { projection: { score: { $meta: 'textScore' } } }
            )
            .sort({ score: { $meta: 'textScore' } })
            .limit(80)
            .toArray(),
        ]);
        for (const d of vTextDocs) verifiedCollected.push({ doc: d });
        for (const d of uTextDocs) unverifiedCollected.push({ doc: d });
        usedTextIndex = true;
      } catch {
        // Text index not yet built — fall back to regex queries cleanly
      }
    }

    // Also run targeted regex queries when $text didn't find enough matches (e.g. partial prefixes like "Paracet", "Cip")
    if (!usedTextIndex || (verifiedCollected.length === 0 && unverifiedCollected.length < 15)) {
      const regexFilter = orClauses.length > 0 ? { $or: orClauses } : {};
      const [vRxDocs, uRxDocs] = await Promise.all([
        col.find({ $and: [regexFilter, VERIFIED_MED_FILTER] }).limit(40).toArray(),
        col.find({ $and: [regexFilter, { $nor: [VERIFIED_MED_FILTER] }] }).limit(80).toArray(),
      ]);
      for (const d of vRxDocs) verifiedCollected.push({ doc: d });
      for (const d of uRxDocs) unverifiedCollected.push({ doc: d });
    }

    // Spelling-typo fallback using 4-char prefix scan if nothing matched yet
    if (
      verifiedCollected.length === 0 &&
      unverifiedCollected.length === 0 &&
      parsed.nameTokens.some((t) => t.length >= 5)
    ) {
      const prefixClauses: Document[] = [];
      for (const tok of parsed.nameTokens) {
        if (tok.length >= 5) {
          const p3 = { $regex: `^${escapeRegex(tok.slice(0, 4))}`, $options: 'i' };
          prefixClauses.push({ brandName: p3 }, { genericName: p3 }, { name: p3 }, { manufacturer: p3 });
        }
      }
      const prefixFilter = prefixClauses.length > 0 ? { $or: prefixClauses } : {};
      const [vTypoDocs, uTypoDocs] = await Promise.all([
        col.find({ $and: [prefixFilter, VERIFIED_MED_FILTER] }).limit(40).toArray(),
        col.find({ $and: [prefixFilter, { $nor: [VERIFIED_MED_FILTER] }] }).limit(120).toArray(),
      ]);
      for (const d of vTypoDocs) verifiedCollected.push({ doc: d });
      for (const d of uTypoDocs) unverifiedCollected.push({ doc: d });
    }
  }

  const candidateDocs = [...verifiedCollected, ...unverifiedCollected].map((entry) => entry.doc);

  const seenIds = new Set<string>();
  const normalizedCandidates: Array<{ med: MedicineDatabaseRecord; rawAliases: string[] }> = [];
  for (const rawDoc of candidateDocs) {
    const med = normalizeMedicine(rawDoc);
    if (!seenIds.has(med.id)) {
      seenIds.add(med.id);
      normalizedCandidates.push({
        med,
        rawAliases: asStringArray(rawDoc.aliases),
      });
    }
  }

  interface ScoredMedicine {
    record: MedicineDatabaseRecord;
    isExact: boolean;
    strengthRank: number; // 3 = exact strength match, 2 = unspecified in DB, 1 = different strength
    formRank: number;     // 3 = exact formulation match, 2 = unspecified in DB, 1 = different formulation
    nameRank: number;     // 4 = exact brand/generic/manufacturer, 3 = all tokens match, 2 = partial/alias, 1 = spelling typo
  }

  const scored: ScoredMedicine[] = [];

  for (const { med, rawAliases } of normalizedCandidates) {
    const medNameNorm = normalizeTextForMatch(med.name);
    const medGenericNorm = normalizeTextForMatch(med.genericName);
    const medManufacturerNorm = normalizeTextForMatch(med.manufacturer || '');
    const medBrandsNorm = med.brandNames.map(normalizeTextForMatch);
    const medAllText = normalizeTextForMatch(
      [
        med.name,
        med.genericName,
        ...med.brandNames,
        ...rawAliases,
        med.activeIngredients || '',
        med.manufacturer || '',
        med.medicineCategory || '',
        med.strength || '',
        med.dosageForms || '',
      ].join(' ')
    );
    const medWords = medAllText.split(' ').filter(Boolean);

    // 1. Evaluate name/alias/manufacturer/fuzzy match
    let nameRank = 0;
    const joinedQueryName = parsed.nameTokens.join(' ');
    const queryAliasPool = parsed.expandedNameTerms;

    if (
      joinedQueryName &&
      (medNameNorm === joinedQueryName ||
        medGenericNorm === joinedQueryName ||
        medManufacturerNorm === joinedQueryName ||
        medBrandsNorm.includes(joinedQueryName))
    ) {
      nameRank = 4;
    } else if (
      queryAliasPool.some(
        (term) =>
          medNameNorm === term ||
          medGenericNorm === term ||
          medManufacturerNorm === term ||
          medBrandsNorm.includes(term)
      )
    ) {
      nameRank = 3;
    } else if (
      parsed.nameTokens.length > 0 &&
      parsed.nameTokens.every((tok) => {
        const variants = [tok, ...(MEDICINE_SPELLING_ALIASES[tok] || [])];
        return variants.some((v) => medAllText.includes(v));
      })
    ) {
      nameRank = 3;
    } else if (
      (() => {
        const MODIFIER_WORDS = new Set([
          'acid',
          'sulfate',
          'sulphate',
          'carbonate',
          'chloride',
          'sodium',
          'potassium',
          'oxide',
          'hydroxide',
          'maleate',
          'tartrate',
          'hcl',
        ]);
        const significantTerms = parsed.expandedNameTerms.filter(
          (term) => term.length >= 3 && !MODIFIER_WORDS.has(term)
        );
        const pool = significantTerms.length > 0 ? significantTerms : parsed.expandedNameTerms;
        return pool.some((term) => term.length >= 3 && medAllText.includes(term));
      })()
    ) {
      nameRank = 2;
    } else if (
      parsed.nameTokens.some((tok) => {
        if (tok.length < 5) return false;
        const maxDist = tok.length >= 8 ? 2 : 1;
        return medWords.some((w) => w.length >= 4 && levenshteinDistance(tok, w) <= maxDist);
      })
    ) {
      nameRank = 1;
    }

    // If user searched ONLY a strength (e.g., "650" or "500mg") with no name tokens:
    if (parsed.nameTokens.length === 0 && parsed.strengths.length > 0) {
      const recStrengths = extractRecordStrengths(med);
      const strengthMatches = parsed.strengths.some((qs) =>
        recStrengths.some((rs) => rs.num === qs.num && (!qs.unit || !rs.unit || qs.unit === rs.unit))
      );
      if (strengthMatches) {
        nameRank = 2;
      }
    }

    if (nameRank === 0) {
      continue;
    }

    // 2. Evaluate strength match when user requested a strength
    const recStrengths = extractRecordStrengths(med);
    let strengthRank = 3;
    let strengthNote = '';
    if (parsed.strengths.length > 0) {
      const matched = parsed.strengths.every((qs) =>
        recStrengths.some((rs) => rs.num === qs.num && (!qs.unit || !rs.unit || qs.unit === rs.unit))
      );
      if (matched) {
        strengthRank = 3;
      } else if (recStrengths.length === 0) {
        strengthRank = 2;
        strengthNote = `Strength (${parsed.strengths.map((s) => s.raw).join(', ')}) is not recorded on this database entry.`;
      } else {
        strengthRank = 1;
        strengthNote = `Lists strength ${recStrengths.map((s) => s.raw).join(', ')} rather than ${parsed.strengths.map((s) => s.raw).join(', ')} (related ${med.genericName || med.name} record).`;
      }
    }

    // 3. Evaluate formulation match when user requested a formulation (tablet, syrup, capsule, etc.)
    const recForms = extractRecordFormulations(med);
    let formRank = 3;
    let formNote = '';
    if (parsed.formulations.length > 0) {
      const matched = parsed.formulations.some((qf) => recForms.includes(qf));
      if (matched) {
        formRank = 3;
      } else if (recForms.length === 0) {
        formRank = 2;
        formNote = `Formulation (${parsed.formulations.join(', ')}) is not recorded on this database entry.`;
      } else {
        formRank = 1;
        formNote = `Lists formulation ${recForms.join(', ')} rather than ${parsed.formulations.join(', ')}.`;
      }
    }

    const isExact = nameRank >= 3 && strengthRank === 3 && formRank === 3;
    const notes: string[] = [];
    if (!isExact) {
      if (nameRank === 1) {
        notes.push('Matched via close spelling similarity.');
      } else if (nameRank === 2) {
        notes.push('Partial name or ingredient match.');
      }
      if (strengthNote) notes.push(strengthNote);
      if (formNote) notes.push(formNote);
    }

    const enriched: MedicineDatabaseRecord = {
      ...med,
      matchType: isExact ? 'exact' : 'related',
      matchNote: notes.length > 0 ? notes.join(' ') : undefined,
    };

    scored.push({
      record: enriched,
      isExact,
      strengthRank,
      formRank,
      nameRank,
    });
  }

  scored.sort((a, b) => {
    if (a.isExact !== b.isExact) return a.isExact ? -1 : 1;
    if (a.strengthRank !== b.strengthRank) return b.strengthRank - a.strengthRank;
    if (a.formRank !== b.formRank) return b.formRank - a.formRank;
    if (a.nameRank !== b.nameRank) return b.nameRank - a.nameRank;
    const aDirect = normalizeTextForMatch(a.record.name) === parsed.nameTokens.join(' ') ? 1 : 0;
    const bDirect = normalizeTextForMatch(b.record.name) === parsed.nameTokens.join(' ') ? 1 : 0;
    if (aDirect !== bDirect) return bDirect - aDirect;
    return a.record.name.localeCompare(b.record.name);
  });

  const sortedRecords = scored.map((s) => s.record);
  const exactMatchesCount = sortedRecords.filter((r) => r.matchType === 'exact').length;
  const relatedMatchesCount = sortedRecords.filter((r) => r.matchType !== 'exact').length;

  let searchSummary = '';
  if (sortedRecords.length === 0) {
    searchSummary = `No matching medicine records were found for "${parsed.cleanQuery}" in Medi_Bridge MedicineInfo.`;
  } else if (exactMatchesCount === 0 && relatedMatchesCount > 0) {
    const requestedDetails = [
      ...parsed.strengths.map((s) => s.raw),
      ...parsed.formulations,
    ].join(' ');
    searchSummary = requestedDetails
      ? `No exact "${parsed.cleanQuery}" record with ${requestedDetails} exists in Medi_Bridge MedicineInfo. Showing ${relatedMatchesCount} related database ${relatedMatchesCount === 1 ? 'record' : 'records'} below.`
      : `No exact match for "${parsed.cleanQuery}" was found. Showing ${relatedMatchesCount} related database ${relatedMatchesCount === 1 ? 'record' : 'records'}.`;
  } else if (exactMatchesCount > 0 && relatedMatchesCount > 0) {
    searchSummary = `Found ${exactMatchesCount} exact ${exactMatchesCount === 1 ? 'match' : 'matches'} and ${relatedMatchesCount} related database ${relatedMatchesCount === 1 ? 'record' : 'records'} in Medi_Bridge MedicineInfo.`;
  } else {
    searchSummary = `Found ${exactMatchesCount} exact ${exactMatchesCount === 1 ? 'match' : 'matches'} in Medi_Bridge MedicineInfo.`;
  }

  return {
    verified: sortedRecords.filter((m) => m.verified),
    unverified: sortedRecords.filter((m) => !m.verified),
    exactMatchesCount,
    relatedMatchesCount,
    searchSummary,
    databaseConnected: true,
  };
}

export async function searchHealthTopicsInDb(query: string): Promise<{
  records: CuratedHealthTopic[];
  databaseConnected: boolean;
}> {
  const db = await getMediBridgeDb();
  if (!db) return { records: [], databaseConnected: false };

  const col = await resolveCollection(db, ['health_topics', 'healthTopics', 'HealthTopics', 'topics']);
  if (!col) return { records: [], databaseConnected: true };

  const rx = { $regex: escapeRegex(query), $options: 'i' };
  const docs = await col
    .find({
      $or: [{ title: rx }, { topic: rx }, { name: rx }, { category: rx }, { summary: rx }],
    })
    .limit(10)
    .toArray();

  return {
    records: docs.map((d) => ({
      id: String(d._id || crypto.randomUUID()),
      title: String(d.title || d.topic || d.name || query),
      category: String(d.category || 'General Health'),
      summary: String(d.summary || d.explanation || d.description || ''),
      verifiedBy: d.verifiedBy ? String(d.verifiedBy) : undefined,
    })),
    databaseConnected: true,
  };
}

export async function searchHealthTestsInDb(query: string): Promise<{
  records: CuratedTestRecord[];
  databaseConnected: boolean;
}> {
  const db = await getMediBridgeDb();
  if (!db) return { records: [], databaseConnected: false };

  const col = await resolveCollection(db, ['health_tests', 'medical_tests', 'lab_tests', 'tests']);
  if (!col) return { records: [], databaseConnected: true };

  const rx = { $regex: escapeRegex(query), $options: 'i' };
  const docs = await col
    .find({
      $or: [{ testName: rx }, { name: rx }, { aliases: rx }, { category: rx }],
    })
    .limit(10)
    .toArray();

  return {
    records: docs.map((d) => ({
      id: String(d._id || crypto.randomUUID()),
      testName: String(d.testName || d.name || query),
      category: String(d.category || 'Diagnostic Laboratory Test'),
      purpose: String(d.purpose || d.generalPurpose || d.description || ''),
    })),
    databaseConnected: true,
  };
}

export async function registerPatientRecord(input: {
  fullName: string;
  age: number;
  gender: string;
  phone: string;
  email?: string;
  bloodGroup?: string;
  emergencyContact?: string;
  address: string;
  city: string;
  district: string;
  state: string;
  pinCode: string;
  allergiesOrConditions?: string;
}): Promise<PatientRecord> {
  const db = await getMediBridgeDb();
  const year = new Date().getFullYear();
  const suffix = crypto.randomBytes(3).toString('hex').toUpperCase();
  const patientId = `MB-IN-${year}-${suffix}`;
  const createdAt = new Date().toISOString();

  const record: PatientRecord = {
    patientId,
    fullName: input.fullName,
    age: input.age,
    gender: input.gender,
    phone: input.phone,
    email: input.email || undefined,
    bloodGroup: input.bloodGroup || undefined,
    emergencyContact: input.emergencyContact || undefined,
    address: input.address,
    city: input.city,
    district: input.district,
    state: input.state,
    pinCode: input.pinCode,
    allergiesOrConditions: input.allergiesOrConditions || undefined,
    createdAt,
    storageMode: db ? 'mongodb' : 'preview',
  };

  if (db) {
    const col = await getOrCreateWriteCollection(db, ['patients', 'Patients', 'patient'], 'patients');
    await col.insertOne({ ...record });
    return record;
  }

  const store = readPreviewStore();
  store.patients.unshift(record);
  writePreviewStore(store);
  return record;
}

export async function lookupPatients(query: string): Promise<{
  patients: PatientRecord[];
  storageMode: 'mongodb' | 'preview';
}> {
  const db = await getMediBridgeDb();
  const cleanQuery = query.trim();

  if (db) {
    const col = await resolveCollection(db, ['patients', 'Patients', 'patient']);
    if (!col) return { patients: [], storageMode: 'mongodb' };

    const mongoFilter = cleanQuery
      ? {
          $or: [
            { patientId: { $regex: escapeRegex(cleanQuery), $options: 'i' } },
            { phone: { $regex: escapeRegex(cleanQuery), $options: 'i' } },
            { fullName: { $regex: escapeRegex(cleanQuery), $options: 'i' } },
          ],
        }
      : {};

    const docs = await col.find(mongoFilter).sort({ createdAt: -1 }).limit(25).toArray();
    return {
      patients: docs.map((d) => ({
        patientId: String(d.patientId || d._id),
        fullName: String(d.fullName || d.name || ''),
        age: Number(d.age || 0),
        gender: String(d.gender || ''),
        phone: String(d.mobileNumber || d.phone || ''),
        email: d.email ? String(d.email) : undefined,
        bloodGroup: d.bloodGroup ? String(d.bloodGroup) : undefined,
        emergencyContact: d.emergencyContact ? String(d.emergencyContact) : undefined,
        address: String(d.address || ''),
        city: String(d.city || ''),
        district: String(d.district || ''),
        state: String(d.state || ''),
        pinCode: String(d.pinCode || d.pincode || ''),
        allergiesOrConditions: d.allergiesOrConditions ? String(d.allergiesOrConditions) : undefined,
        createdAt: String(d.registrationDate || d.createdAt || new Date().toISOString()),
        storageMode: 'mongodb',
      })),
      storageMode: 'mongodb',
    };
  }

  const store = readPreviewStore();
  const filtered = cleanQuery
    ? store.patients.filter(
        (p) =>
          p.patientId.toLowerCase().includes(cleanQuery.toLowerCase()) ||
          p.phone.toLowerCase().includes(cleanQuery.toLowerCase()) ||
          p.fullName.toLowerCase().includes(cleanQuery.toLowerCase())
      )
    : store.patients;
  return { patients: filtered.slice(0, 25), storageMode: 'preview' };
}

export async function createAppointmentRequest(input: {
  patientId: string;
  hospitalName: string;
  hospitalCity?: string;
  doctorName?: string;
  specialty?: string;
  preferredDate: string;
  preferredWindow: string;
  visitType: 'In-Person' | 'Teleconsultation';
  reason: string;
}): Promise<AppointmentRecord> {
  const db = await getMediBridgeDb();
  const cleanPatientId = input.patientId.trim().toUpperCase();
  let matchedPatient: { patientId: string; fullName: string; phone: string } | null = null;

  if (db) {
    const col = await resolveCollection(db, ['patients', 'Patients', 'patient']);
    if (col) {
      const doc = await col.findOne({ patientId: cleanPatientId });
      if (doc) {
        matchedPatient = {
          patientId: String(doc.patientId || cleanPatientId),
          fullName: String(doc.fullName || ''),
          phone: String(doc.mobileNumber || doc.phone || ''),
        };
      }
    }
  } else {
    const lookup = await lookupPatients(cleanPatientId);
    const found = lookup.patients.find((p) => p.patientId.toUpperCase() === cleanPatientId);
    if (found) {
      matchedPatient = {
        patientId: found.patientId,
        fullName: found.fullName,
        phone: found.phone,
      };
    }
  }

  if (!matchedPatient) {
    throw new Error(`No registered patient found with Patient ID "${input.patientId}". Please register first.`);
  }

  const suffix = crypto.randomBytes(3).toString('hex').toUpperCase();
  const now = new Date().toISOString();
  const appointment: AppointmentRecord = {
    bookingRef: `MB-APT-${suffix}`,
    patientId: matchedPatient.patientId,
    patientName: matchedPatient.fullName,
    patientPhone: matchedPatient.phone,
    hospitalName: input.hospitalName,
    hospitalCity: input.hospitalCity || undefined,
    doctorName: input.doctorName || undefined,
    specialty: input.specialty || undefined,
    preferredDate: input.preferredDate,
    preferredWindow: input.preferredWindow,
    visitType: input.visitType,
    reason: input.reason,
    status: 'Requested',
    statusNote: 'Appointment request recorded. Final slot confirmation depends on direct facility verification.',
    createdAt: now,
    updatedAt: now,
    storageMode: db ? 'mongodb' : 'preview',
  };

  if (db) {
    const col = await getOrCreateWriteCollection(db, ['appointments', 'Appointments', 'appointment'], 'appointments');
    await col.insertOne({ ...appointment });
    return appointment;
  }

  const store = readPreviewStore();
  store.appointments.unshift(appointment);
  writePreviewStore(store);
  return appointment;
}

export async function listAppointments(filters: {
  patientId?: string;
  bookingRef?: string;
}): Promise<{
  appointments: AppointmentRecord[];
  storageMode: 'mongodb' | 'preview';
}> {
  const db = await getMediBridgeDb();

  if (db) {
    const col = await resolveCollection(db, ['appointments', 'Appointments', 'appointment']);
    if (!col) return { appointments: [], storageMode: 'mongodb' };

    const clauses: Document[] = [];
    if (filters.patientId) {
      clauses.push({ patientId: { $regex: escapeRegex(filters.patientId), $options: 'i' } });
    }
    if (filters.bookingRef) {
      clauses.push({ bookingRef: { $regex: escapeRegex(filters.bookingRef), $options: 'i' } });
    }

    const query = clauses.length > 0 ? { $and: clauses } : {};
    const docs = await col.find(query).sort({ createdAt: -1 }).limit(50).toArray();

    return {
      appointments: docs.map((d) => ({
        bookingRef: String(d.bookingRef || d._id),
        patientId: String(d.patientId || ''),
        patientName: String(d.patientName || ''),
        patientPhone: String(d.patientPhone || ''),
        hospitalName: String(d.hospitalName || ''),
        hospitalCity: d.hospitalCity ? String(d.hospitalCity) : undefined,
        doctorName: d.doctorName ? String(d.doctorName) : undefined,
        specialty: d.specialty ? String(d.specialty) : undefined,
        preferredDate: String(d.preferredDate || ''),
        preferredWindow: String(d.preferredWindow || ''),
        visitType: d.visitType === 'Teleconsultation' ? 'Teleconsultation' : 'In-Person',
        reason: String(d.reason || ''),
        status: (d.status as AppointmentStatus) || 'Requested',
        statusNote: String(d.statusNote || ''),
        createdAt: String(d.createdAt || ''),
        updatedAt: String(d.updatedAt || ''),
        storageMode: 'mongodb',
      })),
      storageMode: 'mongodb',
    };
  }

  const store = readPreviewStore();
  let items = store.appointments;
  if (filters.patientId) {
    const q = filters.patientId.toLowerCase();
    items = items.filter((a) => a.patientId.toLowerCase().includes(q));
  }
  if (filters.bookingRef) {
    const q = filters.bookingRef.toLowerCase();
    items = items.filter((a) => a.bookingRef.toLowerCase().includes(q));
  }
  return { appointments: items.slice(0, 50), storageMode: 'preview' };
}

export async function updateAppointmentStatus(
  bookingRef: string,
  status: AppointmentStatus,
  statusNote?: string
): Promise<AppointmentRecord | null> {
  const db = await getMediBridgeDb();
  const now = new Date().toISOString();
  const note =
    statusNote ||
    (status === 'Cancelled'
      ? 'Cancelled by patient (record preserved).'
      : `Status updated to ${status}.`);

  if (db) {
    const col = await resolveCollection(db, ['appointments', 'Appointments', 'appointment']);
    if (!col) return null;

    const result = await col.findOneAndUpdate(
      { bookingRef: bookingRef.trim() },
      { $set: { status, statusNote: note, updatedAt: now } },
      { returnDocument: 'after' }
    );
    if (!result) return null;
    return {
      bookingRef: String(result.bookingRef || result._id),
      patientId: String(result.patientId || ''),
      patientName: String(result.patientName || ''),
      patientPhone: String(result.patientPhone || ''),
      hospitalName: String(result.hospitalName || ''),
      hospitalCity: result.hospitalCity ? String(result.hospitalCity) : undefined,
      doctorName: result.doctorName ? String(result.doctorName) : undefined,
      specialty: result.specialty ? String(result.specialty) : undefined,
      preferredDate: String(result.preferredDate || ''),
      preferredWindow: String(result.preferredWindow || ''),
      visitType: result.visitType === 'Teleconsultation' ? 'Teleconsultation' : 'In-Person',
      reason: String(result.reason || ''),
      status: result.status as AppointmentStatus,
      statusNote: String(result.statusNote || ''),
      createdAt: String(result.createdAt || ''),
      updatedAt: String(result.updatedAt || ''),
      storageMode: 'mongodb',
    };
  }

  const store = readPreviewStore();
  const idx = store.appointments.findIndex((a) => a.bookingRef === bookingRef.trim());
  if (idx === -1) return null;
  store.appointments[idx] = {
    ...store.appointments[idx],
    status,
    statusNote: note,
    updatedAt: now,
  };
  writePreviewStore(store);
  return store.appointments[idx];
}

// --- Medicine Reminders (Authenticated User-Scoped) ---

const USER_DATA_PREVIEW_PATH = path.resolve('/tmp', 'medibridge_user_data_preview.json');

interface UserPreviewDataStore {
  reminders: MedicineReminderRecord[];
  emergencyContacts: Array<EmergencyContactRecord & { userId: string }>;
  contactMessages: Array<{
    id: string;
    name: string;
    email: string;
    subject: string;
    message: string;
    createdAt: string;
  }>;
}

function readUserPreviewData(): UserPreviewDataStore {
  try {
    if (fs.existsSync(USER_DATA_PREVIEW_PATH)) {
      const parsed = JSON.parse(fs.readFileSync(USER_DATA_PREVIEW_PATH, 'utf8')) as Partial<UserPreviewDataStore>;
      return {
        reminders: Array.isArray(parsed.reminders) ? parsed.reminders : [],
        emergencyContacts: Array.isArray(parsed.emergencyContacts) ? parsed.emergencyContacts : [],
        contactMessages: Array.isArray(parsed.contactMessages) ? parsed.contactMessages : [],
      };
    }
  } catch {
    // Ignore unreadable preview store
  }
  return { reminders: [], emergencyContacts: [], contactMessages: [] };
}

function writeUserPreviewData(data: UserPreviewDataStore): void {
  fs.writeFileSync(USER_DATA_PREVIEW_PATH, JSON.stringify(data, null, 2), { mode: 0o600 });
}

function isValidIsoDate(val: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(val) && !Number.isNaN(Date.parse(`${val}T00:00:00Z`));
}

function normalizeReminderTimes(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [];
  const cleaned = raw
    .map((t) => String(t ?? '').trim())
    .filter((t) => /^([01]\d|2[0-3]):[0-5]\d$/.test(t));
  return Array.from(new Set(cleaned)).sort().slice(0, 8);
}

function normalizeSelectedDates(raw: unknown, startDate: string, endDate: string): string[] {
  if (!Array.isArray(raw)) return [];
  const cleaned = raw
    .map((d) => String(d ?? '').trim())
    .filter((d) => isValidIsoDate(d) && d >= startDate && d <= endDate);
  return Array.from(new Set(cleaned)).sort().slice(0, 60);
}

function mapReminderDoc(doc: Document): MedicineReminderRecord {
  const rawStatus = String(doc.status || 'pending');
  const status: ReminderActionStatus =
    rawStatus === 'completed' || rawStatus === 'skipped' ? rawStatus : 'pending';
  return {
    id: String(doc.id || doc._id),
    userId: String(doc.userId || ''),
    reminderName: String(doc.reminderName || ''),
    medicineName: String(doc.medicineName || ''),
    prescribedSchedule: String(doc.prescribedSchedule || ''),
    reminderTimes: Array.isArray(doc.reminderTimes) ? doc.reminderTimes.map(String) : [],
    selectedDates: Array.isArray(doc.selectedDates) ? doc.selectedDates.map(String) : [],
    startDate: String(doc.startDate || ''),
    endDate: String(doc.endDate || ''),
    status,
    lastActionAt: doc.lastActionAt ? String(doc.lastActionAt) : undefined,
    notes: doc.notes ? String(doc.notes) : undefined,
    createdAt: String(doc.createdAt || ''),
    updatedAt: String(doc.updatedAt || ''),
    storageMode: 'mongodb',
  };
}

export async function listUserReminders(userId: string): Promise<MedicineReminderRecord[]> {
  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('medicine_reminders');
    const docs = await col.find({ userId }).sort({ startDate: 1, createdAt: -1 }).limit(100).toArray();
    return docs.map(mapReminderDoc);
  }
  const store = readUserPreviewData();
  return store.reminders.filter((r) => r.userId === userId);
}

export async function createUserReminder(
  userId: string,
  input: {
    reminderName: string;
    medicineName: string;
    prescribedSchedule: string;
    reminderTimes: unknown;
    selectedDates?: unknown;
    startDate: string;
    endDate: string;
    notes?: string;
  }
): Promise<MedicineReminderRecord> {
  const reminderName = asCleanString(input.reminderName, 120);
  const medicineName = asCleanString(input.medicineName, 120);
  const prescribedSchedule = asCleanString(input.prescribedSchedule, 240);
  const startDate = asCleanString(input.startDate, 20);
  const endDate = asCleanString(input.endDate, 20);
  const reminderTimes = normalizeReminderTimes(input.reminderTimes);
  const notes = asCleanString(input.notes, 300);

  if (reminderName.length < 2) throw new Error('Reminder name must be at least 2 characters.');
  if (medicineName.length < 2) throw new Error('Medicine name must be at least 2 characters.');
  if (prescribedSchedule.length < 2) {
    throw new Error('Please enter the schedule provided by your doctor or pharmacist.');
  }
  if (!isValidIsoDate(startDate) || !isValidIsoDate(endDate)) {
    throw new Error('Start date and end date must be valid YYYY-MM-DD dates.');
  }
  if (endDate < startDate) {
    throw new Error('End date cannot be earlier than start date.');
  }
  if (reminderTimes.length === 0) {
    throw new Error('Select at least one valid reminder time (HH:MM).');
  }

  const selectedDates = normalizeSelectedDates(input.selectedDates, startDate, endDate);
  const now = new Date().toISOString();
  const db = await getMediBridgeDb();

  const record: MedicineReminderRecord = {
    id: `REM-${crypto.randomBytes(6).toString('hex').toUpperCase()}`,
    userId,
    reminderName,
    medicineName,
    prescribedSchedule,
    reminderTimes,
    selectedDates,
    startDate,
    endDate,
    status: 'pending',
    notes: notes || undefined,
    createdAt: now,
    updatedAt: now,
    storageMode: db ? 'mongodb' : 'preview',
  };

  if (db) {
    const col = db.collection('medicine_reminders');
    await col.insertOne({ ...record });
    return record;
  }

  const store = readUserPreviewData();
  store.reminders.unshift(record);
  writeUserPreviewData(store);
  return record;
}

export async function updateUserReminder(
  userId: string,
  reminderId: string,
  input: {
    reminderName?: string;
    medicineName?: string;
    prescribedSchedule?: string;
    reminderTimes?: unknown;
    selectedDates?: unknown;
    startDate?: string;
    endDate?: string;
    status?: ReminderActionStatus;
    notes?: string;
  }
): Promise<MedicineReminderRecord | null> {
  const now = new Date().toISOString();
  const db = await getMediBridgeDb();

  let existing: MedicineReminderRecord | null = null;
  if (db) {
    const col = db.collection('medicine_reminders');
    const idFilter: Document = ObjectId.isValid(reminderId)
      ? { userId, $or: [{ id: reminderId }, { _id: new ObjectId(reminderId) }] }
      : { userId, id: reminderId };
    const found = await col.findOne(idFilter);
    if (!found) return null;
    existing = mapReminderDoc(found);
  } else {
    const store = readUserPreviewData();
    existing = store.reminders.find((r) => r.userId === userId && r.id === reminderId) || null;
    if (!existing) return null;
  }

  const nextStartDate =
    input.startDate !== undefined ? asCleanString(input.startDate, 20) : existing.startDate;
  const nextEndDate =
    input.endDate !== undefined ? asCleanString(input.endDate, 20) : existing.endDate;

  if (!isValidIsoDate(nextStartDate) || !isValidIsoDate(nextEndDate)) {
    throw new Error('Start date and end date must be valid YYYY-MM-DD dates.');
  }
  if (nextEndDate < nextStartDate) {
    throw new Error('End date cannot be earlier than start date.');
  }

  const nextReminderName =
    input.reminderName !== undefined ? asCleanString(input.reminderName, 120) : existing.reminderName;
  const nextMedicineName =
    input.medicineName !== undefined ? asCleanString(input.medicineName, 120) : existing.medicineName;
  const nextSchedule =
    input.prescribedSchedule !== undefined
      ? asCleanString(input.prescribedSchedule, 240)
      : existing.prescribedSchedule;

  if (nextReminderName.length < 2) throw new Error('Reminder name must be at least 2 characters.');
  if (nextMedicineName.length < 2) throw new Error('Medicine name must be at least 2 characters.');
  if (nextSchedule.length < 2) {
    throw new Error('Schedule provided by your doctor or pharmacist is required.');
  }

  const nextTimes =
    input.reminderTimes !== undefined
      ? normalizeReminderTimes(input.reminderTimes)
      : existing.reminderTimes;
  if (nextTimes.length === 0) {
    throw new Error('Select at least one valid reminder time (HH:MM).');
  }

  const nextSelectedDates =
    input.selectedDates !== undefined
      ? normalizeSelectedDates(input.selectedDates, nextStartDate, nextEndDate)
      : normalizeSelectedDates(existing.selectedDates, nextStartDate, nextEndDate);

  const nextStatus: ReminderActionStatus =
    input.status === 'completed' || input.status === 'skipped' || input.status === 'pending'
      ? input.status
      : existing.status;

  const nextNotes =
    input.notes !== undefined ? asCleanString(input.notes, 300) || undefined : existing.notes;
  const statusChanged = input.status !== undefined;

  const updateFields = {
    reminderName: nextReminderName,
    medicineName: nextMedicineName,
    prescribedSchedule: nextSchedule,
    reminderTimes: nextTimes,
    selectedDates: nextSelectedDates,
    startDate: nextStartDate,
    endDate: nextEndDate,
    status: nextStatus,
    ...(statusChanged ? { lastActionAt: now } : {}),
    notes: nextNotes ?? '',
    updatedAt: now,
  };

  if (db) {
    const col = db.collection('medicine_reminders');
    const idFilter: Document = ObjectId.isValid(reminderId)
      ? { userId, $or: [{ id: reminderId }, { _id: new ObjectId(reminderId) }] }
      : { userId, id: reminderId };
    const updated = await col.findOneAndUpdate(
      idFilter,
      { $set: updateFields },
      { returnDocument: 'after' }
    );
    return updated ? mapReminderDoc(updated) : null;
  }

  const store = readUserPreviewData();
  const idx = store.reminders.findIndex((r) => r.userId === userId && r.id === reminderId);
  if (idx === -1) return null;
  store.reminders[idx] = {
    ...store.reminders[idx],
    ...updateFields,
    notes: nextNotes,
  };
  writeUserPreviewData(store);
  return store.reminders[idx];
}

export async function deleteUserReminder(userId: string, reminderId: string): Promise<boolean> {
  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('medicine_reminders');
    const idFilter: Document = ObjectId.isValid(reminderId)
      ? { userId, $or: [{ id: reminderId }, { _id: new ObjectId(reminderId) }] }
      : { userId, id: reminderId };
    const res = await col.deleteOne(idFilter);
    return res.deletedCount > 0;
  }

  const store = readUserPreviewData();
  const initialLen = store.reminders.length;
  store.reminders = store.reminders.filter((r) => !(r.userId === userId && r.id === reminderId));
  if (store.reminders.length === initialLen) return false;
  writeUserPreviewData(store);
  return true;
}

// --- Emergency SOS Contacts (Authenticated User-Scoped) ---

export async function listUserEmergencyContacts(userId: string): Promise<EmergencyContactRecord[]> {
  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('emergency_contacts');
    const docs = await col.find({ userId }).sort({ createdAt: -1 }).limit(20).toArray();
    return docs.map((d) => ({
      id: String(d.id || d._id),
      name: String(d.name || ''),
      relationship: String(d.relationship || ''),
      phone: String(d.phone || ''),
      createdAt: String(d.createdAt || ''),
      storageMode: 'mongodb',
    }));
  }
  const store = readUserPreviewData();
  return store.emergencyContacts
    .filter((c) => c.userId === userId)
    .map(({ userId: _uid, ...rest }) => rest);
}

export async function createUserEmergencyContact(
  userId: string,
  input: { name: string; relationship: string; phone: string }
): Promise<EmergencyContactRecord> {
  const name = asCleanString(input.name, 80);
  const relationship = asCleanString(input.relationship, 60) || 'Family / Contact';
  const phone = asCleanString(input.phone, 24);
  if (name.length < 2) throw new Error('Contact name must be at least 2 characters.');
  if (!/^[+\d\s()-]{3,20}$/.test(phone)) {
    throw new Error('Please enter a valid contact phone number.');
  }

  const now = new Date().toISOString();
  const db = await getMediBridgeDb();
  const record: EmergencyContactRecord = {
    id: `SOS-${crypto.randomBytes(5).toString('hex').toUpperCase()}`,
    name,
    relationship,
    phone,
    createdAt: now,
    storageMode: db ? 'mongodb' : 'session',
  };

  if (db) {
    const col = db.collection('emergency_contacts');
    await col.insertOne({ ...record, userId });
    return record;
  }

  const store = readUserPreviewData();
  store.emergencyContacts.unshift({ ...record, userId });
  writeUserPreviewData(store);
  return record;
}

export async function deleteUserEmergencyContact(userId: string, contactId: string): Promise<boolean> {
  const db = await getMediBridgeDb();
  if (db) {
    const col = db.collection('emergency_contacts');
    const idFilter: Document = ObjectId.isValid(contactId)
      ? { userId, $or: [{ id: contactId }, { _id: new ObjectId(contactId) }] }
      : { userId, id: contactId };
    const res = await col.deleteOne(idFilter);
    return res.deletedCount > 0;
  }
  const store = readUserPreviewData();
  const before = store.emergencyContacts.length;
  store.emergencyContacts = store.emergencyContacts.filter(
    (c) => !(c.userId === userId && c.id === contactId)
  );
  if (store.emergencyContacts.length === before) return false;
  writeUserPreviewData(store);
  return true;
}

// --- Contact Us Submissions ---

export async function saveContactMessage(input: {
  name: string;
  email: string;
  subject: string;
  message: string;
}): Promise<{ id: string; createdAt: string }> {
  const name = asCleanString(input.name, 100);
  const email = asCleanString(input.email, 140);
  const subject = asCleanString(input.subject, 160);
  const message = asCleanString(input.message, 1500);

  if (name.length < 2) throw new Error('Please enter your full name.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Please enter a valid email address.');
  if (subject.length < 3) throw new Error('Please enter a subject.');
  if (message.length < 10) throw new Error('Please enter a message of at least 10 characters.');

  const id = `MSG-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
  const createdAt = new Date().toISOString();
  const db = await getMediBridgeDb();

  if (db) {
    await db.collection('contact_messages').insertOne({
      id,
      name,
      email,
      subject,
      message,
      createdAt,
    });
    return { id, createdAt };
  }

  const store = readUserPreviewData();
  store.contactMessages.unshift({ id, name, email, subject, message, createdAt });
  writeUserPreviewData(store);
  return { id, createdAt };
}
