import fs from 'node:fs';
import { parse } from 'csv-parse';
import { parse as parseSync } from 'csv-parse/sync';
import type { AnyBulkWriteOperation, Collection, Db, Document } from 'mongodb';
import { getMediBridgeDb, getOrCreateWriteCollection } from './db.ts';
import type { MedicineImportSummary } from '../src/types/healthcare.ts';

export interface MedicineImportCandidate {
  sourceId: string;
  brandName: string;
  genericName: string;
  activeIngredients?: string;
  strength?: string;
  formulation: string;
  packSize?: string;
  manufacturer: string;
  medicineCategory: string;
  prescriptionClassification?: string;
  officialSourceName: string;
  sourceUrl: string;
  verified: boolean;
  verificationStatus: 'verified' | 'unverified';
  lastCheckedDate: string;
  aliases?: string[];
  precautions: string;
  usedFor?: string;
}

const GENERIC_ALIAS_MAP: Record<string, string[]> = {
  paracetamol: ['Acetaminophen', 'PCM'],
  acetaminophen: ['Paracetamol'],
  amoxycillin: ['Amoxicillin'],
  amoxicillin: ['Amoxycillin'],
  azithromycin: ['Azithromycine'],
  cetirizine: ['Cetrizine', 'Ceterizine'],
  levocetirizine: ['Levocetrizine'],
  pantoprazole: ['Pantaprazole'],
  omeprazole: ['Omeprazol'],
  rabeprazole: ['Rabiprazole'],
  metformin: ['Metformine'],
  atorvastatin: ['Atorvastatine'],
  montelukast: ['Montelucast'],
  amlodipine: ['Amlodipin'],
  ibuprofen: ['Ibuprophen'],
  'ascorbic acid': ['Vitamin C'],
  cholecalciferol: ['Vitamin D3'],
  'folic acid': ['Vitamin B9', 'Folate'],
  methylcobalamin: ['Mecobalamin', 'Vitamin B12'],
  cyanocobalamin: ['Vitamin B12'],
  pyridoxine: ['Vitamin B6'],
  thiamine: ['Vitamin B1'],
  riboflavin: ['Vitamin B2'],
  niacinamide: ['Vitamin B3', 'Nicotinamide'],
  levothyroxine: ['Thyroxine', 'Eltroxin'],
};

function computeAliases(genericName: string): string[] | undefined {
  const lower = genericName.toLowerCase();
  const aliasSet = new Set<string>();
  for (const [key, list] of Object.entries(GENERIC_ALIAS_MAP)) {
    if (lower.includes(key)) {
      for (const a of list) aliasSet.add(a);
    }
  }
  return aliasSet.size > 0 ? Array.from(aliasSet) : undefined;
}

export function classifyIndianTabletCategory(genericOrComp: string, groupHint = ''): string {
  const text = `${genericOrComp} ${groupHint}`.toLowerCase();

  if (/\b(levothyroxine|thyroxine|carbimazole|methimazole|propylthiouracil|anti-thyroid|thyroid)\b/.test(text)) {
    return 'Thyroid';
  }
  if (/\b(metformin|glimepiride|gliclazide|glipizide|glibenclamide|sitagliptin|vildagliptin|teneligliptin|linagliptin|saxagliptin|empagliflozin|dapagliflozin|canagliflozin|pioglitazone|voglibose|acarbose|repaglinide|anti-diabetic)\b/.test(text)) {
    return 'Diabetes';
  }
  if (/\b(amlodipine|telmisartan|losartan|olmesartan|valsartan|irbesartan|ramipril|enalapril|lisinopril|perindopril|atenolol|metoprolol|bisoprolol|nebivolol|propranolol|carvedilol|cilnidipine|nifedipine|clonidine|prazosin|hydrochlorothiazide|chlorthalidone|indapamide|furosemide|torsemide|spironolactone|eplerenone)\b/.test(text)) {
    return 'Blood Pressure & Hypertension';
  }
  if (/\b(atorvastatin|rosuvastatin|simvastatin|pravastatin|fenofibrate|ezetimibe|aspirin|clopidogrel|prasugrel|ticagrelor|warfarin|rivaroxaban|apixaban|dabigatran|isosorbide|nitroglycerin|nicorandil|trimetazidine|ivabradine|digoxin|amiodarone|cardiovascular)\b/.test(text)) {
    return 'Heart & Cholesterol';
  }
  if (/\b(paracetamol|acetaminophen|aceclofenac|diclofenac|ibuprofen|naproxen|etoricoxib|celecoxib|mefenamic|ketorolac|piroxicam|nimesulide|indomethacin|tramadol|tapentadol|chlorzoxazone|thiocolchicoside|tizanidine|serratiopeptidase|trypsin|analgesic|antipyretic)\b/.test(text)) {
    return 'Paracetamol & Pain Relief';
  }
  if (/\b(amoxycillin|amoxicillin|clavulanic|azithromycin|cefixime|cefuroxime|cefpodoxime|cephalexin|cefadroxil|ciprofloxacin|ofloxacin|levofloxacin|moxifloxacin|norfloxacin|doxycycline|minocycline|metronidazole|tinidazole|ornidazole|clarithromycin|erythromycin|linezolid|clindamycin|cotrimoxazole|trimethoprim|sulfamethoxazole|nitrofurantoin|rifaximin|rifampicin|isoniazid|ethambutol|pyrazinamide|fluconazole|itraconazole|ketoconazole|terbinafine|albendazole|ivermectin|acyclovir|valacyclovir|oseltamivir|antibiotic|anti-fungal|anthelmintic|anti-viral)\b/.test(text)) {
    return 'Antibiotics';
  }
  if (/\b(pantoprazole|omeprazole|rabeprazole|esomeprazole|lansoprazole|dexlansoprazole|ilaprazole|vonoprazan|famotidine|ranitidine|cimetidine|domperidone|levosulpiride|mosapride|itopride|sucralfate|antacid|magaldrate|simethicone)\b/.test(text)) {
    return 'Gastric & Acidity';
  }
  if (/\b(ondansetron|dicyclomine|hyoscine|drotaverine|mebeverine|loperamide|racecadotril|bisacodyl|lactulose|mesalamine|ursodeoxycholic|silymarin|pancreatin|probiotic|gastrointestinal)\b/.test(text)) {
    return 'Gastrointestinal';
  }
  if (/\b(cetirizine|levocetirizine|fexofenadine|loratadine|desloratadine|bilastine|ebastine|hydroxyzine|chlorpheniramine|pheniramine|cyproheptadine|promethazine|anti-histaminic)\b/.test(text)) {
    return 'Antiallergic & Antihistamines';
  }
  if (/\b(montelukast|ambroxol|acebrophylline|doxofylline|theophylline|salbutamol|levosalbutamol|terbutaline|phenylephrine|dextromethorphan|bromhexine|guaifenesin|acetylcysteine|respiratory)\b/.test(text)) {
    return 'Cough & Cold';
  }
  if (/\b(calcium|ferrous|ferric|iron|carbonyl iron|sodium feredetate|calcitriol)\b/.test(text)) {
    return 'Calcium & Iron';
  }
  if (/\b(vitamin|ascorbic|cholecalciferol|folic acid|methylcobalamin|mecobalamin|cyanocobalamin|biotin|pyridoxine|thiamine|riboflavin|niacinamide|zinc|magnesium|multivitamin|nutraceutical|supplement)\b/.test(text)) {
    return 'Vitamins & Minerals';
  }
  if (/\b(pregabalin|gabapentin|amitriptyline|nortriptyline|escitalopram|sertraline|fluoxetine|paroxetine|duloxetine|venlafaxine|desvenlafaxine|mirtazapine|alprazolam|clonazepam|lorazepam|diazepam|etizolam|zolpidem|levetiracetam|valproate|carbamazepine|oxcarbazepine|phenytoin|topiramate|lamotrigine|risperidone|olanzapine|quetiapine|aripiprazole|haloperidol|donepezil|memantine|betahistine|flunarizine|sumatriptan|rizatriptan|levodopa|carbidopa|pramipexole|central nervous system)\b/.test(text)) {
    return 'Neurological & Psychiatric';
  }
  if (/\b(isotretinoin|finasteride|dutasteride|minoxidil|acitretin|apremilast|methotrexate|hydroxychloroquine|tranexamic|derma)\b/.test(text)) {
    return 'Dermatological';
  }
  return 'Other Prescription & OTC Tablets';
}

export function extractTabletFormulation(packSize: string, brandName: string): string | null {
  const combined = `${packSize} ${brandName}`.toLowerCase();
  if (/\b(syrup|injection|vial|ampoule|cream|ointment|gel|drops|suspension|powder|sachet|inhaler|spray|capsule|capsules|lotion|solution|patch|patches|suppository)\b/.test(packSize.toLowerCase())) {
    return null;
  }
  if (!/\btablets?\b/.test(combined) && !/\btab\b/.test(combined)) {
    return null;
  }
  if (/\btablet\s*sr\b|\bsustained\s*release\b|\bsr\s+tablet/i.test(combined)) return 'Tablet SR (Sustained Release)';
  if (/\btablet\s*er\b|\bextended\s*release\b|\ber\s+tablet/i.test(combined)) return 'Tablet ER (Extended Release)';
  if (/\btablet\s*dt\b|\bdispersible\b/i.test(combined)) return 'Tablet DT (Dispersible)';
  if (/\btablet\s*md\b|\bmouth\s*dissolving\b|\bodt\b/i.test(combined)) return 'Tablet MD (Mouth Dissolving)';
  if (/\btablet\s*cr\b|\bcontrolled\s*release\b/i.test(combined)) return 'Tablet CR (Controlled Release)';
  if (/\btablet\s*pr\b|\bprolonged\s*release\b/i.test(combined)) return 'Tablet PR (Prolonged Release)';
  if (/\btablet\s*mr\b|\bmodified\s*release\b/i.test(combined)) return 'Tablet MR (Modified Release)';
  if (/\bchewable\b/i.test(combined)) return 'Chewable Tablet';
  if (/\bgastro[- ]resistant\b|\benteric[- ]coated\b/i.test(combined)) return 'Gastro-resistant Tablet';
  if (/\btablet\s*xl\b/i.test(combined)) return 'Tablet XL (Extended Release)';
  return 'Tablet';
}

export function parseIndianCompositionFields(comp1: string, comp2: string, brandName: string): {
  genericName: string;
  activeIngredients: string;
  strength?: string;
} {
  const partsRaw = [comp1.trim(), comp2.trim()].filter(Boolean);
  const genericParts: string[] = [];
  const strengthParts: string[] = [];

  for (const part of partsRaw) {
    const cleanPart = part.replace(/\s+/g, ' ').trim();
    const sMatch = cleanPart.match(/\(([^)]+)\)/);
    if (sMatch) {
      strengthParts.push(sMatch[1].replace(/\s+/g, '').trim());
    }
    const baseName = cleanPart.replace(/\([^)]*\)/g, '').replace(/\s+/g, ' ').trim();
    if (baseName) {
      genericParts.push(baseName);
    }
  }

  let strength = strengthParts.length > 0 ? strengthParts.join(' + ') : undefined;
  if (!strength) {
    const brandStrength = brandName.match(/\b(\d+(?:\.\d+)?\s*(?:mg|mcg|g|gm|ml|iu|%))\b/i);
    if (brandStrength) {
      strength = brandStrength[1].replace(/\s+/g, '');
    }
  }

  return {
    genericName: genericParts.join(' + ') || partsRaw.join(' + '),
    activeIngredients: partsRaw.join(' + '),
    strength,
  };
}

export function normalizeDedupKey(brandName: string, genericName: string, strength = '', manufacturer = ''): string {
  return `${brandName}|${genericName}|${strength}|${manufacturer}`
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

export async function ensureMedicineIndexes(col: Collection<Document>): Promise<void> {
  await Promise.all([
    col.createIndex({ sourceId: 1 }, { unique: true, sparse: true, background: true }),
    col.createIndex({ verified: 1, brandName: 1 }, { background: true }),
    col.createIndex({ genericName: 1 }, { background: true }),
    col.createIndex({ manufacturer: 1 }, { background: true }),
    col.createIndex({ medicineCategory: 1 }, { background: true }),
    col.createIndex(
      {
        brandName: 'text',
        genericName: 'text',
        activeIngredients: 'text',
        manufacturer: 'text',
        strength: 'text',
        aliases: 'text',
        medicineCategory: 'text',
      },
      { name: 'medibridge_medicine_text_idx', background: true }
    ),
  ]);
}

export async function getMedicineDatabaseStats(db?: Db | null): Promise<{
  totalInCollection: number;
  verifiedInCollection: number;
  unverifiedInCollection: number;
  byCategory: Record<string, number>;
  storageStats?: { dataSizeMB: number; storageSizeMB: number; indexSizeMB: number };
}> {
  const targetDb = db ?? (await getMediBridgeDb());
  if (!targetDb) {
    throw new Error('MongoDB Atlas Medi_Bridge is not connected.');
  }
  const col = await getOrCreateWriteCollection(
    targetDb,
    ['MedicineInfo', 'medicineInfo', 'medicine_info', 'medicines'],
    'MedicineInfo'
  );

  const [totalInCollection, verifiedInCollection, catAgg, dbStats] = await Promise.all([
    col.countDocuments(),
    col.countDocuments({
      $or: [
        { verified: true },
        { pharmacistVerified: true },
        { isVerified: true },
        { verificationStatus: { $in: ['verified', 'Verified', 'approved'] } },
      ],
    }),
    col
      .aggregate<{ _id: string | null; count: number }>([
        { $group: { _id: '$medicineCategory', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
      ])
      .toArray(),
    targetDb.command({ dbStats: 1, scale: 1048576 }).catch(() => null),
  ]);

  const byCategory: Record<string, number> = {};
  for (const row of catAgg) {
    const label = row._id ? String(row._id) : 'Uncategorized / Existing Core Records';
    byCategory[label] = row.count;
  }

  return {
    totalInCollection,
    verifiedInCollection,
    unverifiedInCollection: Math.max(0, totalInCollection - verifiedInCollection),
    byCategory,
    storageStats: dbStats
      ? {
          dataSizeMB: Number(Number(dbStats.dataSize || 0).toFixed(2)),
          storageSizeMB: Number(Number(dbStats.storageSize || 0).toFixed(2)),
          indexSizeMB: Number(Number(dbStats.indexSize || 0).toFixed(2)),
        }
      : undefined,
  };
}

export async function importMedicineBatchCandidates(
  candidates: MedicineImportCandidate[],
  options: { batchSize?: number; preRejectedCount?: number; preDuplicateCount?: number } = {}
): Promise<MedicineImportSummary> {
  const db = await getMediBridgeDb();
  if (!db) {
    throw new Error('MongoDB Atlas Medi_Bridge is not connected.');
  }

  const col = await getOrCreateWriteCollection(
    db,
    ['MedicineInfo', 'medicineInfo', 'medicine_info', 'medicines'],
    'MedicineInfo'
  );

  await ensureMedicineIndexes(col);

  // Load existing keys so we never duplicate or overwrite any pre-existing record
  const existingDocs = await col
    .find(
      {},
      {
        projection: {
          sourceId: 1,
          brandName: 1,
          name: 1,
          genericName: 1,
          strength: 1,
          manufacturer: 1,
        },
      }
    )
    .toArray();

  const existingSourceIds = new Set<string>();
  const existingCompositeKeys = new Set<string>();
  for (const d of existingDocs) {
    if (d.sourceId) existingSourceIds.add(String(d.sourceId));
    const bName = String(d.brandName || d.name || '');
    const gName = String(d.genericName || '');
    const str = String(d.strength || '');
    const mfg = String(d.manufacturer || '');
    existingCompositeKeys.add(normalizeDedupKey(bName, gName, str, mfg));
  }

  const batchSize = options.batchSize ?? 2000;
  let newlyImported = 0;
  let duplicatesSkipped = options.preDuplicateCount ?? 0;
  let rejectedCount = options.preRejectedCount ?? 0;
  let verifiedImported = 0;
  let unverifiedImported = 0;
  const byCategory: Record<string, number> = {};

  const validOps: Array<{
    op: AnyBulkWriteOperation<Document>;
    category: string;
    verified: boolean;
  }> = [];

  for (const item of candidates) {
    const brandName = item.brandName.trim();
    const genericName = item.genericName.trim();
    const manufacturer = item.manufacturer.trim();
    const formulation = item.formulation.trim();

    if (!brandName || !genericName || !manufacturer || !formulation || !item.sourceId) {
      rejectedCount++;
      continue;
    }

    const compKey = normalizeDedupKey(brandName, genericName, item.strength || '', manufacturer);
    if (existingSourceIds.has(item.sourceId) || existingCompositeKeys.has(compKey)) {
      duplicatesSkipped++;
      continue;
    }

    existingSourceIds.add(item.sourceId);
    existingCompositeKeys.add(compKey);

    const doc: Document = {
      sourceId: item.sourceId,
      brandName,
      genericName,
      formulation,
      manufacturer,
      medicineCategory: item.medicineCategory,
      officialSourceName: item.officialSourceName,
      sourceUrl: item.sourceUrl,
      verified: item.verified,
      verificationStatus: item.verificationStatus,
      lastCheckedDate: item.lastCheckedDate,
      precautions: item.precautions,
    };

    if (item.activeIngredients) doc.activeIngredients = item.activeIngredients;
    if (item.strength) doc.strength = item.strength;
    if (item.packSize) doc.packSize = item.packSize;
    if (item.prescriptionClassification && item.verified) {
      doc.prescriptionClassification = item.prescriptionClassification;
    }
    if (item.aliases && item.aliases.length > 0) doc.aliases = item.aliases;
    if (item.usedFor) doc.usedFor = item.usedFor;

    validOps.push({
      op: {
        updateOne: {
          filter: { sourceId: item.sourceId },
          update: { $setOnInsert: doc },
          upsert: true,
        },
      },
      category: item.medicineCategory,
      verified: item.verified,
    });
  }

  for (let i = 0; i < validOps.length; i += batchSize) {
    const slice = validOps.slice(i, i + batchSize);
    const result = await col.bulkWrite(
      slice.map((s) => s.op),
      { ordered: false }
    );
    const upserted = result.upsertedCount || 0;
    const matched = result.matchedCount || 0;
    newlyImported += upserted;
    duplicatesSkipped += matched;

    // Track breakdown for inserted batch items
    const upsertedIdxSet = new Set(Object.keys(result.upsertedIds || {}).map(Number));
    slice.forEach((entry, idx) => {
      if (upsertedIdxSet.has(idx) || (upserted === slice.length && matched === 0)) {
        byCategory[entry.category] = (byCategory[entry.category] || 0) + 1;
        if (entry.verified) verifiedImported++;
        else unverifiedImported++;
      }
    });
  }

  const finalStats = await getMedicineDatabaseStats(db);

  return {
    totalCandidates: candidates.length + (options.preDuplicateCount ?? 0) + (options.preRejectedCount ?? 0),
    newlyImported,
    duplicatesSkipped,
    rejectedCount,
    verifiedImported,
    unverifiedImported,
    byCategory,
    totalInCollection: finalStats.totalInCollection,
    verifiedInCollection: finalStats.verifiedInCollection,
    unverifiedInCollection: finalStats.unverifiedInCollection,
    storageStats: finalStats.storageStats,
  };
}

export async function parseLocalIndianTabletCatalogs(options: {
  csvPath?: string;
  janAushadhiJsonPath?: string;
} = {}): Promise<{
  candidates: MedicineImportCandidate[];
  rejectedCount: number;
  duplicateCount: number;
}> {
  const checkedDate = new Date().toISOString().slice(0, 10);
  const candidates: MedicineImportCandidate[] = [];
  const seenKeys = new Set<string>();
  let rejectedCount = 0;
  let duplicateCount = 0;

  // 1. Jan Aushadhi generic tablet basket (if present)
  const janaPath = options.janAushadhiJsonPath ?? '/tmp/janaushadhi_products.json';
  if (fs.existsSync(janaPath)) {
    const rawList = JSON.parse(fs.readFileSync(janaPath, 'utf8')) as Array<Record<string, unknown>>;
    const excludedGroups = new Set(['Surgical & Medical Consumables', 'Ayurvedic']);
    for (const item of rawList) {
      const genericFull = String(item.GenericName || '').trim();
      const groupName = String(item.GroupName || '').trim();
      const drugCode = String(item.DrugCode || item.Sr_No || '').trim();
      const unitSize = String(item.UnitSize || '').trim();

      if (!genericFull || !drugCode || excludedGroups.has(groupName)) {
        rejectedCount++;
        continue;
      }

      const formulation = extractTabletFormulation(genericFull, genericFull);
      if (!formulation) {
        rejectedCount++;
        continue;
      }

      // Extract strength(s) and base generic ingredient from GenericName like "Aceclofenac 100mg and Paracetamol 325mg Tablets"
      const strengthMatches = Array.from(
        genericFull.matchAll(/\b(\d+(?:\.\d+)?\s*(?:mg|mcg|g|gm|ml|iu|%))\b/gi)
      ).map((m) => m[1].replace(/\s+/g, ''));
      const strength = strengthMatches.length > 0 ? strengthMatches.join(' + ') : undefined;
      const cleanGeneric = genericFull
        .replace(/\b(tablets?|ip|bp|usp|sr|er|dt|md|cr|pr|mr|chewable|gastro[- ]resistant|film[- ]coated|coated|dispersible)\b/gi, '')
        .replace(/\b\d+(?:\.\d+)?\s*(?:mg|mcg|g|gm|ml|iu|%)\b/gi, '')
        .replace(/\s+and\s+/gi, ' + ')
        .replace(/[,+]+/g, ' + ')
        .replace(/\s+/g, ' ')
        .replace(/^\s*\+\s*|\s*\+\s*$/g, '')
        .trim();

      const manufacturer = 'PMBI (Jan Aushadhi Generic Basket)';
      const key = normalizeDedupKey(genericFull, cleanGeneric || genericFull, strength || '', manufacturer);
      if (seenKeys.has(key)) {
        duplicateCount++;
        continue;
      }
      seenKeys.add(key);

      candidates.push({
        sourceId: `jana-tablet-${drugCode}`,
        brandName: genericFull,
        genericName: cleanGeneric || genericFull,
        activeIngredients: genericFull,
        strength,
        formulation,
        packSize: unitSize || undefined,
        manufacturer,
        medicineCategory: classifyIndianTabletCategory(genericFull, groupName),
        officialSourceName: 'PMBI Jan Aushadhi Product Portfolio (Unverified Mirror of janaushadhi.gov.in)',
        sourceUrl: 'https://janaushadhi.gov.in/ProductList.aspx',
        verified: false,
        verificationStatus: 'unverified',
        lastCheckedDate: checkedDate,
        aliases: computeAliases(cleanGeneric || genericFull),
        precautions: 'Verify exact generic composition, strength, and prescription requirement with a licensed doctor or registered pharmacist.',
      });
    }
  }

  // 2. Indian Medicine Dataset CSV (147,000+ genuine Indian brand tablets)
  const csvPath = options.csvPath ?? '/tmp/indian_medicine_data.csv';
  if (fs.existsSync(csvPath)) {
    const parser = fs.createReadStream(csvPath).pipe(
      parse({
        columns: true,
        skip_empty_lines: true,
        trim: true,
      })
    );

    for await (const row of parser as AsyncIterable<Record<string, string>>) {
      const id = (row.id || '').trim();
      const brandName = (row.name || '').trim();
      const packSize = (row.pack_size_label || '').trim();
      const manufacturer = (row.manufacturer_name || '').trim();
      const comp1 = (row.short_composition1 || '').trim();
      const comp2 = (row.short_composition2 || '').trim();
      const discontinued = String(row.Is_discontinued || '').toUpperCase() === 'TRUE';

      if (!id || !brandName || !manufacturer || !comp1 || discontinued) {
        rejectedCount++;
        continue;
      }

      const formulation = extractTabletFormulation(packSize, brandName);
      if (!formulation) {
        rejectedCount++;
        continue;
      }

      const parsedComp = parseIndianCompositionFields(comp1, comp2, brandName);
      if (!parsedComp.genericName) {
        rejectedCount++;
        continue;
      }

      const key = normalizeDedupKey(brandName, parsedComp.genericName, parsedComp.strength || '', manufacturer);
      if (seenKeys.has(key)) {
        duplicateCount++;
        continue;
      }
      seenKeys.add(key);

      candidates.push({
        sourceId: `imd-tablet-${id}`,
        brandName,
        genericName: parsedComp.genericName,
        activeIngredients: parsedComp.activeIngredients,
        strength: parsedComp.strength,
        formulation,
        packSize: packSize || undefined,
        manufacturer,
        medicineCategory: classifyIndianTabletCategory(parsedComp.genericName),
        officialSourceName: 'Indian Medicine Dataset (Manufacturer & Composition Catalog — Unverified)',
        sourceUrl: 'https://github.com/junioralive/Indian-Medicine-Dataset',
        verified: false,
        verificationStatus: 'unverified',
        lastCheckedDate: checkedDate,
        aliases: computeAliases(parsedComp.genericName),
        precautions: 'Unverified catalog entry. Confirm strength, active ingredients, and prescription requirement with a licensed physician or pharmacist.',
      });
    }
  }

  return { candidates, rejectedCount, duplicateCount };
}

export async function importMedicineCsvBuffer(buffer: Buffer): Promise<MedicineImportSummary> {
  const checkedDate = new Date().toISOString().slice(0, 10);
  const rows = parseSync(buffer.toString('utf8'), {
    columns: true,
    skip_empty_lines: true,
    trim: true,
  }) as Array<Record<string, string>>;

  const candidates: MedicineImportCandidate[] = [];
  let rejectedCount = 0;

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const brandName = (r.brandName || r.name || r.medicineName || '').trim();
    const genericNameRaw = (r.genericName || r.short_composition1 || r.composition || '').trim();
    const comp2 = (r.short_composition2 || '').trim();
    const manufacturer = (r.manufacturer || r.manufacturer_name || '').trim();
    const packSize = (r.packSize || r.pack_size_label || '').trim();
    const formulation = (r.formulation || '').trim() || extractTabletFormulation(packSize, brandName) || '';

    if (!brandName || !genericNameRaw || !manufacturer || !formulation) {
      rejectedCount++;
      continue;
    }

    const parsedComp = comp2 || /\([^)]+\)/.test(genericNameRaw)
      ? parseIndianCompositionFields(genericNameRaw, comp2, brandName)
      : { genericName: genericNameRaw, activeIngredients: r.activeIngredients || genericNameRaw, strength: r.strength || undefined };

    const sourceId = (r.sourceId || '').trim() || `csv-tablet-${normalizeDedupKey(brandName, parsedComp.genericName, parsedComp.strength || '', manufacturer)}`;
    const isVerified = String(r.verified || '').toLowerCase() === 'true';

    candidates.push({
      sourceId,
      brandName,
      genericName: parsedComp.genericName,
      activeIngredients: parsedComp.activeIngredients,
      strength: parsedComp.strength,
      formulation,
      packSize: packSize || undefined,
      manufacturer,
      medicineCategory: (r.medicineCategory || '').trim() || classifyIndianTabletCategory(parsedComp.genericName),
      prescriptionClassification: isVerified && r.prescriptionClassification ? r.prescriptionClassification.trim() : undefined,
      officialSourceName: (r.officialSourceName || '').trim() || (isVerified ? 'Verified Regulatory Source' : 'Uploaded CSV Dataset — Unverified'),
      sourceUrl: (r.sourceUrl || '').trim() || '',
      verified: isVerified,
      verificationStatus: isVerified ? 'verified' : 'unverified',
      lastCheckedDate: (r.lastCheckedDate || '').trim() || checkedDate,
      aliases: computeAliases(parsedComp.genericName),
      precautions: (r.precautions || '').trim() || 'Confirm strength and prescription status with a licensed physician or registered pharmacist.',
    });
  }

  return importMedicineBatchCandidates(candidates, { preRejectedCount: rejectedCount });
}
