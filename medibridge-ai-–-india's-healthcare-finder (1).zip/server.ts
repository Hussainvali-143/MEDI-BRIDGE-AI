import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import multer from 'multer';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  asCleanString,
  createAppointmentRequest,
  createUserEmergencyContact,
  createUserReminder,
  deleteUserEmergencyContact,
  deleteUserReminder,
  getConfiguredDbName,
  getDatabaseStatus,
  listAppointments,
  listHospitalsForAdmin,
  listUserEmergencyContacts,
  listUserReminders,
  lookupPatients,
  saveContactMessage,
  searchDoctorsInDb,
  searchHealthTestsInDb,
  searchHealthTopicsInDb,
  searchHospitalsInDb,
  searchMedicinesInDb,
  updateAppointmentStatus,
  updateHospitalVerificationStatus,
  updateUserReminder,
} from './server/db.ts';
import {
  educateHealthTest,
  educateHealthTestDocument,
  explainHealthTopic,
  lookupMedicineEducation,
  searchPublicHospitalsGrounded,
} from './server/ai.ts';
import {
  authenticateAdminPasscode,
  extractBearerToken,
  getAdminAuthStatus,
  requireAdminAuth,
  setupInitialAdminPasscode,
} from './server/adminAuth.ts';
import {
  loginUserAccount,
  registerUserAccount,
  requireUserAuth,
  type AuthenticatedRequest,
} from './server/userAuth.ts';
import {
  assertSafeMutationOrigin,
  clearPatientSessionCookie,
  createPatientSessionCookie,
  HttpStatusError,
  loginPatientAccount,
  registerPatientAccount,
  requirePatientAuth,
  updatePatientProfileById,
  type PatientAuthenticatedRequest,
} from './server/patientAuth.ts';
import { importHospitalCsvToMongo, previewHospitalCsv } from './server/csvImport.ts';
import {
  getMedicineDatabaseStats,
  importMedicineBatchCandidates,
  importMedicineCsvBuffer,
  parseLocalIndianTabletCatalogs,
} from './server/medicineImport.ts';
import type {
  AppointmentStatus,
  HospitalImportTargetField,
  ReminderActionStatus,
} from './src/types/healthcare.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = 3000;

const VALID_APPOINTMENT_STATUSES: AppointmentStatus[] = [
  'Requested',
  'Pending Facility Confirmation',
  'Confirmed',
  'Cancelled',
];

const csvUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 30 * 1024 * 1024, // 30 MB max CSV upload
  },
  fileFilter: (_req, file, cb) => {
    const lowerName = (file.originalname || '').toLowerCase();
    const mime = (file.mimetype || '').toLowerCase();
    if (
      lowerName.endsWith('.csv') ||
      mime.includes('csv') ||
      mime === 'text/plain' ||
      mime === 'application/vnd.ms-excel'
    ) {
      cb(null, true);
    } else {
      cb(new Error('Only .csv files are supported for hospital dataset import.'));
    }
  },
});

const MAX_HEALTH_REPORT_BYTES = 10 * 1024 * 1024; // 10 MB max report upload
const ALLOWED_REPORT_EXTS = ['.pdf', '.jpg', '.jpeg', '.png'];
const ALLOWED_REPORT_MIMES = new Set([
  'application/pdf',
  'image/jpeg',
  'image/jpg',
  'image/png',
]);

const reportUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_HEALTH_REPORT_BYTES,
    files: 1,
  },
  fileFilter: (_req, file, cb) => {
    const lowerName = (file.originalname || '').toLowerCase();
    const mime = (file.mimetype || '').toLowerCase();
    const hasAllowedExt = ALLOWED_REPORT_EXTS.some((ext) => lowerName.endsWith(ext));
    const hasAllowedMime = ALLOWED_REPORT_MIMES.has(mime);
    if (hasAllowedExt && hasAllowedMime) {
      cb(null, true);
    } else {
      cb(new Error('Unsupported file type. Only PDF, JPG, JPEG, and PNG medical report files are allowed.'));
    }
  },
});

function validateReportFileSignature(
  buffer: Buffer,
  originalName: string
): 'application/pdf' | 'image/jpeg' | 'image/png' {
  if (!buffer || buffer.length === 0) {
    throw new Error('The uploaded medical report file is empty.');
  }

  const lower = originalName.toLowerCase();
  const isPdfSig = buffer.length >= 5 && buffer.subarray(0, 5).toString('ascii') === '%PDF-';
  const isPngSig =
    buffer.length >= 8 &&
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a;
  const isJpegSig = buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;

  if (lower.endsWith('.pdf')) {
    if (!isPdfSig) {
      throw new Error('Invalid PDF file content. Please upload a valid PDF document.');
    }
    return 'application/pdf';
  }
  if (lower.endsWith('.png')) {
    if (!isPngSig) {
      throw new Error('Invalid PNG image content. Please upload a valid PNG file.');
    }
    return 'image/png';
  }
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) {
    if (!isJpegSig) {
      throw new Error('Invalid JPEG image content. Please upload a valid JPG or JPEG file.');
    }
    return 'image/jpeg';
  }

  throw new Error('Unsupported file extension. Only PDF, JPG, JPEG, and PNG files are allowed.');
}

function parseColumnOverrides(
  raw: unknown
): Partial<Record<HospitalImportTargetField, string | null>> | undefined {
  if (typeof raw !== 'string' || !raw.trim()) return undefined;
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Partial<Record<HospitalImportTargetField, string | null>>;
    }
  } catch {
    // Ignore malformed override JSON
  }
  return undefined;
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  app.use('/api', (_req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    next();
  });
  app.use(express.json({ limit: '1mb' }));

  // 1. Database & System Status
  app.get('/api/health', async (req, res) => {
    try {
      const forceRetry = req.query.retry === '1';
      const status = await getDatabaseStatus(forceRetry);
      res.json({ ok: true, ...status });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to inspect database status.' });
    }
  });

  // 2. India Hospital Finder (Medi_Bridge DB: separated Verified vs Unverified)
  const extractHospitalFilters = (req: express.Request) => ({
    q: asCleanString(req.query.q),
    state: asCleanString(req.query.state),
    district: asCleanString(req.query.district),
    city: asCleanString(req.query.city),
    pinCode: asCleanString(req.query.pinCode, 12),
    facilityType: asCleanString(req.query.facilityType),
  });

  app.get(['/api/hospitals', '/api/hospitals/search'], async (req, res) => {
    try {
      const filters = extractHospitalFilters(req);
      const data = await searchHospitalsInDb(filters, 'all');
      res.json({
        ...data,
        databaseName: getConfiguredDbName(),
      });
    } catch {
      res.status(500).json({ error: 'Failed to search hospitals in Medi_Bridge.' });
    }
  });

  app.get('/api/hospitals/verified', async (req, res) => {
    try {
      const filters = extractHospitalFilters(req);
      const data = await searchHospitalsInDb(filters, 'verified');
      res.json({
        hospitals: data.verified,
        verified: data.verified,
        count: data.verified.length,
        databaseConnected: data.databaseConnected,
        databaseName: getConfiguredDbName(),
        availableStates: data.availableStates,
        availableFacilityTypes: data.availableFacilityTypes,
      });
    } catch {
      res.status(500).json({ error: 'Failed to load verified hospitals from Medi_Bridge.' });
    }
  });

  app.get('/api/hospitals/unverified', async (req, res) => {
    try {
      const filters = extractHospitalFilters(req);
      const data = await searchHospitalsInDb(filters, 'unverified');
      res.json({
        hospitals: data.unverified,
        unverified: data.unverified,
        count: data.unverified.length,
        databaseConnected: data.databaseConnected,
        databaseName: getConfiguredDbName(),
        availableStates: data.availableStates,
        availableFacilityTypes: data.availableFacilityTypes,
      });
    } catch {
      res.status(500).json({ error: 'Failed to load unverified hospitals from Medi_Bridge.' });
    }
  });

  // 2b. Grounded Public Web Directory Search (explicitly Unverified external results)
  app.post('/api/hospitals/web-search', async (req, res) => {
    try {
      const q = asCleanString(req.body?.q);
      const state = asCleanString(req.body?.state);
      const district = asCleanString(req.body?.district);
      const city = asCleanString(req.body?.city);
      const pinCode = asCleanString(req.body?.pinCode, 12);
      const facilityType = asCleanString(req.body?.facilityType);

      if (!q && !state && !district && !city && !pinCode) {
        res.status(400).json({ error: 'Provide at least one search location (State, District, City, PIN code, or hospital name).' });
        return;
      }

      const result = await searchPublicHospitalsGrounded({ q, state, district, city, pinCode, facilityType });
      res.json(result);
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'Unable to perform grounded hospital lookup.',
      });
    }
  });

  // 3. Doctor Directory
  app.get('/api/doctors', async (req, res) => {
    try {
      const q = asCleanString(req.query.q);
      const specialty = asCleanString(req.query.specialty);
      const hospital = asCleanString(req.query.hospital);
      const city = asCleanString(req.query.city);
      const state = asCleanString(req.query.state);

      const data = await searchDoctorsInDb({ q, specialty, hospital, city, state });
      res.json(data);
    } catch {
      res.status(500).json({ error: 'Failed to query Doctor Directory.' });
    }
  });

  // 4. Medicine Information (Medi_Bridge MedicineInfo DB records + optional non-prescriptive educational summary)
  const handleMedicineLookup = async (req: express.Request, res: express.Response) => {
    try {
      const rawInput =
        req.method === 'GET'
          ? req.query.query ?? req.query.q ?? req.query.name ?? req.query.medicineName
          : req.body?.query ?? req.body?.name ?? req.body?.q ?? req.body?.medicineName;
      const query = asCleanString(rawInput, 120);
      if (!query) {
        res.status(400).json({ error: 'Please enter a medicine name to search.' });
        return;
      }

      const aiWithTimeout = Promise.race([
        lookupMedicineEducation(query),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('Educational AI reference timed out.')), 4500)
        ),
      ]);

      const [dbSettled, aiSettled] = await Promise.allSettled([
        searchMedicinesInDb(query),
        aiWithTimeout,
      ]);

      if (dbSettled.status === 'rejected') {
        res.status(500).json({
          error: 'Failed to query the Medi_Bridge MedicineInfo collection.',
        });
        return;
      }

      const dbResult = dbSettled.value;
      const totalDbMatches = dbResult.verified.length + dbResult.unverified.length;
      const educationalInfo =
        aiSettled.status === 'fulfilled'
          ? {
              ...aiSettled.value,
              safetyAndStorageNotes: aiSettled.value.howTypicallyTaken,
            }
          : null;

      const aiNotice =
        aiSettled.status === 'fulfilled'
          ? 'Educational AI reference shown below is unverified general information. Always consult a qualified physician or registered pharmacist.'
          : totalDbMatches > 0
          ? 'Showing records from your Medi_Bridge MedicineInfo database. Educational AI reference is temporarily unavailable; always consult a qualified physician or registered pharmacist.'
          : 'No matching records were found in the Medi_Bridge MedicineInfo collection, and the optional educational AI reference is temporarily unavailable. Always consult a qualified physician or registered pharmacist.';

      res.json({
        query,
        verifiedRecords: dbResult.verified,
        unverifiedRecords: dbResult.unverified,
        exactMatchesCount: dbResult.exactMatchesCount,
        relatedMatchesCount: dbResult.relatedMatchesCount,
        searchSummary: dbResult.searchSummary,
        educationalInfo,
        aiNotice,
        databaseConnected: dbResult.databaseConnected,
        databaseName: getConfiguredDbName(),
        medicalWarning:
          'IMPORTANT: Medicine information shown here is for educational purposes only and is NOT a substitute for professional medical advice, diagnosis, or a licensed prescription.',
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Unable to retrieve medicine information.',
      });
    }
  };

  app
    .route('/api/medicines/lookup')
    .get(handleMedicineLookup)
    .post(handleMedicineLookup)
    .all((_req, res) => {
      res
        .status(405)
        .setHeader('Allow', 'GET, POST')
        .json({ error: 'Method not allowed. Use GET or POST for /api/medicines/lookup.' });
    });

  // 5. Health Topics Education
  app.post('/api/health-topics/explain', async (req, res) => {
    try {
      const query = asCleanString(req.body?.query, 140);
      if (!query) {
        res.status(400).json({ error: 'Please enter a health topic to search.' });
        return;
      }

      const [dbResult, educationalGuide] = await Promise.all([
        searchHealthTopicsInDb(query),
        explainHealthTopic(query),
      ]);

      res.json({
        query,
        curatedRecords: dbResult.records,
        educationalGuide,
        databaseConnected: dbResult.databaseConnected,
      });
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'Unable to retrieve health topic explanation.',
      });
    }
  });

  // 6. Health Report Education (Non-diagnostic test explainer: JSON text OR multipart PDF/JPG/PNG)
  const handleHealthReportDocumentUpload = (req: express.Request, res: express.Response) => {
    reportUpload.fields([
      { name: 'report', maxCount: 1 },
      { name: 'file', maxCount: 1 },
    ])(req, res, async (uploadErr) => {
      if (uploadErr) {
        if (uploadErr instanceof multer.MulterError) {
          if (uploadErr.code === 'LIMIT_FILE_SIZE') {
            res.status(413).json({
              error: 'File size exceeds the 10 MB limit. Please upload a smaller PDF, JPG, JPEG, or PNG file.',
            });
            return;
          }
          res.status(400).json({
            error: 'Please upload a single medical report file (PDF, JPG, JPEG, or PNG) up to 10 MB.',
          });
          return;
        }
        res.status(400).json({
          error: uploadErr instanceof Error ? uploadErr.message : 'Unable to process uploaded file.',
        });
        return;
      }

      const filesMap = req.files as Record<string, Express.Multer.File[]> | undefined;
      const uploadedFile = filesMap?.report?.[0] || filesMap?.file?.[0];
      if (!uploadedFile || !uploadedFile.buffer) {
        res.status(400).json({
          error: 'No medical report file was received. Select a PDF, JPG, JPEG, or PNG file to continue.',
        });
        return;
      }

      const consentRaw = req.body?.consent;
      const hasConsent = consentRaw === 'true' || consentRaw === true;
      if (!hasConsent) {
        res.status(400).json({
          error: 'Please confirm consent for temporary in-memory report processing before uploading.',
        });
        return;
      }

      let verifiedMime: 'application/pdf' | 'image/jpeg' | 'image/png';
      try {
        verifiedMime = validateReportFileSignature(
          uploadedFile.buffer,
          uploadedFile.originalname || ''
        );
      } catch (validationErr) {
        res.status(400).json({
          error: validationErr instanceof Error ? validationErr.message : 'Invalid medical report file.',
        });
        return;
      }

      const safeFileName = path.basename(uploadedFile.originalname || 'medical-report').slice(0, 120);
      const question = asCleanString(req.body?.question, 300);

      try {
        const educationalExplanation = await educateHealthTestDocument({
          buffer: uploadedFile.buffer,
          mimeType: verifiedMime,
          question: question || undefined,
        });

        let dbResult: Awaited<ReturnType<typeof searchHealthTestsInDb>> = {
          records: [],
          databaseConnected: false,
        };
        try {
          if (educationalExplanation.testName) {
            dbResult = await searchHealthTestsInDb(educationalExplanation.testName);
          }
        } catch {
          // Non-fatal: still return AI educational explanation
        }

        res.json({
          query: educationalExplanation.testName || safeFileName,
          sourceType: 'document',
          uploadedFileName: safeFileName,
          curatedRecords: dbResult.records,
          educationalExplanation,
          databaseConnected: dbResult.databaseConnected,
        });
      } catch (err) {
        res.status(502).json({
          error: err instanceof Error ? err.message : 'Unable to explain uploaded medical report.',
        });
      }
    });
  };

  app.post('/api/health-reports/educate-document', handleHealthReportDocumentUpload);

  app.post('/api/health-reports/educate', async (req, res) => {
    if (req.is('multipart/form-data')) {
      handleHealthReportDocumentUpload(req, res);
      return;
    }

    if (!req.is('application/json') && req.headers['content-type']) {
      res.status(415).json({
        error: 'Unsupported Content-Type. Send application/json with a testName or multipart/form-data with a PDF, JPG, JPEG, or PNG medical report.',
      });
      return;
    }

    try {
      const testName = asCleanString(req.body?.testName, 140);
      const question = asCleanString(req.body?.question, 300);
      if (!testName) {
        res.status(400).json({ error: 'Please enter a medical test name (e.g., CBC, HbA1c, Lipid Profile).' });
        return;
      }

      const [dbResult, educationalExplanation] = await Promise.all([
        searchHealthTestsInDb(testName),
        educateHealthTest(testName, question || undefined),
      ]);

      res.json({
        query: testName,
        sourceType: 'text',
        curatedRecords: dbResult.records,
        educationalExplanation,
        databaseConnected: dbResult.databaseConnected,
      });
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'Unable to retrieve test educational guide.',
      });
    }
  });

  app.all(['/api/health-reports/educate', '/api/health-reports/educate-document'], (_req, res) => {
    res
      .status(405)
      .setHeader('Allow', 'POST')
      .json({ error: 'Method not allowed. Use POST to request Health Report Education.' });
  });

  // 7. Patient Registration, Authentication & Private Profile
  app.post('/api/patients/register', async (req, res) => {
    try {
      const patient = await registerPatientAccount({
        fullName: req.body?.fullName,
        dateOfBirth: req.body?.dateOfBirth,
        gender: req.body?.gender,
        mobileNumber: req.body?.mobileNumber ?? req.body?.phone,
        email: req.body?.email,
        address: req.body?.address,
        password: req.body?.password,
        confirmPassword: req.body?.confirmPassword,
      });

      res.status(201).json({
        message: 'Patient registration successful. Save your Patient ID to log in.',
        patient,
      });
    } catch (err) {
      if (err instanceof HttpStatusError) {
        res.status(err.status).json({ error: err.message });
        return;
      }
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Unable to register patient account.',
      });
    }
  });

  app.post('/api/patients/login', async (req, res) => {
    try {
      const patient = await loginPatientAccount(req, {
        patientId: req.body?.patientId,
        password: req.body?.password,
      });

      await createPatientSessionCookie(req, res, patient.patientId);
      res.json({
        message: 'Login successful.',
        patient,
      });
    } catch (err) {
      if (err instanceof HttpStatusError) {
        if (err.retryAfterSeconds) {
          res.setHeader('Retry-After', String(err.retryAfterSeconds));
        }
        res.status(err.status).json({ error: err.message });
        return;
      }
      res.status(401).json({ error: 'Invalid Patient ID or password.' });
    }
  });

  app.post('/api/patients/logout', async (req, res) => {
    try {
      if (!assertSafeMutationOrigin(req)) {
        res.status(403).json({ error: 'Cross-site logout blocked.' });
        return;
      }
      await clearPatientSessionCookie(req, res);
      res.json({ loggedOut: true, message: 'You have been logged out securely.' });
    } catch {
      res.status(500).json({ error: 'Unable to complete logout.' });
    }
  });

  app.get('/api/patients/me', requirePatientAuth, (req: PatientAuthenticatedRequest, res) => {
    res.json({ patient: req.patient });
  });

  app.patch('/api/patients/me', requirePatientAuth, async (req: PatientAuthenticatedRequest, res) => {
    try {
      const updated = await updatePatientProfileById(req.patient!.patientId, {
        fullName: req.body?.fullName,
        dateOfBirth: req.body?.dateOfBirth,
        gender: req.body?.gender,
        mobileNumber: req.body?.mobileNumber,
        email: req.body?.email,
        address: req.body?.address,
      });
      if (!updated) {
        res.status(404).json({ error: 'Patient profile not found.' });
        return;
      }
      res.json({
        message: 'Patient profile updated successfully.',
        patient: updated,
      });
    } catch (err) {
      if (err instanceof HttpStatusError) {
        res.status(err.status).json({ error: err.message });
        return;
      }
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Unable to update patient profile.',
      });
    }
  });

  app.post('/api/patients/forgot-password', (_req, res) => {
    res.status(501).json({
      configured: false,
      error:
        'Self-service password reset requires configured SMS OTP or verified email delivery, which is not yet active on this deployment. Password reset cannot proceed without identity verification.',
    });
  });

  app.get('/api/patients/lookup', requirePatientAuth, (req: PatientAuthenticatedRequest, res) => {
    const p = req.patient!;
    res.json({
      patients: [
        {
          patientId: p.patientId,
          fullName: p.fullName,
          age: p.age ?? 0,
          gender: p.gender || '',
          phone: p.mobileNumber,
          email: p.email,
          address: p.address || '',
          city: '',
          district: '',
          state: '',
          pinCode: '',
          createdAt: p.registrationDate,
          storageMode: p.storageMode,
        },
      ],
      storageMode: p.storageMode,
    });
  });

  // 8. Appointment Booking & Status Tracking (Patient-Scoped & Authenticated)
  app.get('/api/appointments', requirePatientAuth, async (req: PatientAuthenticatedRequest, res) => {
    try {
      const requestedPatientId = asCleanString(req.query.patientId, 60).toUpperCase();
      const authenticatedId = req.patient!.patientId.toUpperCase();
      if (requestedPatientId && requestedPatientId !== authenticatedId) {
        res.status(403).json({
          error: 'Access denied. Patients can only view their own appointments.',
        });
        return;
      }
      const bookingRef = asCleanString(req.query.bookingRef, 60);
      const result = await listAppointments({
        patientId: req.patient!.patientId,
        bookingRef: bookingRef || undefined,
      });
      res.json(result);
    } catch {
      res.status(500).json({ error: 'Failed to retrieve appointment records.' });
    }
  });

  app.post('/api/appointments', requirePatientAuth, async (req: PatientAuthenticatedRequest, res) => {
    try {
      const requestedPatientId = asCleanString(req.body?.patientId, 60).toUpperCase();
      const authenticatedId = req.patient!.patientId.toUpperCase();
      if (requestedPatientId && requestedPatientId !== authenticatedId) {
        res.status(403).json({
          error: 'Access denied. Appointments can only be created under your own Patient ID.',
        });
        return;
      }

      const hospitalName = asCleanString(req.body?.hospitalName, 160);
      const hospitalCity = asCleanString(req.body?.hospitalCity, 80);
      const doctorName = asCleanString(req.body?.doctorName, 120);
      const specialty = asCleanString(req.body?.specialty, 100);
      const preferredDate = asCleanString(req.body?.preferredDate, 30);
      const preferredWindow = asCleanString(req.body?.preferredWindow, 60);
      const visitTypeRaw = asCleanString(req.body?.visitType, 30);
      const reason = asCleanString(req.body?.reason, 300);

      if (!hospitalName || !preferredDate || !preferredWindow || !reason) {
        res.status(400).json({
          error: 'Hospital Name, Preferred Date, Preferred Window, and Reason for Visit are required.',
        });
        return;
      }

      const visitType = visitTypeRaw === 'Teleconsultation' ? 'Teleconsultation' : 'In-Person';
      const appointment = await createAppointmentRequest({
        patientId: req.patient!.patientId,
        hospitalName,
        hospitalCity,
        doctorName,
        specialty,
        preferredDate,
        preferredWindow,
        visitType,
        reason,
      });

      res.status(201).json({ appointment });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to submit appointment request.';
      const status = msg.includes('No registered patient found') ? 404 : 500;
      res.status(status).json({ error: msg });
    }
  });

  app.patch('/api/appointments/:bookingRef/status', requirePatientAuth, async (req: PatientAuthenticatedRequest, res) => {
    try {
      const bookingRef = asCleanString(req.params.bookingRef, 60);
      const status = asCleanString(req.body?.status, 40) as AppointmentStatus;
      const statusNote = asCleanString(req.body?.statusNote, 200);

      if (!bookingRef || !VALID_APPOINTMENT_STATUSES.includes(status)) {
        res.status(400).json({ error: 'Invalid booking reference or appointment status.' });
        return;
      }

      const existing = await listAppointments({ bookingRef });
      const target = existing.appointments.find((a) => a.bookingRef === bookingRef);
      if (!target) {
        res.status(404).json({ error: 'Appointment booking reference not found.' });
        return;
      }
      if (target.patientId.toUpperCase() !== req.patient!.patientId.toUpperCase()) {
        res.status(403).json({
          error: 'Access denied. You can only modify appointments belonging to your own Patient ID.',
        });
        return;
      }

      const updated = await updateAppointmentStatus(bookingRef, status, statusNote || undefined);
      if (!updated) {
        res.status(404).json({ error: 'Appointment booking reference not found.' });
        return;
      }

      res.json({ appointment: updated });
    } catch {
      res.status(500).json({ error: 'Unable to update appointment status.' });
    }
  });

  // 8b. User Account Auth, Medicine Reminders, Emergency SOS Contacts & Contact Us
  app.post('/api/auth/register', async (req, res) => {
    try {
      const fullName = asCleanString(req.body?.fullName, 120);
      const email = asCleanString(req.body?.email, 140);
      const password = typeof req.body?.password === 'string' ? req.body.password : '';
      const result = await registerUserAccount({ fullName, email, password });
      res.status(201).json(result);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Unable to register account.',
      });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const email = asCleanString(req.body?.email, 140);
      const password = typeof req.body?.password === 'string' ? req.body.password : '';
      const result = await loginUserAccount({ email, password });
      res.json(result);
    } catch (err) {
      res.status(401).json({
        error: err instanceof Error ? err.message : 'Invalid email or password.',
      });
    }
  });

  app.get('/api/reminders', requireUserAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const reminders = await listUserReminders(req.user!.id);
      res.json({ reminders });
    } catch {
      res.status(500).json({ error: 'Unable to load medicine reminders.' });
    }
  });

  app.post('/api/reminders', requireUserAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const reminder = await createUserReminder(req.user!.id, {
        reminderName: asCleanString(req.body?.reminderName, 120),
        medicineName: asCleanString(req.body?.medicineName, 120),
        prescribedSchedule: asCleanString(req.body?.prescribedSchedule, 240),
        reminderTimes: req.body?.reminderTimes,
        selectedDates: req.body?.selectedDates,
        startDate: asCleanString(req.body?.startDate, 20),
        endDate: asCleanString(req.body?.endDate, 20),
        notes: asCleanString(req.body?.notes, 300),
      });
      res.status(201).json({ reminder });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Unable to create reminder.',
      });
    }
  });

  app.patch('/api/reminders/:id', requireUserAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const reminderId = asCleanString(req.params.id, 80);
      const rawStatus = req.body?.status;
      const status: ReminderActionStatus | undefined =
        rawStatus === 'pending' || rawStatus === 'completed' || rawStatus === 'skipped'
          ? rawStatus
          : undefined;
      const updated = await updateUserReminder(req.user!.id, reminderId, {
        reminderName: req.body?.reminderName !== undefined ? asCleanString(req.body.reminderName, 120) : undefined,
        medicineName: req.body?.medicineName !== undefined ? asCleanString(req.body.medicineName, 120) : undefined,
        prescribedSchedule: req.body?.prescribedSchedule !== undefined ? asCleanString(req.body.prescribedSchedule, 240) : undefined,
        reminderTimes: req.body?.reminderTimes,
        selectedDates: req.body?.selectedDates,
        startDate: req.body?.startDate !== undefined ? asCleanString(req.body.startDate, 20) : undefined,
        endDate: req.body?.endDate !== undefined ? asCleanString(req.body.endDate, 20) : undefined,
        status,
        notes: req.body?.notes !== undefined ? asCleanString(req.body.notes, 300) : undefined,
      });
      if (!updated) {
        res.status(404).json({ error: 'Medicine reminder not found.' });
        return;
      }
      res.json({ reminder: updated });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Unable to update reminder.',
      });
    }
  });

  app.delete('/api/reminders/:id', requireUserAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const deleted = await deleteUserReminder(req.user!.id, asCleanString(req.params.id, 80));
      if (!deleted) {
        res.status(404).json({ error: 'Medicine reminder not found.' });
        return;
      }
      res.json({ deleted: true });
    } catch {
      res.status(500).json({ error: 'Unable to delete reminder.' });
    }
  });

  app.get('/api/sos-contacts', requireUserAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const contacts = await listUserEmergencyContacts(req.user!.id);
      res.json({ contacts });
    } catch {
      res.status(500).json({ error: 'Unable to load emergency contacts.' });
    }
  });

  app.post('/api/sos-contacts', requireUserAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const contact = await createUserEmergencyContact(req.user!.id, {
        name: asCleanString(req.body?.name, 80),
        relationship: asCleanString(req.body?.relationship, 60),
        phone: asCleanString(req.body?.phone, 24),
      });
      res.status(201).json({ contact });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Unable to save emergency contact.',
      });
    }
  });

  app.delete('/api/sos-contacts/:id', requireUserAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const deleted = await deleteUserEmergencyContact(req.user!.id, asCleanString(req.params.id, 80));
      if (!deleted) {
        res.status(404).json({ error: 'Emergency contact not found.' });
        return;
      }
      res.json({ deleted: true });
    } catch {
      res.status(500).json({ error: 'Unable to delete emergency contact.' });
    }
  });

  app.post('/api/contact', async (req, res) => {
    try {
      const saved = await saveContactMessage({
        name: asCleanString(req.body?.name, 100),
        email: asCleanString(req.body?.email, 140),
        subject: asCleanString(req.body?.subject, 160),
        message: asCleanString(req.body?.message, 1500),
      });
      res.status(201).json(saved);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Unable to save contact message.',
      });
    }
  });

  // 9. Admin Authentication & CSV-to-MongoDB Hospital Import
  app.get('/api/admin/auth/status', async (req, res) => {
    try {
      const token = extractBearerToken(req);
      const status = await getAdminAuthStatus(token || undefined);
      res.json(status);
    } catch {
      res.status(500).json({ error: 'Unable to check admin authentication status.' });
    }
  });

  app.post('/api/admin/auth/setup', async (req, res) => {
    try {
      const passcode = typeof req.body?.passcode === 'string' ? req.body.passcode : '';
      const result = await setupInitialAdminPasscode(passcode);
      res.status(201).json(result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to set admin passcode.';
      res.status(400).json({ error: msg });
    }
  });

  app.post('/api/admin/auth/login', async (req, res) => {
    try {
      const passcode = typeof req.body?.passcode === 'string' ? req.body.passcode : '';
      if (!passcode) {
        res.status(400).json({ error: 'Please enter the admin passcode.' });
        return;
      }
      const result = await authenticateAdminPasscode(passcode);
      res.json(result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Authentication failed.';
      res.status(401).json({ error: msg });
    }
  });

  app.post('/api/admin/hospitals/preview', requireAdminAuth, (req, res) => {
    csvUpload.single('file')(req, res, async (uploadErr) => {
      if (uploadErr) {
        res.status(400).json({
          error: uploadErr instanceof Error ? uploadErr.message : 'CSV file upload failed.',
        });
        return;
      }
      if (!req.file || !req.file.buffer) {
        res.status(400).json({ error: 'Please upload a valid CSV file.' });
        return;
      }
      try {
        const overrides = parseColumnOverrides(req.body?.columnOverrides);
        const preview = await previewHospitalCsv(
          req.file.buffer,
          req.file.originalname || 'hospitals.csv',
          overrides
        );
        res.json(preview);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'Unable to parse CSV file.',
        });
      }
    });
  });

  app.post('/api/admin/hospitals/import', requireAdminAuth, (req, res) => {
    csvUpload.single('file')(req, res, async (uploadErr) => {
      if (uploadErr) {
        res.status(400).json({
          error: uploadErr instanceof Error ? uploadErr.message : 'CSV file upload failed.',
        });
        return;
      }
      if (!req.file || !req.file.buffer) {
        res.status(400).json({ error: 'Please upload a valid CSV file.' });
        return;
      }

      res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Transfer-Encoding', 'chunked');

      try {
        const overrides = parseColumnOverrides(req.body?.columnOverrides);
        const finalSummary = await importHospitalCsvToMongo(
          req.file.buffer,
          req.file.originalname || 'hospitals.csv',
          overrides,
          (progressEvt) => {
            res.write(JSON.stringify(progressEvt) + '\n');
          }
        );
        res.write(JSON.stringify(finalSummary) + '\n');
        res.end();
      } catch (err) {
        const errEvt = {
          type: 'error',
          totalRows: 0,
          processedRows: 0,
          insertedCount: 0,
          skippedCount: 0,
          failedCount: 0,
          currentBatch: 0,
          totalBatches: 0,
          sampleErrors: [],
          error: err instanceof Error ? err.message : 'CSV import failed.',
        };
        res.write(JSON.stringify(errEvt) + '\n');
        res.end();
      }
    });
  });

  // 10. Admin Hospital Verification Workflow
  app.get('/api/admin/hospitals', requireAdminAuth, async (req, res) => {
    try {
      const q = asCleanString(req.query.q, 120);
      const state = asCleanString(req.query.state, 80);
      const rawStatus = asCleanString(req.query.status, 20);
      const status =
        rawStatus === 'verified' || rawStatus === 'unverified' ? rawStatus : 'all';
      const limit = Number(req.query.limit) || 40;

      const data = await listHospitalsForAdmin({ q, state, status, limit });
      res.json({
        ...data,
        databaseName: getConfiguredDbName(),
      });
    } catch {
      res.status(500).json({ error: 'Unable to load hospitals for admin verification.' });
    }
  });

  app.post('/api/admin/hospitals/lookup-official', requireAdminAuth, async (req, res) => {
    try {
      const name = asCleanString(req.body?.name, 160);
      const city = asCleanString(req.body?.city, 80);
      const state = asCleanString(req.body?.state, 80);
      const pinCode = asCleanString(req.body?.pinCode, 12);

      if (!name) {
        res.status(400).json({ error: 'Hospital name is required to look up official sources.' });
        return;
      }

      const result = await searchPublicHospitalsGrounded({ q: name, city, state, pinCode });
      res.json(result);
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'Unable to look up official sources.',
      });
    }
  });

  app.patch('/api/admin/hospitals/:id/verify', requireAdminAuth, async (req, res) => {
    try {
      const id = asCleanString(req.params.id, 80);
      if (!id) {
        res.status(400).json({ error: 'Hospital record ID is required.' });
        return;
      }

      const verified = Boolean(req.body?.verified);
      const checkedOfficialSource = Boolean(req.body?.checkedOfficialSource);
      const officialSourceName = asCleanString(req.body?.officialSourceName, 160);
      const officialSourceUrl = asCleanString(req.body?.officialSourceUrl, 300);
      const verificationNotes = asCleanString(req.body?.verificationNotes, 300);

      const updated = await updateHospitalVerificationStatus({
        id,
        verified,
        checkedOfficialSource,
        officialSourceName: officialSourceName || undefined,
        officialSourceUrl: officialSourceUrl || undefined,
        verificationNotes: verificationNotes || undefined,
      });

      if (!updated) {
        res.status(404).json({ error: 'Hospital record not found in Medi_Bridge.' });
        return;
      }

      res.json({ hospital: updated });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to update hospital verification status.';
      const status =
        msg.includes('confirm') || msg.includes('Provide') || msg.includes('URL') ? 400 : 500;
      res.status(status).json({ error: msg });
    }
  });

  // 11. Admin Medicine Catalogue Stats & Batch Import
  app.get('/api/admin/medicines/stats', requireAdminAuth, async (_req, res) => {
    try {
      const stats = await getMedicineDatabaseStats();
      res.json({
        ...stats,
        databaseName: getConfiguredDbName(),
        collectionName: 'MedicineInfo',
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Unable to fetch medicine database statistics.',
      });
    }
  });

  app.post('/api/admin/medicines/import-local', requireAdminAuth, async (req, res) => {
    try {
      const batchSize = Math.min(Math.max(Number(req.body?.batchSize) || 2000, 200), 5000);
      const parsed = await parseLocalIndianTabletCatalogs();
      if (parsed.candidates.length === 0) {
        res.status(400).json({
          error: 'No local Indian tablet catalog files were found on the server.',
        });
        return;
      }
      const summary = await importMedicineBatchCandidates(parsed.candidates, {
        batchSize,
        preRejectedCount: parsed.rejectedCount,
        preDuplicateCount: parsed.duplicateCount,
      });
      res.json({
        ...summary,
        databaseName: getConfiguredDbName(),
        collectionName: 'MedicineInfo',
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Batch medicine import failed.',
      });
    }
  });

  app.post('/api/admin/medicines/import', requireAdminAuth, (req, res) => {
    csvUpload.single('file')(req, res, async (uploadErr) => {
      if (uploadErr) {
        res.status(400).json({
          error: uploadErr instanceof Error ? uploadErr.message : 'CSV file upload failed.',
        });
        return;
      }
      if (!req.file || !req.file.buffer) {
        res.status(400).json({ error: 'Please upload a valid CSV file.' });
        return;
      }
      try {
        const summary = await importMedicineCsvBuffer(req.file.buffer);
        res.json({
          ...summary,
          databaseName: getConfiguredDbName(),
          collectionName: 'MedicineInfo',
        });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'Unable to import medicine CSV file.',
        });
      }
    });
  });

  // Ensure unmatched /api/* routes and Express middleware errors always return JSON (never HTML)
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  app.use((err: unknown, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (!req.path.startsWith('/api')) {
      next(err);
      return;
    }
    if (res.headersSent) {
      next(err);
      return;
    }
    const status =
      typeof (err as { status?: number })?.status === 'number'
        ? (err as { status: number }).status
        : 400;
    const message =
      err instanceof SyntaxError
        ? 'Invalid JSON request payload. To upload a PDF, JPG, JPEG, or PNG medical report, send multipart/form-data.'
        : err instanceof Error
        ? err.message
        : 'Unexpected API request error.';
    res.status(status).json({ error: message });
  });

  // Frontend middleware / static build serving
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      if (req.path.startsWith('/api')) {
        res.status(404).json({ error: 'API endpoint not found.' });
        return;
      }
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MediBridge AI server listening on http://0.0.0.0:${PORT}`);

    const csvPath = '/tmp/indian_medicine_data.csv';
    const janaPath = '/tmp/janaushadhi_products.json';
    if (fs.existsSync(csvPath) || fs.existsSync(janaPath)) {
      void (async () => {
        try {
          const beforeStats = await getMedicineDatabaseStats();
          if (beforeStats.totalInCollection >= 1000) {
            return;
          }
          const usedMB = beforeStats.storageStats?.storageSizeMB ?? 0;
          if (usedMB > 400) {
            fs.writeFileSync(
              '/tmp/medicine_import_report.json',
              JSON.stringify({ status: 'aborted_storage_limit', beforeStats }, null, 2)
            );
            return;
          }
          console.log(
            `[MedicineImport] Starting batch import (existing=${beforeStats.totalInCollection}, storageMB=${usedMB})...`
          );
          const parsed = await parseLocalIndianTabletCatalogs({
            csvPath,
            janAushadhiJsonPath: janaPath,
          });
          const importSummary = await importMedicineBatchCandidates(parsed.candidates, {
            batchSize: 2000,
            preRejectedCount: parsed.rejectedCount,
            preDuplicateCount: parsed.duplicateCount,
          });
          const afterStats = await getMedicineDatabaseStats();
          fs.writeFileSync(
            '/tmp/medicine_import_report.json',
            JSON.stringify(
              {
                status: 'completed',
                completedAt: new Date().toISOString(),
                beforeStats,
                importSummary,
                afterStats,
              },
              null,
              2
            )
          );
          console.log(
            `[MedicineImport] Completed: newlyImported=${importSummary.newlyImported}, duplicatesSkipped=${importSummary.duplicatesSkipped}, rejected=${importSummary.rejectedCount}, totalInCollection=${afterStats.totalInCollection}`
          );
        } catch (err) {
          fs.writeFileSync(
            '/tmp/medicine_import_report.json',
            JSON.stringify(
              {
                status: 'error',
                error: err instanceof Error ? err.message : String(err),
              },
              null,
              2
            )
          );
          console.error('[MedicineImport] Failed:', err);
        }
      })();
    }
  });
}

startServer();
