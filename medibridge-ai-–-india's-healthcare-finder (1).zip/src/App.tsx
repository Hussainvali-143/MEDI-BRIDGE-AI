import React, { useEffect, useState } from 'react';
import {
  Bell,
  Building2,
  Database,
  Home,
  Info,
  LogIn,
  LogOut,
  Mail,
  Menu,
  PhoneCall,
  Pill,
  Plus,
  Search,
  ShieldAlert,
  ShieldCheck,
  Upload,
  UserCheck,
  UserPlus,
  X,
} from 'lucide-react';
import { AboutUs } from './components/AboutUs';
import { AdminHospitalImport } from './components/AdminHospitalImport';
import { AdminHospitalVerification } from './components/AdminHospitalVerification';
import { ContactUs } from './components/ContactUs';
import { EmergencySOS } from './components/EmergencySOS';
import { HospitalFinder, type HospitalFilters } from './components/HospitalFinder';
import { MedicineInfo } from './components/MedicineInfo';
import { MedicineReminder } from './components/MedicineReminder';
import { OverviewHub, type NavSection } from './components/OverviewHub';
import { PatientPortal } from './components/PatientPortal';
import { FACILITY_TYPES, INDIAN_STATES_AND_UTS } from './data/indianLocations';
import { apiFetchJson } from './utils/apiClient';
import type {
  AuthenticatedUser,
  DatabaseStatus,
  PatientAccountProfile,
} from './types/healthcare';

type SearchScope = 'hospitals' | 'medicines';

const MAIN_NAV_ITEMS: Array<{ id: NavSection; label: string; icon: React.ReactNode }> = [
  { id: 'home', label: 'Home', icon: <Home className="w-4 h-4" /> },
  { id: 'hospitals', label: 'Hospital Finder', icon: <Building2 className="w-4 h-4" /> },
  { id: 'medicines', label: 'Medicine Details', icon: <Pill className="w-4 h-4" /> },
  { id: 'reminders', label: 'Medicine Reminder', icon: <Bell className="w-4 h-4" /> },
  { id: 'sos', label: 'Emergency SOS', icon: <ShieldAlert className="w-4 h-4" /> },
  { id: 'about', label: 'About Us', icon: <Info className="w-4 h-4" /> },
  { id: 'contact', label: 'Contact Us', icon: <Mail className="w-4 h-4" /> },
];

const ADMIN_NAV_ITEMS: Array<{ id: NavSection; label: string; icon: React.ReactNode }> = [
  { id: 'admin-import', label: 'Import Hospital Dataset', icon: <Upload className="w-4 h-4" /> },
  { id: 'admin-verify', label: 'Hospital Verification', icon: <ShieldCheck className="w-4 h-4" /> },
];

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSection>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null);
  const [retryingDb, setRetryingDb] = useState(false);

  // Security: tokens remain strictly in React state (never persisted to localStorage)
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [userToken, setUserToken] = useState<string | null>(null);
  const [activeUser, setActiveUser] = useState<AuthenticatedUser | null>(null);
  const [activePatient, setActivePatient] = useState<PatientAccountProfile | null>(null);

  // Global top search bar + (+) additional search options state
  const [globalQuery, setGlobalQuery] = useState('');
  const [showPlusOptions, setShowPlusOptions] = useState(false);
  const [searchScope, setSearchScope] = useState<SearchScope>('hospitals');

  const [hospitalFilters, setHospitalFilters] = useState<HospitalFilters>({
    q: '',
    state: '',
    district: '',
    city: '',
    pinCode: '',
    facilityType: '',
    verificationFilter: 'all',
  });
  const [hospitalSearchTrigger, setHospitalSearchTrigger] = useState(0);
  const [medicineQuickQuery, setMedicineQuickQuery] = useState('');

  const refreshHealth = async (retry = false) => {
    if (retry) setRetryingDb(true);
    try {
      const json = await apiFetchJson<DatabaseStatus>(
        retry ? '/api/health?retry=1' : '/api/health',
        { method: 'GET' },
        'Failed to inspect database status.'
      );
      setDbStatus(json);
    } catch {
      // Ignore transient poll errors
    } finally {
      if (retry) setRetryingDb(false);
    }
  };

  useEffect(() => {
    refreshHealth(false);
  }, [activeSection]);

  // Restore HTTP-only cookie patient session on initial mount if present
  useEffect(() => {
    let cancelled = false;
    apiFetchJson<{ patient: PatientAccountProfile }>(
      '/api/patients/me',
      { method: 'GET' },
      'No active patient session.'
    )
      .then((json) => {
        if (!cancelled && json.patient) {
          setActivePatient(json.patient);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setActivePatient(null);
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const handlePatientLogout = async () => {
    try {
      await apiFetchJson<{ loggedOut: boolean }>(
        '/api/patients/logout',
        { method: 'POST' },
        'Logout failed.'
      );
    } catch {
      // Clear local session state even if network request fails
    }
    setActivePatient(null);
    setActiveUser(null);
    setUserToken(null);
    setMobileMenuOpen(false);
    if (activeSection === 'patient-dashboard') {
      setActiveSection('patient-login');
    }
  };

  const handleGlobalSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = globalQuery.trim();
    setShowPlusOptions(false);

    if (searchScope === 'hospitals') {
      const isPin = /^\d{6}$/.test(trimmed);
      setHospitalFilters((prev) => ({
        ...prev,
        q: isPin ? '' : trimmed,
        pinCode: isPin ? trimmed : prev.pinCode,
      }));
      setHospitalSearchTrigger((n) => n + 1);
      setActiveSection('hospitals');
      return;
    }

    if (searchScope === 'medicines') {
      setMedicineQuickQuery(trimmed);
      setActiveSection('medicines');
    }
  };

  const activeNavLabel =
    activeSection === 'patient-register'
      ? 'Patient Register'
      : activeSection === 'patient-login'
      ? 'Patient Login'
      : activeSection === 'patient-dashboard'
      ? 'Patient Dashboard'
      : [...MAIN_NAV_ITEMS, ...ADMIN_NAV_ITEMS].find((item) => item.id === activeSection)?.label ||
        'MediBridge AI';

  const SidebarContent = (
    <div className="flex flex-col h-full bg-white border-r border-slate-200">
      {/* Brand Lockup */}
      <div className="px-5 py-5 border-b border-slate-200">
        <button
          type="button"
          onClick={() => {
            setActiveSection('home');
            setMobileMenuOpen(false);
          }}
          className="flex items-center gap-3 text-left w-full cursor-pointer"
        >
          <div className="w-9 h-9 rounded-lg bg-blue-700 text-white flex items-center justify-center shrink-0">
            <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M12 5v14M5 12h14" strokeLinecap="round" />
            </svg>
          </div>
          <div className="min-w-0">
            <span className="block text-base font-bold text-slate-900 tracking-tight truncate">
              MediBridge AI
            </span>
            <span className="block text-xs text-slate-500 truncate">
              India&apos;s Healthcare Finder
            </span>
          </div>
        </button>
      </div>

      {/* Main Navigation Links (Strictly the 7 required items) */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto" aria-label="Primary navigation">
        {MAIN_NAV_ITEMS.map((item) => {
          const isActive = activeSection === item.id;
          const isSos = item.id === 'sos';
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setActiveSection(item.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors text-left cursor-pointer whitespace-nowrap ${
                isSos
                  ? isActive
                    ? 'bg-red-600 text-white font-semibold'
                    : 'text-red-700 bg-red-50 hover:bg-red-100 font-semibold'
                  : isActive
                  ? 'bg-blue-50 text-blue-800 font-semibold'
                  : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <span
                className={
                  isSos
                    ? isActive
                      ? 'text-white'
                      : 'text-red-600'
                    : isActive
                    ? 'text-blue-700'
                    : 'text-slate-400'
                }
              >
                {item.icon}
              </span>
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}

        {/* Patient Account Navigation */}
        <div className="pt-4 mt-4 border-t border-slate-200 space-y-1">
          <p className="px-3 pb-1 text-xs font-semibold text-slate-500">Patient Portal</p>
          {activePatient ? (
            <>
              <button
                type="button"
                onClick={() => {
                  setActiveSection('patient-dashboard');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors text-left cursor-pointer whitespace-nowrap ${
                  activeSection === 'patient-dashboard'
                    ? 'bg-blue-50 text-blue-800 font-semibold'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <UserCheck className={`w-4 h-4 ${activeSection === 'patient-dashboard' ? 'text-blue-700' : 'text-slate-400'}`} />
                <span className="truncate">Patient Dashboard</span>
              </button>
              <button
                type="button"
                onClick={handlePatientLogout}
                className="w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-red-700 hover:bg-red-50 rounded-lg transition-colors text-left cursor-pointer whitespace-nowrap"
              >
                <LogOut className="w-4 h-4 text-red-600" />
                <span className="truncate">Logout</span>
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => {
                  setActiveSection('patient-register');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors text-left cursor-pointer whitespace-nowrap ${
                  activeSection === 'patient-register'
                    ? 'bg-blue-50 text-blue-800 font-semibold'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <UserPlus className={`w-4 h-4 ${activeSection === 'patient-register' ? 'text-blue-700' : 'text-slate-400'}`} />
                <span className="truncate">Patient Register</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveSection('patient-login');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors text-left cursor-pointer whitespace-nowrap ${
                  activeSection === 'patient-login'
                    ? 'bg-blue-50 text-blue-800 font-semibold'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <LogIn className={`w-4 h-4 ${activeSection === 'patient-login' ? 'text-blue-700' : 'text-slate-400'}`} />
                <span className="truncate">Patient Login</span>
              </button>
            </>
          )}
        </div>

        {/* Separate Admin Dashboard Section (Authorized Admin Only) */}
        <div className="pt-4 mt-4 border-t border-slate-200">
          <p className="px-3 pb-1.5 text-xs font-semibold text-slate-500">Admin Dashboard</p>
          {ADMIN_NAV_ITEMS.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setActiveSection(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors text-left cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-50 text-blue-800 font-semibold'
                    : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <span className={isActive ? 'text-blue-700' : 'text-slate-400'}>{item.icon}</span>
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Signed-in User & Medi_Bridge DB Footer */}
      <div className="p-4 border-t border-slate-200 space-y-3 bg-slate-50">
        {activePatient ? (
          <div className="bg-white border border-blue-200 rounded-lg p-3 space-y-0.5">
            <p className="text-xs text-slate-500">Signed-in Patient</p>
            <p className="text-sm font-semibold text-slate-900 truncate">{activePatient.fullName}</p>
            <p className="text-xs font-mono tabular-nums text-blue-700 truncate">
              {activePatient.patientId}
            </p>
          </div>
        ) : activeUser ? (
          <div className="bg-white border border-blue-200 rounded-lg p-3 space-y-0.5">
            <p className="text-xs text-slate-500">Signed-in User</p>
            <p className="text-sm font-semibold text-slate-900 truncate">{activeUser.fullName}</p>
            <p className="text-xs text-slate-500 truncate">{activeUser.email}</p>
          </div>
        ) : null}

        <div className="flex items-start gap-2.5 text-xs text-slate-600">
          <Database className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
          <div className="min-w-0 flex-1">
            <p className="font-semibold text-slate-800">
              {dbStatus?.connected
                ? `MongoDB: ${dbStatus.databaseName}`
                : dbStatus?.envVarsDetected?.mongodbUriSet
                ? 'Atlas TLS / Network Pending'
                : 'Database: Preview Mode'}
            </p>
            <p className="text-slate-500 leading-snug mt-0.5">
              {dbStatus?.connected
                ? `${dbStatus.collections.length} collections linked safely`
                : dbStatus?.envVarsDetected?.mongodbUriSet
                ? 'Check Atlas Network Access'
                : 'Set MONGODB_URI in Secrets'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-[260px] shrink-0 sticky top-0 h-screen">
        {SidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <div className="relative w-72 max-w-[85vw] h-full z-10">{SidebarContent}</div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar with Search + Patient Auth Buttons + Emergency SOS */}
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-4 sm:px-6 py-3">
          <div className="max-w-7xl mx-auto flex flex-wrap md:flex-nowrap items-center justify-between gap-3">
            {/* Zone 1: Menu + Breadcrumb */}
            <div className="flex items-center gap-3 min-w-0 shrink-0">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg cursor-pointer"
                aria-label="Open navigation menu"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="hidden sm:block">
                <p className="text-xs text-slate-500 whitespace-nowrap">MediBridge AI</p>
                <h2 className="text-sm font-semibold text-slate-900 whitespace-nowrap">
                  {activeNavLabel}
                </h2>
              </div>
            </div>

            {/* Zone 2: Unified Search Bar with (+) Button */}
            <div className="flex-1 max-w-2xl relative">
              <form onSubmit={handleGlobalSearchSubmit} className="flex items-center gap-1.5">
                <div className="relative flex-1 flex items-center bg-slate-50 border border-slate-200 rounded-lg focus-within:ring-2 focus-within:ring-blue-600 focus-within:bg-white">
                  <Search className="w-4 h-4 text-slate-400 ml-3 shrink-0" />
                  <input
                    type="text"
                    value={globalQuery}
                    onChange={(e) => setGlobalQuery(e.target.value)}
                    placeholder={
                      searchScope === 'hospitals'
                        ? 'Search hospitals, city, district, or 6-digit PIN code...'
                        : 'Search medicine name, generic, or brand (e.g., Dolo, Metformin)...'
                    }
                    className="w-full px-3 py-2 text-sm bg-transparent focus:outline-none text-slate-900 placeholder:text-slate-400"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPlusOptions((v) => !v)}
                    aria-expanded={showPlusOptions}
                    aria-label="Additional search options"
                    title="Additional search options"
                    className={`mr-1.5 p-1.5 rounded-md border transition-colors cursor-pointer shrink-0 ${
                      showPlusOptions
                        ? 'bg-blue-700 text-white border-blue-700'
                        : 'bg-white text-slate-600 border-slate-200 hover:text-blue-700 hover:border-blue-300'
                    }`}
                  >
                    {showPlusOptions ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </button>
                </div>

                <button
                  type="submit"
                  className="hidden sm:inline-flex px-4 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Search
                </button>
              </form>

              {/* Expandable (+) Additional Search Options Panel */}
              {showPlusOptions && (
                <div className="absolute left-0 right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-lg p-4 z-40 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <p className="text-xs font-semibold text-slate-900">
                      Additional Search Options
                    </p>
                    <button
                      type="button"
                      onClick={() => setShowPlusOptions(false)}
                      className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                    >
                      Close
                    </button>
                  </div>

                  {/* Scope Selector */}
                  <div>
                    <p className="text-xs font-medium text-slate-600 mb-1.5">Search Category</p>
                    <div className="flex flex-wrap gap-1.5">
                      {(
                        [
                          { id: 'hospitals', label: 'Hospitals' },
                          { id: 'medicines', label: 'Medicines' },
                        ] as const
                      ).map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setSearchScope(opt.id)}
                          className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                            searchScope === opt.id
                              ? 'bg-blue-700 text-white border-blue-700'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {searchScope === 'hospitals' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          State / UT
                        </label>
                        <select
                          value={hospitalFilters.state}
                          onChange={(e) =>
                            setHospitalFilters((prev) => ({ ...prev, state: e.target.value }))
                          }
                          className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                        >
                          <option value="">All States</option>
                          {INDIAN_STATES_AND_UTS.map((st) => (
                            <option key={st} value={st}>
                              {st}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          District
                        </label>
                        <input
                          type="text"
                          value={hospitalFilters.district}
                          onChange={(e) =>
                            setHospitalFilters((prev) => ({ ...prev, district: e.target.value }))
                          }
                          placeholder="e.g., Bengaluru Urban"
                          className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          City / Town
                        </label>
                        <input
                          type="text"
                          value={hospitalFilters.city}
                          onChange={(e) =>
                            setHospitalFilters((prev) => ({ ...prev, city: e.target.value }))
                          }
                          placeholder="e.g., Chennai"
                          className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          PIN Code
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          maxLength={6}
                          value={hospitalFilters.pinCode}
                          onChange={(e) =>
                            setHospitalFilters((prev) => ({
                              ...prev,
                              pinCode: e.target.value.replace(/\D/g, '').slice(0, 6),
                            }))
                          }
                          placeholder="6-digit PIN"
                          className="w-full px-2.5 py-1.5 text-xs font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Facility Type
                        </label>
                        <select
                          value={hospitalFilters.facilityType}
                          onChange={(e) =>
                            setHospitalFilters((prev) => ({
                              ...prev,
                              facilityType: e.target.value,
                            }))
                          }
                          className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg"
                        >
                          <option value="">All Facility Types</option>
                          {FACILITY_TYPES.map((ft) => (
                            <option key={ft} value={ft}>
                              {ft}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => {
                        setGlobalQuery('');
                        setHospitalFilters({
                          q: '',
                          state: '',
                          district: '',
                          city: '',
                          pinCode: '',
                          facilityType: '',
                          verificationFilter: 'all',
                        });
                      }}
                      className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
                    >
                      Reset Filters
                    </button>
                    <button
                      type="button"
                      onClick={handleGlobalSearchSubmit}
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                    >
                      Apply &amp; Search
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Zone 3: Patient Navigation Actions + Prominent Emergency SOS */}
            <div className="flex items-center gap-2 shrink-0">
              {activePatient ? (
                <>
                  <button
                    type="button"
                    onClick={() => setActiveSection('patient-dashboard')}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      activeSection === 'patient-dashboard'
                        ? 'bg-blue-700 text-white border-blue-700'
                        : 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-100'
                    }`}
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span className="max-w-[130px] truncate">{activePatient.fullName}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handlePatientLogout}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Logout</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => setActiveSection('patient-register')}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      activeSection === 'patient-register'
                        ? 'bg-blue-700 text-white border-blue-700'
                        : 'bg-white text-blue-800 border-blue-300 hover:bg-blue-50'
                    }`}
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Patient Register</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveSection('patient-login')}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      activeSection === 'patient-login'
                        ? 'bg-blue-800 text-white border-blue-800'
                        : 'bg-blue-700 text-white border-blue-700 hover:bg-blue-800'
                    }`}
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Patient Login</span>
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={() => setActiveSection('sos')}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Emergency SOS (112)</span>
                <span className="sm:hidden">SOS 112</span>
              </button>
            </div>
          </div>
        </header>

        {/* Main Viewport */}
        <main className="flex-1 px-4 sm:px-6 py-6">
          <div className="max-w-7xl mx-auto">
            {activeSection === 'home' && (
              <OverviewHub
                dbStatus={dbStatus}
                retryingDb={retryingDb}
                onRetryConnection={() => refreshHealth(true)}
                onNavigate={setActiveSection}
                onQuickMedicine={(name) => {
                  setMedicineQuickQuery(name);
                  setActiveSection('medicines');
                }}
              />
            )}

            {activeSection === 'hospitals' && (
              <HospitalFinder
                filters={hospitalFilters}
                onFiltersChange={setHospitalFilters}
                searchTrigger={hospitalSearchTrigger}
              />
            )}

            {activeSection === 'medicines' && <MedicineInfo initialQuery={medicineQuickQuery} />}

            {(activeSection === 'patient-register' ||
              activeSection === 'patient-login' ||
              activeSection === 'patient-dashboard') && (
              <PatientPortal
                mode={
                  activeSection === 'patient-register'
                    ? 'register'
                    : activeSection === 'patient-dashboard'
                    ? 'dashboard'
                    : 'login'
                }
                activePatient={activePatient}
                onModeChange={(next) =>
                  setActiveSection(
                    next === 'register'
                      ? 'patient-register'
                      : next === 'dashboard'
                      ? 'patient-dashboard'
                      : 'patient-login'
                  )
                }
                onLoginSuccess={(patient) => {
                  setActivePatient(patient);
                  setActiveSection('patient-dashboard');
                }}
                onProfileUpdated={(patient) => setActivePatient(patient)}
                onLogout={handlePatientLogout}
                onNavigate={setActiveSection}
              />
            )}

            {activeSection === 'reminders' && (
              <MedicineReminder
                userToken={userToken}
                activeUser={activeUser}
                activePatient={activePatient}
                onGoToPatientAuth={(m) =>
                  setActiveSection(m === 'register' ? 'patient-register' : 'patient-login')
                }
                onUserAuthSuccess={(user, token) => {
                  setActiveUser(user);
                  setUserToken(token);
                }}
                onUserSignOut={() => {
                  if (activePatient) {
                    void handlePatientLogout();
                  } else {
                    setActiveUser(null);
                    setUserToken(null);
                  }
                }}
              />
            )}

            {activeSection === 'sos' && (
              <EmergencySOS
                userToken={userToken}
                activeUser={activeUser}
                activePatient={activePatient}
                onGoToHospitalFinder={() => setActiveSection('hospitals')}
                onGoToSignIn={() => setActiveSection('patient-login')}
              />
            )}

            {activeSection === 'about' && <AboutUs />}

            {activeSection === 'contact' && <ContactUs />}

            {activeSection === 'admin-import' && (
              <AdminHospitalImport
                adminToken={adminToken}
                onAdminTokenChange={setAdminToken}
                onImportComplete={() => {
                  refreshHealth(false);
                  setHospitalSearchTrigger((n) => n + 1);
                }}
                onGoToHospitalFinder={() => {
                  setHospitalSearchTrigger((n) => n + 1);
                  setActiveSection('hospitals');
                }}
                onGoToVerification={() => setActiveSection('admin-verify')}
              />
            )}

            {activeSection === 'admin-verify' && (
              <AdminHospitalVerification
                adminToken={adminToken}
                onAdminTokenChange={setAdminToken}
                onVerificationChanged={() => {
                  refreshHealth(false);
                  setHospitalSearchTrigger((n) => n + 1);
                }}
              />
            )}
          </div>
        </main>

        {/* Quiet Clinical Footer */}
        <footer className="border-t border-slate-200 bg-white px-4 sm:px-6 py-4 mt-8">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-500">
            <p>
              MediBridge AI · Educational healthcare information only. Not a substitute for professional medical advice or emergency services.
            </p>
            <p className="font-mono tabular-nums text-slate-600">
              India Emergency: 112 · Ambulance: 108 · Health Helpline: 104
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
