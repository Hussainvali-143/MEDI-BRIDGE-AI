export function getApiBaseUrl(): string {
  const raw = (import.meta.env?.VITE_API_BASE_URL as string | undefined)?.trim() || '';
  if (!raw) return '';
  return raw.replace(/\/+$/, '');
}

export function buildApiUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) {
    return path;
  }
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const base = getApiBaseUrl();
  return base ? `${base}${normalizedPath}` : normalizedPath;
}

export async function parseApiJsonResponse<T>(res: Response): Promise<T & { error?: string }> {
  const contentType = (res.headers.get('content-type') || '').toLowerCase();
  const rawText = await res.text();

  const looksLikeHtml =
    contentType.includes('text/html') ||
    /^\s*(?:<!doctype\s+html|<html[\s>])/i.test(rawText);

  const isCookieCheckRedirect =
    (res.redirected && res.url.includes('__cookie_check')) ||
    rawText.includes('__cookie_check') ||
    rawText.includes('_aistudio-iframe.js') ||
    rawText.includes('__SECURE-aistudio_auth_flow_may_set_cookies') ||
    rawText.includes('applet-auth-bridge') ||
    /<title>\s*Cookie check\s*<\/title>/i.test(rawText);

  if (contentType.includes('application/json') || contentType.includes('+json')) {
    if (!rawText.trim()) {
      throw new Error(`Server returned an empty JSON response (HTTP ${res.status}).`);
    }
    try {
      return JSON.parse(rawText) as T & { error?: string };
    } catch {
      throw new Error(
        `Server returned malformed JSON (HTTP ${res.status}). Please try again.`
      );
    }
  }

  if (isCookieCheckRedirect) {
    throw new Error(
      `Session verification redirected the API request to an HTML page (HTTP ${res.status}). Refresh this page or open the app in a new browser tab with cookies enabled, then try again.`
    );
  }

  if (looksLikeHtml) {
    throw new Error(
      `API endpoint returned an HTML page instead of JSON (HTTP ${res.status}, Content-Type: ${contentType || 'text/html'}). Verify the backend server is running and serving ${res.url || '/api/*'}, then refresh and try again.`
    );
  }

  if (!rawText.trim()) {
    throw new Error(`Server returned an empty response (HTTP ${res.status}).`);
  }

  if (contentType.startsWith('text/')) {
    const preview = rawText.trim().slice(0, 180);
    throw new Error(
      `Server returned ${contentType.split(';')[0]} instead of JSON (HTTP ${res.status}): ${preview}`
    );
  }

  const trimmed = rawText.trim();
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    try {
      return JSON.parse(trimmed) as T & { error?: string };
    } catch {
      // Fall through to structured error
    }
  }

  throw new Error(
    `Unexpected non-JSON response from server (HTTP ${res.status}, Content-Type: ${contentType || 'missing'}). Please try again.`
  );
}

export async function apiFetchJson<T>(
  path: string,
  init: RequestInit = {},
  fallbackError = 'Request failed. Please try again.'
): Promise<T> {
  const url = buildApiUrl(path);
  const headers = new Headers(init.headers);
  if (!headers.has('Accept')) {
    headers.set('Accept', 'application/json');
  }
  if (!headers.has('X-Requested-With')) {
    headers.set('X-Requested-With', 'MediBridge-SPA');
  }

  let res: Response;
  try {
    res = await fetch(url, {
      credentials: 'same-origin',
      ...init,
      headers,
    });
  } catch (err) {
    const detail = err instanceof Error ? err.message : 'Network error';
    throw new Error(`Unable to reach backend API (${detail}). Check your connection and try again.`);
  }

  const json = await parseApiJsonResponse<T>(res);
  if (!res.ok) {
    const err = new Error(json.error || `${fallbackError} (HTTP ${res.status}).`) as Error & {
      status?: number;
    };
    err.status = res.status;
    throw err;
  }

  return json;
}
