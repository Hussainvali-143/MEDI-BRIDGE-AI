export type VerificationStatus = 'verified' | 'unverified';

export interface DatabaseStatus {
  connected: boolean;
  databaseName: string;
  mode: 'mongodb' | 'preview';
  collections: string[];
  counts: {
    hospitals: number;
    doctors: number;
    medicines: number;
    healthTopics: number;
    patients: number;
    appointments: number;
  };
  envVarsDetected: {
    mongodbUriSet: boolean;
    mongodbUriScheme: 'mongodb+srv' | 'mongodb' | 'invalid' | 'unset';
    mongodbDbName: string;
    uriDiagnostics?: {
      rawHadSurroundingQuotes: boolean;
      rawHadWhitespace: boolean;
      hasUsernameAndPassword: boolean;
      hasAngleBracketPlaceholder: boolean;
      hasUnencodedSpecialCharsInPassword: boolean;
      hasMalformedPercentEncoding: boolean;
      multipleAtSigns: boolean;
      multipleColonsInCredentials: boolean;
      authSourceParam: string | null;
      uriParsesCleanly: boolean;
    };
  };
  errorCategory:
    | 'missing_env'
    | 'atlas_tls_or_ip_whitelist'
    | 'auth_failed'
    | 'dns_srv_failed'
    | 'network_timeout'
    | 'unknown'
    | null;
  diagnosticHint: string | null;
  message: string;
}

export interface HospitalRecord {
  id: string;
  name: string;
  address: string;
  city: string;
  district: string;
  state: string;
  pinCode: string;
  contactNumber: string;
  emergencyNumber?: string;
  facilityType: string;
  verified: boolean;
  sourceLabel: string;
  sourceUrl?: string;
  specialties?: string[];
  website?: string;
  latitude?: number | null;
  longitude?: number | null;
  sourceId?: string;
  officialSourceName?: string;
  officialSourceUrl?: string;
  verificationNotes?: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface AdminHospitalListResponse {
  hospitals: HospitalRecord[];
  totalCount: number;
  verifiedCount: number;
  unverifiedCount: number;
  databaseConnected: boolean;
  databaseName: string;
}

export interface AdminAuthStatus {
  configuredViaEnv: boolean;
  claimedInStore: boolean;
  needsInitialSetup: boolean;
  authenticated: boolean;
}

export type HospitalImportTargetField =
  | 'name'
  | 'state'
  | 'district'
  | 'city'
  | 'pincode'
  | 'address'
  | 'phone'
  | 'facilityType'
  | 'latitude'
  | 'longitude'
  | 'sourceId';

export type CsvColumnMapping = Record<HospitalImportTargetField, string | null>;

export interface MappedHospitalPreviewRow {
  rowNumber: number;
  sourceId: string | null;
  name: string;
  state: string;
  district: string;
  city: string;
  pincode: string;
  address: string;
  phone: string;
  facilityType: string;
  latitude: number | null;
  longitude: number | null;
  verified: false;
  valid: boolean;
  validationIssue?: string;
}

export interface HospitalCsvPreviewResponse {
  fileName: string;
  totalRows: number;
  headers: string[];
  columnMapping: CsvColumnMapping;
  previewRows: MappedHospitalPreviewRow[];
  invalidRowCountInPreview: number;
  databaseConnected: boolean;
  targetDatabase: string;
  targetCollection: string;
}

export interface HospitalImportProgressEvent {
  type: 'progress' | 'complete' | 'error';
  totalRows: number;
  processedRows: number;
  insertedCount: number;
  skippedCount: number;
  failedCount: number;
  currentBatch: number;
  totalBatches: number;
  sampleErrors: string[];
  error?: string;
}

export interface HospitalSearchResponse {
  verified: HospitalRecord[];
  unverified: HospitalRecord[];
  databaseConnected: boolean;
  databaseName: string;
  availableStates: string[];
  availableFacilityTypes: string[];
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface WebHospitalSearchResponse {
  results: HospitalRecord[];
  sources: GroundingSource[];
  note: string;
  disclaimer: string;
}

export interface DoctorRecord {
  id: string;
  name: string;
  specialty: string;
  qualification?: string;
  hospitalAffiliation: string;
  city: string;
  state: string;
  contactNumber: string;
  email?: string;
  consultationHours?: string;
  verified: boolean;
  sourceLabel: string;
  registrationNumber?: string;
}

export interface DoctorSearchResponse {
  verified: DoctorRecord[];
  unverified: DoctorRecord[];
  databaseConnected: boolean;
  availableSpecialties: string[];
}

export interface PharmacistVerifiedMedicine {
  id: string;
  name: string;
  genericName: string;
  drugClass: string;
  dosageForms?: string;
  pharmacistNotes: string;
  commonUses: string[];
  warnings: string[];
  verifiedBy?: string;
  verifiedDate?: string;
}

export interface MedicineDatabaseRecord {
  id: string;
  name: string;
  genericName: string;
  brandNames: string[];
  drugClass: string;
  medicineCategory?: string;
  strength?: string;
  formulation?: string;
  packSize?: string;
  dosageForms?: string;
  manufacturer?: string;
  activeIngredients?: string;
  prescriptionClassification?: string;
  officialSourceName?: string;
  sourceUrl?: string;
  lastCheckedDate?: string;
  pharmacistNotes: string;
  commonUses: string[];
  warnings: string[];
  verified: boolean;
  sourceLabel: string;
  verifiedBy?: string;
  verifiedDate?: string;
  matchType?: 'exact' | 'related';
  matchNote?: string;
}

export interface MedicineImportSummary {
  totalCandidates: number;
  newlyImported: number;
  duplicatesSkipped: number;
  rejectedCount: number;
  verifiedImported: number;
  unverifiedImported: number;
  byCategory: Record<string, number>;
  totalInCollection: number;
  verifiedInCollection: number;
  unverifiedInCollection: number;
  storageStats?: {
    dataSizeMB: number;
    storageSizeMB: number;
    indexSizeMB: number;
  };
}

export interface EducationalMedicineInfo {
  medicineName: string;
  activeIngredients: string;
  drugClass: string;
  generalUses: string[];
  howTypicallyTaken: string;
  safetyAndStorageNotes?: string;
  commonSideEffects: string[];
  importantPrecautions: string[];
  whenToSeekUrgentHelp: string[];
  disclaimer: string;
}

export interface MedicineLookupResponse {
  query: string;
  verifiedRecords: MedicineDatabaseRecord[];
  unverifiedRecords: MedicineDatabaseRecord[];
  exactMatchesCount?: number;
  relatedMatchesCount?: number;
  searchSummary?: string;
  pharmacistVerified?: PharmacistVerifiedMedicine[];
  educationalInfo: EducationalMedicineInfo | null;
  aiNotice?: string;
  databaseConnected: boolean;
  databaseName?: string;
  medicalWarning: string;
}

export interface CuratedHealthTopic {
  id: string;
  title: string;
  category: string;
  summary: string;
  verifiedBy?: string;
}

export interface EducationalHealthTopic {
  topic: string;
  category: string;
  overview: string;
  commonCausesAndRiskFactors: string[];
  commonSymptoms: string[];
  preventiveAndSelfCareGuidance: string[];
  whenToConsultDoctor: string[];
  disclaimer: string;
}

export interface HealthTopicResponse {
  query: string;
  curatedRecords: CuratedHealthTopic[];
  educationalGuide: EducationalHealthTopic | null;
  databaseConnected: boolean;
}

export interface CuratedTestRecord {
  id: string;
  testName: string;
  category: string;
  purpose: string;
}

export interface EducationalHealthTest {
  testName: string;
  commonAliases: string[];
  category: string;
  whatItMeasures: string;
  generalPurpose: string;
  commonParameters: Array<{
    parameter: string;
    roleInBody: string;
  }>;
  generalPreparationNotes: string[];
  questionsForDoctor: string[];
  nonDiagnosticNotice: string;
}

export interface HealthReportEducationResponse {
  query: string;
  sourceType?: 'text' | 'document';
  uploadedFileName?: string;
  curatedRecords: CuratedTestRecord[];
  educationalExplanation: EducationalHealthTest | null;
  databaseConnected: boolean;
}

export interface PatientRecord {
  patientId: string;
  fullName: string;
  age: number;
  gender: string;
  phone: string;
  email?: string;
  bloodGroup?: string;
  emergencyContact?: string;
  address: string;
  city: string;
  district: string;
  state: string;
  pinCode: string;
  allergiesOrConditions?: string;
  createdAt: string;
  storageMode: 'mongodb' | 'preview';
}

export type AppointmentStatus =
  | 'Requested'
  | 'Pending Facility Confirmation'
  | 'Confirmed'
  | 'Cancelled';

export interface AppointmentRecord {
  bookingRef: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  hospitalName: string;
  hospitalCity?: string;
  doctorName?: string;
  specialty?: string;
  preferredDate: string;
  preferredWindow: string;
  visitType: 'In-Person' | 'Teleconsultation';
  reason: string;
  status: AppointmentStatus;
  statusNote: string;
  createdAt: string;
  updatedAt: string;
  storageMode: 'mongodb' | 'preview';
}

export interface AuthenticatedUser {
  id: string;
  fullName: string;
  email: string;
  patientId?: string;
}

export type PatientAccountStatus = 'active' | 'suspended';

export interface PatientAccountProfile {
  patientId: string;
  fullName: string;
  dateOfBirth: string;
  age?: number;
  gender?: string;
  mobileNumber: string;
  email?: string;
  address?: string;
  registrationDate: string;
  accountStatus: PatientAccountStatus;
  storageMode: 'mongodb' | 'preview';
}

export type ReminderActionStatus = 'pending' | 'completed' | 'skipped';

export interface MedicineReminderRecord {
  id: string;
  userId: string;
  reminderName: string;
  medicineName: string;
  prescribedSchedule: string;
  reminderTimes: string[];
  selectedDates: string[];
  startDate: string;
  endDate: string;
  status: ReminderActionStatus;
  lastActionAt?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  storageMode: 'mongodb' | 'preview';
}

export interface EmergencyContactRecord {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  createdAt: string;
  storageMode: 'mongodb' | 'session';
}

