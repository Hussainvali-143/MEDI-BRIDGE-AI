import React, { useEffect, useState } from 'react';
import { CalendarCheck, CalendarPlus, CheckCircle2, Info, Search, XCircle } from 'lucide-react';
import { apiFetchJson } from '../utils/apiClient';
import type { AppointmentRecord, AppointmentStatus, PatientRecord } from '../types/healthcare';

interface AppointmentPrefill {
  hospitalName?: string;
  hospitalCity?: string;
  doctorName?: string;
  specialty?: string;
}

interface AppointmentBookingProps {
  activePatient: PatientRecord | null;
  prefill: AppointmentPrefill | null;
  onGoToRegistration: () => void;
}

const PREFERRED_WINDOWS = [
  'Morning (9:00 AM – 12:00 PM)',
  'Afternoon (12:00 PM – 4:00 PM)',
  'Evening (4:00 PM – 7:00 PM)',
];

export const AppointmentBooking: React.FC<AppointmentBookingProps> = ({
  activePatient,
  prefill,
  onGoToRegistration,
}) => {
  const [patientId, setPatientId] = useState(activePatient?.patientId || '');
  const [hospitalName, setHospitalName] = useState(prefill?.hospitalName || '');
  const [hospitalCity, setHospitalCity] = useState(prefill?.hospitalCity || '');
  const [doctorName, setDoctorName] = useState(prefill?.doctorName || '');
  const [specialty, setSpecialty] = useState(prefill?.specialty || '');
  const [preferredDate, setPreferredDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [preferredWindow, setPreferredWindow] = useState(PREFERRED_WINDOWS[0]);
  const [visitType, setVisitType] = useState<'In-Person' | 'Teleconsultation'>('In-Person');
  const [reason, setReason] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [createdBooking, setCreatedBooking] = useState<AppointmentRecord | null>(null);

  const [filterPatientId, setFilterPatientId] = useState('');
  const [appointments, setAppointments] = useState<AppointmentRecord[]>([]);
  const [loadingList, setLoadingList] = useState(true);

  useEffect(() => {
    if (activePatient?.patientId) {
      setPatientId(activePatient.patientId);
    }
  }, [activePatient]);

  useEffect(() => {
    if (prefill) {
      if (prefill.hospitalName) setHospitalName(prefill.hospitalName);
      if (prefill.hospitalCity) setHospitalCity(prefill.hospitalCity);
      if (prefill.doctorName) setDoctorName(prefill.doctorName);
      if (prefill.specialty) setSpecialty(prefill.specialty);
    }
  }, [prefill]);

  const fetchAppointments = async (pid = filterPatientId) => {
    setLoadingList(true);
    try {
      const params = new URLSearchParams();
      if (pid.trim()) params.set('patientId', pid.trim());
      const json = await apiFetchJson<{ appointments?: AppointmentRecord[] }>(
        `/api/appointments?${params.toString()}`,
        { method: 'GET' },
        'Unable to load appointments.'
      );
      if (Array.isArray(json.appointments)) {
        setAppointments(json.appointments);
      }
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Unable to load appointments.');
    } finally {
      setLoadingList(false);
    }
  };

  useEffect(() => {
    fetchAppointments('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError(null);
    try {
      const json = await apiFetchJson<{ appointment: AppointmentRecord }>(
        '/api/appointments',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            patientId,
            hospitalName,
            hospitalCity,
            doctorName,
            specialty,
            preferredDate,
            preferredWindow,
            visitType,
            reason,
          }),
        },
        'Unable to submit appointment request.'
      );

      const created = json.appointment;
      setCreatedBooking(created);
      setReason('');
      fetchAppointments(filterPatientId);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Unable to book appointment.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUpdateStatus = async (bookingRef: string, status: AppointmentStatus) => {
    try {
      await apiFetchJson<{ appointment: AppointmentRecord }>(
        `/api/appointments/${encodeURIComponent(bookingRef)}/status`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status }),
        },
        'Unable to update appointment status.'
      );
      fetchAppointments(filterPatientId);
    } catch {
      // Handled gracefully
    }
  };

  const getStatusBadgeStyle = (status: AppointmentStatus) => {
    switch (status) {
      case 'Confirmed':
        return 'text-emerald-800 bg-emerald-50 border-emerald-200';
      case 'Pending Facility Confirmation':
        return 'text-blue-800 bg-blue-50 border-blue-200';
      case 'Cancelled':
        return 'text-red-800 bg-red-50 border-red-200';
      default:
        return 'text-amber-800 bg-amber-50 border-amber-200';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left: Appointment Request Form */}
      <section className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6 space-y-5 h-fit">
        <div className="border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
            <CalendarPlus className="w-4 h-4" />
            <span>Appointment Request</span>
          </div>
          <h2 className="text-lg font-semibold text-slate-900 mt-1">
            Request a Healthcare Appointment
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            Submit an appointment request linked to a registered Patient ID and track its confirmation status.
          </p>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-blue-900">
          <Info className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
          <span>
            Selecting a preferred date and time window submits an <strong>Appointment Request</strong>. Live hospital slot availability is not simulated—confirm final timing directly with the hospital desk.
          </span>
        </div>

        {createdBooking && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-900 font-semibold text-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              <span>Appointment Request Submitted</span>
            </div>
            <p className="text-xs text-emerald-800 font-mono tabular-nums">
              Booking Reference: <strong>{createdBooking.bookingRef}</strong> · Status: {createdBooking.status}
            </p>
          </div>
        )}

        {submitError && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 text-sm text-red-800 space-y-2">
            <p>{submitError}</p>
            {submitError.includes('Patient ID') && (
              <button
                type="button"
                onClick={onGoToRegistration}
                className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
              >
                Go to Patient Registration &rarr;
              </button>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-medium text-slate-700">
                Registered Patient ID <span className="text-red-600">*</span>
              </label>
              <button
                type="button"
                onClick={onGoToRegistration}
                className="text-xs font-medium text-blue-700 hover:underline cursor-pointer"
              >
                Need a Patient ID? Register
              </button>
            </div>
            <input
              type="text"
              required
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              placeholder="e.g., MB-IN-2026-A1B2C3"
              className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Hospital / Clinic Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                value={hospitalName}
                onChange={(e) => setHospitalName(e.target.value)}
                placeholder="Select from Hospital Finder or enter facility name"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
              <input
                type="text"
                value={hospitalCity}
                onChange={(e) => setHospitalCity(e.target.value)}
                placeholder="City"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Doctor Name (Optional)
              </label>
              <input
                type="text"
                value={doctorName}
                onChange={(e) => setDoctorName(e.target.value)}
                placeholder="Preferred doctor"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Department / Specialty
              </label>
              <input
                type="text"
                value={specialty}
                onChange={(e) => setSpecialty(e.target.value)}
                placeholder="e.g., General Medicine"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Visit Type <span className="text-red-600">*</span>
              </label>
              <select
                value={visitType}
                onChange={(e) =>
                  setVisitType(e.target.value === 'Teleconsultation' ? 'Teleconsultation' : 'In-Person')
                }
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              >
                <option value="In-Person">In-Person Consultation</option>
                <option value="Teleconsultation">Teleconsultation</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Preferred Date <span className="text-red-600">*</span>
              </label>
              <input
                type="date"
                required
                value={preferredDate}
                onChange={(e) => setPreferredDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Preferred Window <span className="text-red-600">*</span>
              </label>
              <select
                value={preferredWindow}
                onChange={(e) => setPreferredWindow(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              >
                {PREFERRED_WINDOWS.map((w) => (
                  <option key={w} value={w}>
                    {w}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Reason for Consultation <span className="text-red-600">*</span>
              </label>
              <textarea
                rows={3}
                required
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Briefly describe symptoms or consultation purpose"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
          >
            {submitting ? 'Submitting Request...' : 'Submit Appointment Request'}
          </button>
        </form>
      </section>

      {/* Right: Booking Status Tracker */}
      <section className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
            <CalendarCheck className="w-4 h-4" />
            <span>Booking Status</span>
          </div>
          <h3 className="text-base font-semibold text-slate-900 mt-1">
            Appointment Requests &amp; Status Tracker
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            Track submitted requests by Patient ID. Existing records are always preserved.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchAppointments(filterPatientId);
          }}
          className="flex gap-2"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={filterPatientId}
              onChange={(e) => setFilterPatientId(e.target.value)}
              placeholder="Filter by Patient ID (leave empty for all)"
              className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>
          <button
            type="submit"
            className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
          >
            Filter
          </button>
        </form>

        {loadingList ? (
          <div className="space-y-3 animate-pulse">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-slate-100 rounded-xl" />
            ))}
          </div>
        ) : appointments.length > 0 ? (
          <div className="space-y-3">
            {appointments.map((apt) => (
              <div key={apt.bookingRef} className="border border-slate-200 rounded-xl p-4 space-y-2.5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <p className="text-xs font-mono tabular-nums text-slate-500">
                      {apt.bookingRef} · {apt.patientId}
                    </p>
                    <h4 className="text-sm font-semibold text-slate-900 mt-0.5">
                      {apt.hospitalName}
                    </h4>
                    <p className="text-xs text-slate-600">
                      Patient: {apt.patientName}
                      {apt.doctorName ? ` · ${apt.doctorName}` : ''}
                      {apt.specialty ? ` (${apt.specialty})` : ''}
                    </p>
                  </div>

                  <span
                    className={`px-2.5 py-1 text-xs font-semibold border rounded-md whitespace-nowrap ${getStatusBadgeStyle(
                      apt.status
                    )}`}
                  >
                    {apt.status}
                  </span>
                </div>

                <div className="text-xs text-slate-600 tabular-nums flex flex-wrap gap-x-3 gap-y-1">
                  <span>Preferred Date: {apt.preferredDate}</span>
                  <span>·</span>
                  <span>{apt.preferredWindow}</span>
                  <span>·</span>
                  <span>{apt.visitType}</span>
                </div>

                <p className="text-xs text-slate-700 bg-slate-50 rounded-lg p-2.5">
                  <span className="font-medium">Reason:</span> {apt.reason}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <span className="text-xs text-slate-500">{apt.statusNote}</span>
                  {apt.status !== 'Cancelled' && (
                    <div className="flex items-center gap-2">
                      {apt.status === 'Requested' && (
                        <button
                          type="button"
                          onClick={() =>
                            handleUpdateStatus(apt.bookingRef, 'Pending Facility Confirmation')
                          }
                          className="px-2.5 py-1 text-xs font-medium text-blue-700 border border-blue-200 rounded-md hover:bg-blue-50 cursor-pointer"
                        >
                          Mark Sent to Facility
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => handleUpdateStatus(apt.bookingRef, 'Cancelled')}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-red-700 border border-red-200 rounded-md hover:bg-red-50 cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        Cancel Request
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-600">
            No appointment requests found yet. Submit a request on the left using a registered Patient ID.
          </div>
        )}
      </section>
    </div>
  );
};
