import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Globe,
  KeyRound,
  Lock,
  LogOut,
  MapPin,
  Phone,
  Search,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import { INDIAN_STATES_AND_UTS } from '../data/indianLocations';
import { apiFetchJson } from '../utils/apiClient';
import type {
  AdminAuthStatus,
  AdminHospitalListResponse,
  HospitalRecord,
  WebHospitalSearchResponse,
} from '../types/healthcare';

interface AdminHospitalVerificationProps {
  adminToken: string | null;
  onAdminTokenChange: (token: string | null) => void;
  onVerificationChanged?: () => void;
}

const OFFICIAL_SOURCE_PRESETS = [
  'National Health Portal / NIN Registry',
  'ABDM Health Facility Registry (HFR)',
  'State Health Department Directory',
  'Official Hospital Website',
];

export const AdminHospitalVerification: React.FC<AdminHospitalVerificationProps> = ({
  adminToken,
  onAdminTokenChange,
  onVerificationChanged,
}) => {
  const [authStatus, setAuthStatus] = useState<AdminAuthStatus | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [passcodeInput, setPasscodeInput] = useState('');
  const [confirmPasscodeInput, setConfirmPasscodeInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [q, setQ] = useState('');
  const [stateFilter, setStateFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<'unverified' | 'verified' | 'all'>('unverified');
  const [data, setData] = useState<AdminHospitalListResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Active hospital selected for verification review
  const [reviewingHospital, setReviewingHospital] = useState<HospitalRecord | null>(null);
  const [officialSourceName, setOfficialSourceName] = useState('');
  const [officialSourceUrl, setOfficialSourceUrl] = useState('');
  const [verificationNotes, setVerificationNotes] = useState('');
  const [checkedOfficialSource, setCheckedOfficialSource] = useState(false);
  const [submittingVerify, setSubmittingVerify] = useState(false);
  const [verifyError, setVerifyError] = useState<string | null>(null);

  const [lookupLoading, setLookupLoading] = useState(false);
  const [lookupResult, setLookupResult] = useState<WebHospitalSearchResponse | null>(null);
  const [lookupError, setLookupError] = useState<string | null>(null);

  const fetchAuthStatus = async (tokenToUse = adminToken) => {
    setAuthLoading(true);
    try {
      const headers: Record<string, string> = {};
      if (tokenToUse) headers.Authorization = `Bearer ${tokenToUse}`;
      const json = await apiFetchJson<AdminAuthStatus>(
        '/api/admin/auth/status',
        { headers },
        'Unable to verify admin session.'
      );
      setAuthStatus(json);
      if (!json.authenticated && tokenToUse) {
        onAdminTokenChange(null);
      }
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Unable to verify admin session.');
    } finally {
      setAuthLoading(false);
    }
  };

  const fetchAdminHospitals = async (
    tokenToUse = adminToken,
    overrideStatus = statusFilter
  ) => {
    if (!tokenToUse) return;
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (q.trim()) params.set('q', q.trim());
      if (stateFilter) params.set('state', stateFilter);
      params.set('status', overrideStatus);
      params.set('limit', '50');

      const json = await apiFetchJson<AdminHospitalListResponse>(
        `/api/admin/hospitals?${params.toString()}`,
        { headers: { Authorization: `Bearer ${tokenToUse}` } },
        'Unable to load hospitals.'
      );
      setData(json);
    } catch (err) {
      if ((err as { status?: number })?.status === 401) {
        onAdminTokenChange(null);
        await fetchAuthStatus(null);
      }
      setError(err instanceof Error ? err.message : 'Unable to load hospitals.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuthStatus(adminToken);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (authStatus?.authenticated && adminToken) {
      fetchAdminHospitals(adminToken, statusFilter);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authStatus?.authenticated, statusFilter]);

  const handleInitialSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (passcodeInput.length < 8) {
      setAuthError('Passcode must be at least 8 characters long.');
      return;
    }
    if (passcodeInput !== confirmPasscodeInput) {
      setAuthError('Passcodes do not match.');
      return;
    }
    setAuthSubmitting(true);
    try {
      const json = await apiFetchJson<{ token: string }>(
        '/api/admin/auth/setup',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ passcode: passcodeInput }),
        },
        'Setup failed.'
      );
      onAdminTokenChange(json.token);
      setPasscodeInput('');
      setConfirmPasscodeInput('');
      await fetchAuthStatus(json.token);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Setup failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSubmitting(true);
    try {
      const json = await apiFetchJson<{ token: string }>(
        '/api/admin/auth/login',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ passcode: passcodeInput }),
        },
        'Invalid passcode.'
      );
      onAdminTokenChange(json.token);
      setPasscodeInput('');
      await fetchAuthStatus(json.token);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const openReviewPanel = (hospital: HospitalRecord) => {
    setReviewingHospital(hospital);
    setOfficialSourceName(hospital.officialSourceName || '');
    setOfficialSourceUrl(hospital.officialSourceUrl || hospital.website || '');
    setVerificationNotes(hospital.verificationNotes || '');
    setCheckedOfficialSource(false);
    setVerifyError(null);
    setLookupResult(null);
    setLookupError(null);
  };

  const handleLookupOfficialSources = async (hospital: HospitalRecord) => {
    if (!adminToken) return;
    setLookupLoading(true);
    setLookupError(null);
    try {
      const json = await apiFetchJson<WebHospitalSearchResponse>(
        '/api/admin/hospitals/lookup-official',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${adminToken}`,
          },
          body: JSON.stringify({
            name: hospital.name,
            city: hospital.city,
            state: hospital.state,
            pinCode: hospital.pinCode,
          }),
        },
        'Official source lookup failed.'
      );
      setLookupResult(json);
    } catch (err) {
      setLookupError(err instanceof Error ? err.message : 'Unable to look up official sources.');
    } finally {
      setLookupLoading(false);
    }
  };

  const handleConfirmVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewingHospital || !adminToken) return;
    setSubmittingVerify(true);
    setVerifyError(null);
    try {
      await apiFetchJson<{ hospital: HospitalRecord }>(
        `/api/admin/hospitals/${encodeURIComponent(reviewingHospital.id)}/verify`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${adminToken}`,
          },
          body: JSON.stringify({
            verified: true,
            checkedOfficialSource,
            officialSourceName,
            officialSourceUrl,
            verificationNotes,
          }),
        },
        'Verification failed.'
      );

      setReviewingHospital(null);
      await fetchAdminHospitals(adminToken, statusFilter);
      if (onVerificationChanged) onVerificationChanged();
    } catch (err) {
      setVerifyError(err instanceof Error ? err.message : 'Unable to verify hospital.');
    } finally {
      setSubmittingVerify(false);
    }
  };

  const handleRevertToUnverified = async (hospital: HospitalRecord) => {
    if (!adminToken) return;
    setError(null);
    try {
      await apiFetchJson<{ hospital: HospitalRecord }>(
        `/api/admin/hospitals/${encodeURIComponent(hospital.id)}/verify`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${adminToken}`,
          },
          body: JSON.stringify({
            verified: false,
            verificationNotes: 'Marked unverified by admin for re-verification.',
          }),
        },
        'Unable to update status.'
      );
      await fetchAdminHospitals(adminToken, statusFilter);
      if (onVerificationChanged) onVerificationChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update status.');
    }
  };

  if (authLoading) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-8 text-sm text-slate-600">
        Verifying Admin Dashboard session...
      </div>
    );
  }

  if (!authStatus?.authenticated) {
    return (
      <div className="max-w-lg mx-auto bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="border-b border-slate-100 pb-4 space-y-1">
          <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
            <Lock className="w-4 h-4" />
            <span>Admin Dashboard · Hospital Verification</span>
          </div>
          <h2 className="text-lg font-semibold text-slate-900">
            {authStatus?.needsInitialSetup
              ? 'Set Initial Admin Passcode'
              : 'Admin Sign-In Required'}
          </h2>
          <p className="text-sm text-slate-600">
            {authStatus?.needsInitialSetup
              ? 'Claim an admin passcode (min. 8 characters) to review and verify hospitals against official sources.'
              : 'Sign in with your administrator passcode to review unverified hospital records and confirm official source checks.'}
          </p>
        </div>

        {authError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
            {authError}
          </div>
        )}

        {authStatus?.needsInitialSetup ? (
          <form onSubmit={handleInitialSetup} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                New Admin Passcode
              </label>
              <input
                type="password"
                required
                minLength={8}
                value={passcodeInput}
                onChange={(e) => setPasscodeInput(e.target.value)}
                placeholder="Minimum 8 characters"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Confirm Passcode
              </label>
              <input
                type="password"
                required
                minLength={8}
                value={confirmPasscodeInput}
                onChange={(e) => setConfirmPasscodeInput(e.target.value)}
                placeholder="Re-enter passcode"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
            <button
              type="submit"
              disabled={authSubmitting}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              {authSubmitting ? 'Setting Passcode...' : 'Claim Admin Access'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Admin Passcode
              </label>
              <input
                type="password"
                required
                value={passcodeInput}
                onChange={(e) => setPasscodeInput(e.target.value)}
                placeholder="Enter admin passcode"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
            <button
              type="submit"
              disabled={authSubmitting}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              {authSubmitting ? 'Verifying...' : 'Sign In to Admin Dashboard'}
            </button>
          </form>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-700">Admin Dashboard</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-0.5">
            Hospital Verification Workflow
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            All imported records start as <strong>Unverified</strong>. An authorized admin may mark a hospital <strong>Verified</strong> only after confirming its details against an official source. All existing fields are preserved.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            onAdminTokenChange(null);
            fetchAuthStatus(null);
          }}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign Out
        </button>
      </section>

      {/* Counts Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Total Hospitals in Medi_Bridge</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {data?.totalCount.toLocaleString() ?? 0}
          </p>
        </div>
        <div className="bg-white border border-emerald-200 rounded-xl p-4">
          <p className="text-xs font-medium text-emerald-800">Verified Hospitals</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-emerald-900 mt-1">
            {data?.verifiedCount.toLocaleString() ?? 0}
          </p>
        </div>
        <div className="bg-white border border-amber-200 rounded-xl p-4">
          <p className="text-xs font-medium text-amber-800">Pending / Unverified</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-amber-900 mt-1">
            {data?.unverifiedCount.toLocaleString() ?? 0}
          </p>
        </div>
      </section>

      {/* Search & Queue Filters */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchAdminHospitals(adminToken, statusFilter);
          }}
          className="grid grid-cols-1 md:grid-cols-12 gap-3"
        >
          <div className="md:col-span-5">
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Search Name, City, PIN Code, or Source ID
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="e.g., AIIMS, 110029, NIN-..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-slate-700 mb-1">State / UT</label>
            <select
              value={stateFilter}
              onChange={(e) => setStateFilter(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            >
              <option value="">All States</option>
              {INDIAN_STATES_AND_UTS.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          <div className="md:col-span-2 flex items-end">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-full">
              {(['unverified', 'verified', 'all'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setStatusFilter(tab)}
                  className={`flex-1 px-2 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    statusFilter === tab
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab === 'unverified' ? 'Unverified' : tab === 'verified' ? 'Verified' : 'All'}
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-2 flex items-end">
            <button
              type="submit"
              className="w-full px-4 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
            >
              Filter Queue
            </button>
          </div>
        </form>
      </section>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {data && !data.databaseConnected && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-950">
          MongoDB Atlas (<span className="font-mono">Medi_Bridge</span>) is not currently connected. Connect <span className="font-mono">MONGODB_URI</span> to review and verify hospital records.
        </div>
      )}

      {/* Official Source Verification Drawer / Modal Card */}
      {reviewingHospital && (
        <section className="bg-white border-2 border-blue-600 rounded-xl p-6 space-y-5">
          <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <p className="text-xs font-semibold text-blue-700">
                Official Source Verification Check
              </p>
              <h3 className="text-lg font-semibold text-slate-900 mt-0.5">
                {reviewingHospital.name}
              </h3>
              <p className="text-xs text-slate-600 mt-1 tabular-nums">
                {reviewingHospital.facilityType} · {reviewingHospital.address} ·{' '}
                {[reviewingHospital.city, reviewingHospital.district, reviewingHospital.state]
                  .filter(Boolean)
                  .join(', ')}
                {reviewingHospital.pinCode ? ` — PIN ${reviewingHospital.pinCode}` : ''} · Phone:{' '}
                <span className="font-mono">{reviewingHospital.contactNumber}</span>
              </p>
            </div>
            <button
              type="button"
              onClick={() => setReviewingHospital(null)}
              className="text-xs font-medium text-slate-500 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>
          </div>

          {/* Helper to look up official links (read-only) */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs font-semibold text-slate-800">
                  Step 1: Cross-Check Against an Official Source
                </p>
                <p className="text-xs text-slate-600 mt-0.5">
                  Look up official government registries (.gov.in, NIN, HFR) or the hospital&apos;s official website before verifying.
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleLookupOfficialSources(reviewingHospital)}
                disabled={lookupLoading}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-white border border-blue-200 hover:bg-blue-50 disabled:opacity-50 rounded-lg whitespace-nowrap cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5" />
                {lookupLoading ? 'Searching Official Links...' : 'Find Official Source Links'}
              </button>
            </div>

            {lookupError && <p className="text-xs text-red-700">{lookupError}</p>}

            {lookupResult && (
              <div className="space-y-2 pt-2 border-t border-slate-200">
                {lookupResult.results.length > 0 && (
                  <div className="space-y-1.5">
                    {lookupResult.results.slice(0, 3).map((item) => (
                      <div key={item.id} className="text-xs bg-white border border-slate-200 rounded-lg p-2.5">
                        <p className="font-semibold text-slate-900">{item.name}</p>
                        <p className="text-slate-600">
                          {item.address} · Phone: <span className="font-mono">{item.contactNumber}</span>
                        </p>
                      </div>
                    ))}
                  </div>
                )}
                {lookupResult.sources.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {lookupResult.sources.map((src) => (
                      <button
                        key={src.uri}
                        type="button"
                        onClick={() => setOfficialSourceUrl(src.uri)}
                        className="inline-flex items-center gap-1 text-xs text-blue-700 hover:underline bg-white border border-slate-200 px-2 py-1 rounded cursor-pointer"
                        title="Click to use this URL as Official Source URL, or open link"
                      >
                        <span>Use: {src.title}</span>
                        <a
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          aria-label={`Open ${src.title}`}
                        >
                          <ExternalLink className="w-3 h-3 inline" />
                        </a>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {verifyError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
              {verifyError}
            </div>
          )}

          <form onSubmit={handleConfirmVerification} className="space-y-4">
            <div className="space-y-2">
              <label className="block text-xs font-medium text-slate-700">
                Official Source Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                minLength={3}
                value={officialSourceName}
                onChange={(e) => setOfficialSourceName(e.target.value)}
                placeholder="e.g., National Health Portal / NIN Registry"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
              <div className="flex flex-wrap gap-1.5">
                {OFFICIAL_SOURCE_PRESETS.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setOfficialSourceName(preset)}
                    className="px-2.5 py-1 text-xs text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md cursor-pointer"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Official Source URL (Optional, https://)
                </label>
                <input
                  type="url"
                  value={officialSourceUrl}
                  onChange={(e) => setOfficialSourceUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Admin Verification Notes (Optional)
                </label>
                <input
                  type="text"
                  value={verificationNotes}
                  onChange={(e) => setVerificationNotes(e.target.value)}
                  placeholder="e.g., Verified phone and address on official portal"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
            </div>

            <label className="flex items-start gap-2.5 p-3 bg-blue-50 border border-blue-200 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={checkedOfficialSource}
                onChange={(e) => setCheckedOfficialSource(e.target.checked)}
                className="mt-0.5 w-4 h-4 accent-blue-700"
              />
              <span className="text-xs text-blue-950 leading-relaxed">
                I confirm that I have personally checked this hospital&apos;s name, address, contact information, and facility type against the official source specified above, and no missing details were invented.
              </span>
            </label>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setReviewingHospital(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submittingVerify || !checkedOfficialSource || officialSourceName.trim().length < 3}
                className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                {submittingVerify ? 'Saving Verification...' : 'Confirm & Mark Verified'}
              </button>
            </div>
          </form>
        </section>
      )}

      {/* Hospital Queue List */}
      {loading ? (
        <div className="space-y-3 animate-pulse">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-white border border-slate-200 rounded-xl" />
          ))}
        </div>
      ) : data && data.hospitals.length > 0 ? (
        <div className="space-y-3">
          {data.hospitals.map((hospital) => (
            <article
              key={hospital.id}
              className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
            >
              <div className="space-y-1.5 min-w-0">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 font-semibold border rounded ${
                      hospital.verified
                        ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                        : 'text-amber-800 bg-amber-50 border-amber-200'
                    }`}
                  >
                    {hospital.verified ? (
                      <>
                        <ShieldCheck className="w-3.5 h-3.5" />
                        Verified
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-3.5 h-3.5" />
                        Unverified
                      </>
                    )}
                  </span>
                  <span className="text-slate-600">{hospital.facilityType}</span>
                  {hospital.sourceId && (
                    <span className="font-mono text-slate-500">· ID: {hospital.sourceId}</span>
                  )}
                </div>

                <h3 className="text-base font-semibold text-slate-900">{hospital.name}</h3>

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-blue-600" />
                    {hospital.address}
                    {[hospital.city, hospital.district, hospital.state].filter(Boolean).length > 0 &&
                      ` (${[hospital.city, hospital.district, hospital.state].filter(Boolean).join(', ')})`}
                    {hospital.pinCode ? ` — PIN ${hospital.pinCode}` : ''}
                  </span>
                  <span className="inline-flex items-center gap-1 font-mono tabular-nums">
                    <Phone className="w-3.5 h-3.5 text-blue-600" />
                    {hospital.contactNumber}
                  </span>
                </div>

                {hospital.verified && hospital.officialSourceName && (
                  <p className="text-xs text-emerald-800 pt-1">
                    Source: <strong>{hospital.officialSourceName}</strong>
                    {hospital.verifiedAt ? ` · Verified ${new Date(hospital.verifiedAt).toLocaleDateString()}` : ''}
                    {hospital.officialSourceUrl && (
                      <>
                        {' · '}
                        <a
                          href={hospital.officialSourceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-700 hover:underline inline-flex items-center gap-0.5"
                        >
                          Official Link <ExternalLink className="w-3 h-3" />
                        </a>
                      </>
                    )}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {hospital.verified ? (
                  <button
                    type="button"
                    onClick={() => handleRevertToUnverified(hospital)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg whitespace-nowrap cursor-pointer"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    Mark Unverified
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => openReviewPanel(hospital)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    Verify Against Official Source
                  </button>
                )}
              </div>
            </article>
          ))}
        </div>
      ) : (
        !loading && (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-600">
            No hospitals matched the current verification queue filters.
          </div>
        )
      )}
    </div>
  );
};
