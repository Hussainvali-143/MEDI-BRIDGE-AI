import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Bell,
  Building2,
  CalendarCheck,
  CalendarPlus,
  CheckCircle2,
  Copy,
  Edit3,
  Eye,
  EyeOff,
  HelpCircle,
  KeyRound,
  LogIn,
  LogOut,
  Pill,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  UserPlus,
  X,
} from 'lucide-react';
import { apiFetchJson } from '../utils/apiClient';
import type {
  AppointmentRecord,
  PatientAccountProfile,
} from '../types/healthcare';
import type { NavSection } from './OverviewHub';

interface PatientPortalProps {
  mode: 'register' | 'login' | 'dashboard';
  activePatient: PatientAccountProfile | null;
  onModeChange: (next: 'register' | 'login' | 'dashboard') => void;
  onLoginSuccess: (patient: PatientAccountProfile) => void;
  onProfileUpdated: (patient: PatientAccountProfile) => void;
  onLogout: () => Promise<void>;
  onNavigate: (section: NavSection) => void;
}

const PREFERRED_WINDOWS = [
  'Morning (9:00 AM – 12:00 PM)',
  'Afternoon (12:00 PM – 4:00 PM)',
  'Evening (4:00 PM – 7:00 PM)',
];

export const PatientPortal: React.FC<PatientPortalProps> = ({
  mode,
  activePatient,
  onModeChange,
  onLoginSuccess,
  onProfileUpdated,
  onLogout,
  onNavigate,
}) => {
  // Registration state
  const [fullName, setFullName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [gender, setGender] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [registering, setRegistering] = useState(false);
  const [regError, setRegError] = useState<string | null>(null);
  const [registeredPatient, setRegisteredPatient] = useState<PatientAccountProfile | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  // Login state
  const [loginPatientId, setLoginPatientId] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loggingIn, setLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [forgotPasswordInfo, setForgotPasswordInfo] = useState<string | null>(null);
  const [checkingForgot, setCheckingForgot] = useState(false);

  // Dashboard edit profile state
  const [editingProfile, setEditingProfile] = useState(false);
  const [editFullName, setEditFullName] = useState('');
  const [editDob, setEditDob] = useState('');
  const [editGender, setEditGender] = useState('');
  const [editMobile, setEditMobile] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [profileSuccess, setProfileSuccess] = useState<string | null>(null);

  // Dashboard linked appointments state
  const [appointments, setAppointments] = useState<AppointmentRecord[]>([]);
  const [loadingAppointments, setLoadingAppointments] = useState(false);
  const [showNewAppointment, setShowNewAppointment] = useState(false);
  const [aptHospital, setAptHospital] = useState('');
  const [aptCity, setAptCity] = useState('');
  const [aptSpecialty, setAptSpecialty] = useState('');
  const [aptDate, setAptDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [aptWindow, setAptWindow] = useState(PREFERRED_WINDOWS[0]);
  const [aptVisitType, setAptVisitType] = useState<'In-Person' | 'Teleconsultation'>('In-Person');
  const [aptReason, setAptReason] = useState('');
  const [aptSubmitting, setAptSubmitting] = useState(false);
  const [aptError, setAptError] = useState<string | null>(null);

  useEffect(() => {
    if (activePatient) {
      setEditFullName(activePatient.fullName);
      setEditDob(activePatient.dateOfBirth);
      setEditGender(activePatient.gender || '');
      setEditMobile(activePatient.mobileNumber);
      setEditEmail(activePatient.email || '');
      setEditAddress(activePatient.address || '');
    }
  }, [activePatient]);

  const loadAppointments = async () => {
    if (!activePatient) return;
    setLoadingAppointments(true);
    try {
      const json = await apiFetchJson<{ appointments?: AppointmentRecord[] }>(
        '/api/appointments',
        { method: 'GET' },
        'Unable to load patient appointments.'
      );
      setAppointments(Array.isArray(json.appointments) ? json.appointments : []);
    } catch {
      // Non-fatal in dashboard overview
    } finally {
      setLoadingAppointments(false);
    }
  };

  useEffect(() => {
    if (mode === 'dashboard' && activePatient) {
      loadAppointments();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, activePatient?.patientId]);

  const handleCopyId = async (id: string) => {
    try {
      await navigator.clipboard.writeText(id);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } catch {
      // Clipboard blocked in restricted iframe
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    const cleanName = fullName.trim();
    const digitsOnly = mobileNumber.replace(/\D/g, '');
    if (cleanName.length < 2) {
      setRegError('Full name must be at least 2 characters long.');
      return;
    }
    if (!dateOfBirth) {
      setRegError('Please select your date of birth.');
      return;
    }
    if (digitsOnly.length < 10 || digitsOnly.length > 15) {
      setRegError('Please enter a valid mobile number (10 to 15 digits).');
      return;
    }
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setRegError('Please enter a valid email address or leave it blank.');
      return;
    }
    if (password.length < 8) {
      setRegError('Password must be at least 8 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setRegError('Password and Confirm Password do not match.');
      return;
    }

    setRegistering(true);
    try {
      const json = await apiFetchJson<{ message: string; patient: PatientAccountProfile }>(
        '/api/patients/register',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fullName: cleanName,
            dateOfBirth,
            gender: gender || undefined,
            mobileNumber: mobileNumber.trim(),
            email: email.trim() || undefined,
            address: address.trim() || undefined,
            password,
            confirmPassword,
          }),
        },
        'Patient registration failed.'
      );
      setRegisteredPatient(json.patient);
      setLoginPatientId(json.patient.patientId);
      setPassword('');
      setConfirmPassword('');
      setFullName('');
      setDateOfBirth('');
      setGender('');
      setMobileNumber('');
      setEmail('');
      setAddress('');
    } catch (err) {
      setRegError(err instanceof Error ? err.message : 'Unable to register patient.');
    } finally {
      setRegistering(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setForgotPasswordInfo(null);

    const cleanId = loginPatientId.trim().toUpperCase();
    if (!cleanId || !loginPassword) {
      setLoginError('Please enter both your Patient ID and password.');
      return;
    }

    setLoggingIn(true);
    try {
      const json = await apiFetchJson<{ message: string; patient: PatientAccountProfile }>(
        '/api/patients/login',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            patientId: cleanId,
            password: loginPassword,
          }),
        },
        'Login failed.'
      );
      setLoginPassword('');
      onLoginSuccess(json.patient);
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : 'Invalid Patient ID or password.');
    } finally {
      setLoggingIn(false);
    }
  };

  const handleForgotPassword = async () => {
    setCheckingForgot(true);
    setForgotPasswordInfo(null);
    setLoginError(null);
    try {
      await apiFetchJson<{ configured: boolean; error?: string }>(
        '/api/patients/forgot-password',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ patientId: loginPatientId.trim().toUpperCase() }),
        },
        'Password reset unavailable.'
      );
    } catch (err) {
      setForgotPasswordInfo(
        err instanceof Error
          ? err.message
          : 'Self-service password reset requires configured SMS OTP or email verification.'
      );
    } finally {
      setCheckingForgot(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileError(null);
    setProfileSuccess(null);

    if (editFullName.trim().length < 2) {
      setProfileError('Full name must be at least 2 characters long.');
      return;
    }
    const digitsOnly = editMobile.replace(/\D/g, '');
    if (digitsOnly.length < 10 || digitsOnly.length > 15) {
      setProfileError('Please enter a valid mobile number (10 to 15 digits).');
      return;
    }

    setSavingProfile(true);
    try {
      const json = await apiFetchJson<{ message: string; patient: PatientAccountProfile }>(
        '/api/patients/me',
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fullName: editFullName.trim(),
            dateOfBirth: editDob,
            gender: editGender,
            mobileNumber: editMobile.trim(),
            email: editEmail.trim(),
            address: editAddress.trim(),
          }),
        },
        'Unable to update profile.'
      );
      onProfileUpdated(json.patient);
      setEditingProfile(false);
      setProfileSuccess('Your patient profile has been updated.');
    } catch (err) {
      setProfileError(err instanceof Error ? err.message : 'Unable to update profile.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleCreateAppointment = async (e: React.FormEvent) => {
    e.preventDefault();
    setAptError(null);
    if (!aptHospital.trim() || !aptReason.trim()) {
      setAptError('Hospital name and reason for visit are required.');
      return;
    }
    setAptSubmitting(true);
    try {
      await apiFetchJson<{ appointment: AppointmentRecord }>(
        '/api/appointments',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            hospitalName: aptHospital.trim(),
            hospitalCity: aptCity.trim() || undefined,
            specialty: aptSpecialty.trim() || undefined,
            preferredDate: aptDate,
            preferredWindow: aptWindow,
            visitType: aptVisitType,
            reason: aptReason.trim(),
          }),
        },
        'Unable to submit appointment request.'
      );
      setAptHospital('');
      setAptCity('');
      setAptSpecialty('');
      setAptReason('');
      setShowNewAppointment(false);
      await loadAppointments();
    } catch (err) {
      setAptError(err instanceof Error ? err.message : 'Unable to submit appointment request.');
    } finally {
      setAptSubmitting(false);
    }
  };

  const handleCancelAppointment = async (bookingRef: string) => {
    try {
      await apiFetchJson<{ appointment: AppointmentRecord }>(
        `/api/appointments/${encodeURIComponent(bookingRef)}/status`,
        {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'Cancelled' }),
        },
        'Unable to cancel appointment.'
      );
      await loadAppointments();
    } catch (err) {
      setAptError(err instanceof Error ? err.message : 'Unable to cancel appointment.');
    }
  };

  // --- VIEW 1: PATIENT REGISTRATION ---
  if (mode === 'register') {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-5">
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <p className="text-xs font-semibold text-blue-700 flex items-center gap-1.5">
                <UserPlus className="w-4 h-4" />
                <span>Patient Account Registration</span>
              </p>
              <h2 className="text-xl font-semibold text-slate-900 mt-1">
                Create Your MediBridge Patient Account
              </h2>
              <p className="text-sm text-slate-600 mt-0.5">
                Register once to receive your unique Patient ID (<span className="font-mono text-slate-800">MBP-2026-...</span>) for reminders, SOS contacts, and appointments.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onModeChange('login')}
              className="text-xs font-semibold text-blue-700 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
            >
              Already have a Patient ID? Login
            </button>
          </div>

          {registeredPatient && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-base font-semibold text-emerald-950">
                    Registration Successful
                  </h3>
                  <p className="text-sm text-emerald-900 mt-0.5">
                    Your account for <strong>{registeredPatient.fullName}</strong> has been saved securely in MediBridge. Save your Patient ID below to log in.
                  </p>
                </div>
              </div>

              <div className="bg-white border border-emerald-200 rounded-lg p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-medium text-slate-500">Your Unique Patient ID</p>
                  <p className="text-2xl font-mono font-bold tabular-nums text-slate-900 mt-0.5">
                    {registeredPatient.patientId}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopyId(registeredPatient.patientId)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg cursor-pointer whitespace-nowrap"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {copiedId ? 'Copied!' : 'Copy Patient ID'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLoginPatientId(registeredPatient.patientId);
                      onModeChange('login');
                    }}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer whitespace-nowrap"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    Proceed to Login
                  </button>
                </div>
              </div>
            </div>
          )}

          {regError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3.5 text-sm text-red-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{regError}</span>
            </div>
          )}

          <form onSubmit={handleRegisterSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label htmlFor="reg-fullname" className="block text-xs font-medium text-slate-700 mb-1">
                  Full Name <span className="text-red-600">*</span>
                </label>
                <input
                  id="reg-fullname"
                  type="text"
                  required
                  minLength={2}
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Enter your full legal name"
                  className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div>
                <label htmlFor="reg-dob" className="block text-xs font-medium text-slate-700 mb-1">
                  Date of Birth <span className="text-red-600">*</span>
                </label>
                <input
                  id="reg-dob"
                  type="date"
                  required
                  max={new Date().toISOString().split('T')[0]}
                  min="1900-01-01"
                  value={dateOfBirth}
                  onChange={(e) => setDateOfBirth(e.target.value)}
                  className="w-full px-3 py-2.5 text-sm tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div>
                <label htmlFor="reg-gender" className="block text-xs font-medium text-slate-700 mb-1">
                  Gender (Optional)
                </label>
                <select
                  id="reg-gender"
                  value={gender}
                  onChange={(e) => setGender(e.target.value)}
                  className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                >
                  <option value="">Select gender (optional)</option>
                  <option value="Female">Female</option>
                  <option value="Male">Male</option>
                  <option value="Non-Binary / Other">Non-Binary / Other</option>
                  <option value="Prefer not to say">Prefer not to say</option>
                </select>
              </div>

              <div>
                <label htmlFor="reg-mobile" className="block text-xs font-medium text-slate-700 mb-1">
                  Mobile Number <span className="text-red-600">*</span>
                </label>
                <input
                  id="reg-mobile"
                  type="tel"
                  required
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  placeholder="e.g., +91 9876543210"
                  className="w-full px-3 py-2.5 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div>
                <label htmlFor="reg-email" className="block text-xs font-medium text-slate-700 mb-1">
                  Email Address (Optional)
                </label>
                <input
                  id="reg-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="patient@example.com"
                  className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div className="sm:col-span-2">
                <label htmlFor="reg-address" className="block text-xs font-medium text-slate-700 mb-1">
                  Address (Optional)
                </label>
                <input
                  id="reg-address"
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="House / Street / City / State / PIN Code"
                  className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div>
                <label htmlFor="reg-password" className="block text-xs font-medium text-slate-700 mb-1">
                  Create Password <span className="text-red-600">*</span>
                </label>
                <div className="relative">
                  <input
                    id="reg-password"
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Minimum 8 characters"
                    className="w-full pl-3 pr-10 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword((v) => !v)}
                    aria-label={showRegPassword ? 'Hide password' : 'Show password'}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800 cursor-pointer"
                  >
                    {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label htmlFor="reg-confirm" className="block text-xs font-medium text-slate-700 mb-1">
                  Confirm Password <span className="text-red-600">*</span>
                </label>
                <input
                  id="reg-confirm"
                  type={showRegPassword ? 'text' : 'password'}
                  required
                  minLength={8}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-enter password"
                  className="w-full px-3 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs text-slate-500">
                Passwords are salted and hashed securely on the server before storage.
              </p>
              <button
                type="submit"
                disabled={registering}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                {registering ? 'Registering...' : 'Register Patient'}
              </button>
            </div>
          </form>
        </section>
      </div>
    );
  }

  // --- VIEW 2: PATIENT LOGIN ---
  if (mode === 'login' || !activePatient) {
    return (
      <div className="max-w-lg mx-auto space-y-6">
        <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-5">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <p className="text-xs font-semibold text-blue-700 flex items-center gap-1.5">
                <KeyRound className="w-4 h-4" />
                <span>Patient Sign In</span>
              </p>
              <h2 className="text-xl font-semibold text-slate-900 mt-1">
                Log In With Your Patient ID
              </h2>
              <p className="text-sm text-slate-600 mt-0.5">
                Enter your assigned Patient ID and password to open your Patient Dashboard.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onModeChange('register')}
              className="text-xs font-semibold text-blue-700 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
            >
              New patient? Register
            </button>
          </div>

          {loginError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3.5 text-sm text-red-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{loginError}</span>
            </div>
          )}

          {forgotPasswordInfo && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3.5 text-xs text-amber-950 flex items-start gap-2">
              <HelpCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Password Reset Status</p>
                <p className="mt-0.5 leading-relaxed">{forgotPasswordInfo}</p>
              </div>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label htmlFor="login-pid" className="block text-xs font-medium text-slate-700 mb-1">
                Patient ID <span className="text-red-600">*</span>
              </label>
              <input
                id="login-pid"
                type="text"
                required
                value={loginPatientId}
                onChange={(e) => setLoginPatientId(e.target.value.toUpperCase())}
                placeholder="e.g., MBP-2026-000001"
                className="w-full px-3 py-2.5 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="login-password" className="block text-xs font-medium text-slate-700">
                  Password <span className="text-red-600">*</span>
                </label>
                <button
                  type="button"
                  onClick={handleForgotPassword}
                  disabled={checkingForgot}
                  className="text-xs font-medium text-blue-700 hover:underline cursor-pointer"
                >
                  {checkingForgot ? 'Checking...' : 'Forgot Password?'}
                </button>
              </div>
              <div className="relative">
                <input
                  id="login-password"
                  type={showLoginPassword ? 'text' : 'password'}
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-3 pr-10 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
                <button
                  type="button"
                  onClick={() => setShowLoginPassword((v) => !v)}
                  aria-label={showLoginPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              {loggingIn ? 'Verifying...' : 'Login to Patient Dashboard'}
            </button>
          </form>
        </section>
      </div>
    );
  }

  // --- VIEW 3: PATIENT DASHBOARD ---
  return (
    <div className="space-y-6">
      {/* Welcome & Patient ID Header */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <span className="inline-flex items-center gap-1 font-semibold text-emerald-700">
              <ShieldCheck className="w-3.5 h-3.5" />
              Active Patient Session
            </span>
            <span aria-hidden="true">·</span>
            <span className="capitalize">Status: {activePatient.accountStatus}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              Registered: {activePatient.registrationDate.slice(0, 10)}
            </span>
          </div>
          <h2 className="text-2xl font-bold text-slate-900">
            Welcome, {activePatient.fullName}
          </h2>
          <div className="flex flex-wrap items-center gap-3 pt-1">
            <span className="text-xs text-slate-600">
              Patient ID:{' '}
              <strong className="font-mono tabular-nums text-slate-900 text-sm">
                {activePatient.patientId}
              </strong>
            </span>
            <button
              type="button"
              onClick={() => handleCopyId(activePatient.patientId)}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md cursor-pointer"
            >
              <Copy className="w-3 h-3" />
              {copiedId ? 'Copied' : 'Copy ID'}
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => {
              setEditingProfile((v) => !v);
              setProfileError(null);
              setProfileSuccess(null);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg whitespace-nowrap cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            {editingProfile ? 'Cancel Edit' : 'Edit Profile'}
          </button>
          <button
            type="button"
            onClick={() => onLogout()}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg whitespace-nowrap cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Logout
          </button>
        </div>
      </section>

      {profileSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-sm text-emerald-900 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
          <span>{profileSuccess}</span>
        </div>
      )}

      {/* Profile View or Edit Form */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-blue-700" />
            <h3 className="text-base font-semibold text-slate-900">Patient Profile</h3>
          </div>
          <span className="text-xs font-mono tabular-nums text-slate-500">
            {activePatient.patientId}
          </span>
        </div>

        {editingProfile ? (
          <form onSubmit={handleSaveProfile} className="space-y-4">
            {profileError && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-xs text-red-800">
                {profileError}
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editFullName}
                  onChange={(e) => setEditFullName(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Date of Birth</label>
                <input
                  type="date"
                  required
                  value={editDob}
                  onChange={(e) => setEditDob(e.target.value)}
                  className="w-full px-3 py-2 text-sm tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Gender</label>
                <select
                  value={editGender}
                  onChange={(e) => setEditGender(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                >
                  <option value="">Not specified</option>
                  <option value="Female">Female</option>
                  <option value="Male">Male</option>
                  <option value="Non-Binary / Other">Non-Binary / Other</option>
                  <option value="Prefer not to say">Prefer not to say</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Mobile Number</label>
                <input
                  type="tel"
                  required
                  value={editMobile}
                  onChange={(e) => setEditMobile(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  placeholder="Optional"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Address</label>
                <input
                  type="text"
                  value={editAddress}
                  onChange={(e) => setEditAddress(e.target.value)}
                  placeholder="Optional"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingProfile(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingProfile}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
              >
                {savingProfile ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        ) : (
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
            <div>
              <dt className="text-xs text-slate-500">Full Name</dt>
              <dd className="font-semibold text-slate-900 mt-0.5">{activePatient.fullName}</dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Date of Birth</dt>
              <dd className="font-medium tabular-nums text-slate-900 mt-0.5">
                {activePatient.dateOfBirth}
                {typeof activePatient.age === 'number' ? ` (${activePatient.age} yrs)` : ''}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Gender</dt>
              <dd className="font-medium text-slate-900 mt-0.5">
                {activePatient.gender || 'Not specified'}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Mobile Number</dt>
              <dd className="font-mono tabular-nums text-slate-900 mt-0.5">
                {activePatient.mobileNumber}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Email Address</dt>
              <dd className="text-slate-900 mt-0.5 truncate">
                {activePatient.email || 'Not provided'}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Address</dt>
              <dd className="text-slate-900 mt-0.5">{activePatient.address || 'Not provided'}</dd>
            </div>
          </dl>
        )}
      </section>

      {/* Quick Patient Services Navigation */}
      <section className="space-y-3">
        <h3 className="text-base font-semibold text-slate-900">Your MediBridge Services</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            type="button"
            onClick={() => onNavigate('hospitals')}
            className="bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-4 text-left space-y-2 transition-colors cursor-pointer"
          >
            <Building2 className="w-5 h-5 text-blue-700" />
            <p className="text-sm font-semibold text-slate-900">Hospital Finder</p>
            <p className="text-xs text-slate-600">Search verified &amp; public Indian hospitals</p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700">
              Open <ArrowRight className="w-3 h-3" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('medicines')}
            className="bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-4 text-left space-y-2 transition-colors cursor-pointer"
          >
            <Pill className="w-5 h-5 text-blue-700" />
            <p className="text-sm font-semibold text-slate-900">Medicine Checker</p>
            <p className="text-xs text-slate-600">Look up Indian tablets &amp; compositions</p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700">
              Open <ArrowRight className="w-3 h-3" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('reminders')}
            className="bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-4 text-left space-y-2 transition-colors cursor-pointer"
          >
            <Bell className="w-5 h-5 text-blue-700" />
            <p className="text-sm font-semibold text-slate-900">Medicine Reminder</p>
            <p className="text-xs text-slate-600">
              Linked to <span className="font-mono">{activePatient.patientId}</span>
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700">
              Manage Reminders <ArrowRight className="w-3 h-3" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('sos')}
            className="bg-white border border-red-200 hover:border-red-300 rounded-xl p-4 text-left space-y-2 transition-colors cursor-pointer"
          >
            <ShieldAlert className="w-5 h-5 text-red-600" />
            <p className="text-sm font-semibold text-slate-900">Emergency SOS</p>
            <p className="text-xs text-slate-600">
              Contacts saved to <span className="font-mono">{activePatient.patientId}</span>
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-red-700">
              Open SOS <ArrowRight className="w-3 h-3" />
            </span>
          </button>
        </div>
      </section>

      {/* Linked Appointments Section */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-blue-700" />
            <div>
              <h3 className="text-base font-semibold text-slate-900">My Appointments</h3>
              <p className="text-xs text-slate-500">
                Appointment requests linked strictly to Patient ID{' '}
                <span className="font-mono text-slate-700">{activePatient.patientId}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setShowNewAppointment((v) => !v);
              setAptError(null);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer whitespace-nowrap"
          >
            {showNewAppointment ? (
              <>
                <X className="w-3.5 h-3.5" />
                Close Form
              </>
            ) : (
              <>
                <CalendarPlus className="w-3.5 h-3.5" />
                Request Appointment
              </>
            )}
          </button>
        </div>

        {aptError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-xs text-red-800">
            {aptError}
          </div>
        )}

        {showNewAppointment && (
          <form onSubmit={handleCreateAppointment} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Hospital / Clinic Name <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={aptHospital}
                  onChange={(e) => setAptHospital(e.target.value)}
                  placeholder="e.g., AIIMS New Delhi"
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">City</label>
                <input
                  type="text"
                  value={aptCity}
                  onChange={(e) => setAptCity(e.target.value)}
                  placeholder="e.g., New Delhi"
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Preferred Date</label>
                <input
                  type="date"
                  required
                  min={new Date().toISOString().split('T')[0]}
                  value={aptDate}
                  onChange={(e) => setAptDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm tabular-nums bg-white border border-slate-200 rounded-lg"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Time Window</label>
                <select
                  value={aptWindow}
                  onChange={(e) => setAptWindow(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                >
                  {PREFERRED_WINDOWS.map((w) => (
                    <option key={w} value={w}>
                      {w}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Visit Type</label>
                <select
                  value={aptVisitType}
                  onChange={(e) =>
                    setAptVisitType(
                      e.target.value === 'Teleconsultation' ? 'Teleconsultation' : 'In-Person'
                    )
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                >
                  <option value="In-Person">In-Person</option>
                  <option value="Teleconsultation">Teleconsultation</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Department / Specialty (Optional)
                </label>
                <input
                  type="text"
                  value={aptSpecialty}
                  onChange={(e) => setAptSpecialty(e.target.value)}
                  placeholder="e.g., General Medicine"
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Reason for Visit <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={aptReason}
                  onChange={(e) => setAptReason(e.target.value)}
                  placeholder="Brief summary of consultation need"
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg"
                />
              </div>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={aptSubmitting}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
              >
                {aptSubmitting ? 'Submitting...' : 'Submit Appointment Request'}
              </button>
            </div>
          </form>
        )}

        {loadingAppointments ? (
          <div className="h-20 bg-slate-100 rounded-lg animate-pulse" />
        ) : appointments.length > 0 ? (
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
            {appointments.map((apt) => (
              <div
                key={apt.bookingRef}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                    <span className="font-mono font-semibold text-blue-700 tabular-nums">
                      {apt.bookingRef}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-medium text-slate-800">{apt.status}</span>
                    <span aria-hidden="true">·</span>
                    <span>{apt.visitType}</span>
                  </div>
                  <p className="text-sm font-semibold text-slate-900">
                    {apt.hospitalName}
                    {apt.hospitalCity ? ` (${apt.hospitalCity})` : ''}
                  </p>
                  <p className="text-xs text-slate-600 tabular-nums">
                    {apt.preferredDate} · {apt.preferredWindow} · {apt.reason}
                  </p>
                </div>

                {apt.status !== 'Cancelled' && (
                  <button
                    type="button"
                    onClick={() => handleCancelAppointment(apt.bookingRef)}
                    className="px-3 py-1.5 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Cancel Request
                  </button>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded-lg p-4">
            No appointments recorded for <span className="font-mono">{activePatient.patientId}</span> yet. Use &ldquo;Request Appointment&rdquo; above or explore hospitals in Hospital Finder.
          </p>
        )}
      </section>
    </div>
  );
};
