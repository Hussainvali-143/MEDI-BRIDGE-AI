import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Building2,
  CalendarPlus,
  Clock,
  Mail,
  MapPin,
  Phone,
  Search,
  ShieldCheck,
  Stethoscope,
} from 'lucide-react';
import { INDIAN_STATES_AND_UTS } from '../data/indianLocations';
import { apiFetchJson } from '../utils/apiClient';
import type { DoctorRecord, DoctorSearchResponse } from '../types/healthcare';

interface DoctorDirectoryProps {
  initialQuery?: string;
  onBookWithDoctor: (doctor: DoctorRecord) => void;
}

export const DoctorDirectory: React.FC<DoctorDirectoryProps> = ({
  initialQuery = '',
  onBookWithDoctor,
}) => {
  const [q, setQ] = useState(initialQuery);
  const [specialty, setSpecialty] = useState('');
  const [hospital, setHospital] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [verificationFilter, setVerificationFilter] = useState<'all' | 'verified' | 'unverified'>('all');
  const [data, setData] = useState<DoctorSearchResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchDoctors = async (overrideQ?: string) => {
    setLoading(true);
    setError(null);
    try {
      const effectiveQ = overrideQ !== undefined ? overrideQ : q;
      const params = new URLSearchParams();
      if (effectiveQ.trim()) params.set('q', effectiveQ.trim());
      if (specialty.trim()) params.set('specialty', specialty.trim());
      if (hospital.trim()) params.set('hospital', hospital.trim());
      if (city.trim()) params.set('city', city.trim());
      if (state) params.set('state', state);

      const json = await apiFetchJson<DoctorSearchResponse>(
        `/api/doctors?${params.toString()}`,
        { method: 'GET' },
        'Failed to load Doctor Directory.'
      );
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to query Doctor Directory.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setQ(initialQuery);
    fetchDoctors(initialQuery);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialQuery]);

  const verifiedList = verificationFilter === 'unverified' ? [] : data?.verified ?? [];
  const unverifiedList = verificationFilter === 'verified' ? [] : data?.unverified ?? [];

  const renderDoctorCard = (doc: DoctorRecord) => (
    <article
      key={doc.id}
      className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between gap-4 hover:border-blue-300 transition-colors"
    >
      <div className="space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 font-semibold border rounded ${
                  doc.verified
                    ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                    : 'text-amber-800 bg-amber-50 border-amber-200'
                }`}
              >
                {doc.verified ? (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-3.5 h-3.5" />
                    Unverified
                  </>
                )}
              </span>
              <span className="text-blue-700 font-semibold">{doc.specialty}</span>
              {doc.qualification && (
                <>
                  <span className="text-slate-400" aria-hidden="true">·</span>
                  <span className="text-slate-600">{doc.qualification}</span>
                </>
              )}
            </div>
            <h3 className="text-base font-semibold text-slate-900 mt-1.5 leading-snug">{doc.name}</h3>
          </div>
        </div>

        <div className="space-y-2 text-sm text-slate-600 pt-2 border-t border-slate-100">
          <div className="flex items-start gap-2">
            <Building2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <span className="text-slate-800 font-medium">{doc.hospitalAffiliation}</span>
          </div>

          {(doc.city || doc.state) && (
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{[doc.city, doc.state].filter(Boolean).join(', ')}</span>
            </div>
          )}

          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-blue-600 shrink-0" />
            <span className="font-mono tabular-nums text-xs text-slate-800">
              {doc.contactNumber}
            </span>
          </div>

          {doc.email && (
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <Mail className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{doc.email}</span>
            </div>
          )}

          {doc.consultationHours && (
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <Clock className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{doc.consultationHours}</span>
            </div>
          )}
        </div>
      </div>

      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
        <span className="text-xs text-slate-500 truncate">
          {doc.sourceLabel}
          {doc.registrationNumber ? ` · Reg: ${doc.registrationNumber}` : ''}
        </span>
        <button
          type="button"
          onClick={() => onBookWithDoctor(doc)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <CalendarPlus className="w-3.5 h-3.5" />
          Book Visit
        </button>
      </div>
    </article>
  );

  return (
    <div className="space-y-6">
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-slate-900">Doctor Directory</h2>
          <p className="text-sm text-slate-600">
            Browse doctors by name, specialty, hospital affiliation, and verified contact information from Medi_Bridge.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchDoctors();
          }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3"
        >
          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">Doctor Name or Keyword</label>
            <input
              type="text"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="e.g., Dr. Sharma, Cardiology"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Specialty</label>
            <input
              type="text"
              value={specialty}
              onChange={(e) => setSpecialty(e.target.value)}
              list="specialties-datalist"
              placeholder="e.g., Pediatrics"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
            <datalist id="specialties-datalist">
              {(data?.availableSpecialties ?? []).map((sp) => (
                <option key={sp} value={sp} />
              ))}
            </datalist>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Hospital Affiliation</label>
            <input
              type="text"
              value={hospital}
              onChange={(e) => setHospital(e.target.value)}
              placeholder="Hospital name"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">City / Town</label>
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="e.g., Bengaluru"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">State / UT</label>
            <select
              value={state}
              onChange={(e) => setState(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            >
              <option value="">All States</option>
              {INDIAN_STATES_AND_UTS.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-2 lg:col-span-3 flex items-end">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-full sm:w-auto">
              {(['all', 'verified', 'unverified'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setVerificationFilter(mode)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    verificationFilter === mode
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {mode === 'all' ? 'All Records' : mode === 'verified' ? 'Verified' : 'Unverified'}
                </button>
              ))}
            </div>
          </div>

          <div className="sm:col-span-2 lg:col-span-3 flex items-end justify-end gap-2">
            {(q || specialty || hospital || city || state) && (
              <button
                type="button"
                onClick={() => {
                  setQ('');
                  setSpecialty('');
                  setHospital('');
                  setCity('');
                  setState('');
                  fetchDoctors('');
                }}
                className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg whitespace-nowrap cursor-pointer"
              >
                Clear
              </button>
            )}
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Search className="w-4 h-4" />
              Search Doctors
            </button>
          </div>
        </form>
      </section>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 animate-pulse">
              <div className="h-3 w-24 bg-slate-200 rounded" />
              <div className="h-5 w-48 bg-slate-200 rounded" />
              <div className="h-4 w-full bg-slate-100 rounded" />
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          {verificationFilter !== 'unverified' && (
            <section className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-base font-semibold text-slate-900">Verified Practitioners</h3>
                </div>
                <span className="text-xs font-mono tabular-nums text-slate-500">
                  {verifiedList.length} verified
                </span>
              </div>

              {verifiedList.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {verifiedList.map(renderDoctorCard)}
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-xl p-6 text-center space-y-2">
                  <Stethoscope className="w-6 h-6 text-slate-400 mx-auto" />
                  <p className="text-sm font-medium text-slate-800">
                    {data?.databaseConnected
                      ? 'The Medi_Bridge doctors collection currently contains 0 verified doctor records.'
                      : 'Connect MONGODB_URI in Settings > Secrets to view verified doctor records from Medi_Bridge.'}
                  </p>
                  <p className="text-xs text-slate-500 max-w-lg mx-auto">
                    MediBridge AI strictly displays only verified or database-stored practitioners and never fabricates doctor names, qualifications, hospital affiliations, phone numbers, or consultation timings.
                  </p>
                </div>
              )}
            </section>
          )}

          {verificationFilter !== 'verified' && (
            <section className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                  <h3 className="text-base font-semibold text-slate-900">Unverified Practitioner Records</h3>
                </div>
                <span className="text-xs font-mono tabular-nums text-slate-500">
                  {unverifiedList.length} unverified
                </span>
              </div>

              {unverifiedList.length > 0 ? (
                <>
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 text-xs text-amber-900">
                    <strong>Verification Notice:</strong> These practitioner records have not yet been verified against an official medical council or hospital registry. Confirm credentials, timings, and phone numbers directly with the hospital.
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {unverifiedList.map(renderDoctorCard)}
                  </div>
                </>
              ) : (
                <div className="bg-white border border-slate-200 rounded-xl p-5 text-sm text-slate-600">
                  No unverified doctor records matched your current filters in <span className="font-mono">Medi_Bridge</span>.
                </div>
              )}
            </section>
          )}
        </div>
      )}
    </div>
  );
};
