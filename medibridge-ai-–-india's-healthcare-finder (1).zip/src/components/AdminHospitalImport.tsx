import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Database,
  FileSpreadsheet,
  KeyRound,
  Lock,
  LogOut,
  RefreshCw,
  ShieldAlert,
  Upload,
} from 'lucide-react';
import { apiFetchJson, buildApiUrl, parseApiJsonResponse } from '../utils/apiClient';
import type {
  AdminAuthStatus,
  HospitalCsvPreviewResponse,
  HospitalImportProgressEvent,
  HospitalImportTargetField,
} from '../types/healthcare';

interface AdminHospitalImportProps {
  adminToken: string | null;
  onAdminTokenChange: (token: string | null) => void;
  onImportComplete?: () => void;
  onGoToHospitalFinder?: () => void;
  onGoToVerification?: () => void;
}

const TARGET_FIELD_LABELS: Array<{ key: HospitalImportTargetField; label: string; required?: boolean }> = [
  { key: 'name', label: 'name (Hospital Name)', required: true },
  { key: 'state', label: 'state' },
  { key: 'district', label: 'district' },
  { key: 'city', label: 'city' },
  { key: 'pincode', label: 'pincode' },
  { key: 'address', label: 'address' },
  { key: 'phone', label: 'phone' },
  { key: 'facilityType', label: 'facilityType' },
  { key: 'latitude', label: 'latitude' },
  { key: 'longitude', label: 'longitude' },
  { key: 'sourceId', label: 'sourceId (Dedup Key)' },
];

export const AdminHospitalImport: React.FC<AdminHospitalImportProps> = ({
  adminToken,
  onAdminTokenChange,
  onImportComplete,
  onGoToHospitalFinder,
  onGoToVerification,
}) => {
  const [authStatus, setAuthStatus] = useState<AdminAuthStatus | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [passcodeInput, setPasscodeInput] = useState('');
  const [confirmPasscodeInput, setConfirmPasscodeInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [columnOverrides, setColumnOverrides] = useState<
    Partial<Record<HospitalImportTargetField, string | null>>
  >({});
  const [previewData, setPreviewData] = useState<HospitalCsvPreviewResponse | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState<string | null>(null);

  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState<HospitalImportProgressEvent | null>(null);
  const [importError, setImportError] = useState<string | null>(null);

  const fetchAuthStatus = async (tokenToUse = adminToken) => {
    setAuthLoading(true);
    try {
      const headers: Record<string, string> = {};
      if (tokenToUse) {
        headers.Authorization = `Bearer ${tokenToUse}`;
      }
      const json = await apiFetchJson<AdminAuthStatus>(
        '/api/admin/auth/status',
        { headers },
        'Unable to verify admin session.'
      );
      setAuthStatus(json);
      if (!json.authenticated && tokenToUse) {
        onAdminTokenChange(null);
      }
    } catch {
      // Handled gracefully
    } finally {
      setAuthLoading(false);
    }
  };

  useEffect(() => {
    fetchAuthStatus(adminToken);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleInitialSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (passcodeInput.length < 8) {
      setAuthError('Passcode must be at least 8 characters long.');
      return;
    }
    if (passcodeInput !== confirmPasscodeInput) {
      setAuthError('Passcodes do not match.');
      return;
    }
    setAuthSubmitting(true);
    try {
      const json = await apiFetchJson<{ token: string }>(
        '/api/admin/auth/setup',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ passcode: passcodeInput }),
        },
        'Failed to set admin passcode.'
      );
      onAdminTokenChange(json.token);
      setPasscodeInput('');
      setConfirmPasscodeInput('');
      await fetchAuthStatus(json.token);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Unable to complete setup.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSubmitting(true);
    try {
      const json = await apiFetchJson<{ token: string }>(
        '/api/admin/auth/login',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ passcode: passcodeInput }),
        },
        'Invalid admin passcode.'
      );
      onAdminTokenChange(json.token);
      setPasscodeInput('');
      await fetchAuthStatus(json.token);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleSignOut = () => {
    onAdminTokenChange(null);
    setPreviewData(null);
    setSelectedFile(null);
    setImportProgress(null);
    fetchAuthStatus(null);
  };

  const runPreview = async (
    file: File,
    overrides: Partial<Record<HospitalImportTargetField, string | null>>
  ) => {
    if (!adminToken) return;
    setPreviewLoading(true);
    setPreviewError(null);
    setImportError(null);
    setImportProgress(null);

    try {
      const formData = new FormData();
      formData.append('file', file);
      if (Object.keys(overrides).length > 0) {
        formData.append('columnOverrides', JSON.stringify(overrides));
      }

      const json = await apiFetchJson<HospitalCsvPreviewResponse>(
        '/api/admin/hospitals/preview',
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${adminToken}`,
          },
          body: formData,
        },
        'Failed to parse CSV file.'
      );

      setPreviewData(json);
    } catch (err) {
      if ((err as { status?: number })?.status === 401) {
        onAdminTokenChange(null);
        await fetchAuthStatus(null);
      }
      setPreviewError(err instanceof Error ? err.message : 'Unable to preview CSV.');
      setPreviewData(null);
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleFileChange = (file: File | null) => {
    setSelectedFile(file);
    setColumnOverrides({});
    setPreviewData(null);
    setImportProgress(null);
    setImportError(null);
    if (file) {
      runPreview(file, {});
    }
  };

  const handleOverrideChange = (field: HospitalImportTargetField, headerName: string) => {
    const nextOverrides = {
      ...columnOverrides,
      [field]: headerName === '' ? null : headerName,
    };
    setColumnOverrides(nextOverrides);
    if (selectedFile) {
      runPreview(selectedFile, nextOverrides);
    }
  };

  const handleImport = async () => {
    if (!selectedFile || !adminToken) return;
    setImporting(true);
    setImportError(null);
    setImportProgress(null);

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      if (Object.keys(columnOverrides).length > 0) {
        formData.append('columnOverrides', JSON.stringify(columnOverrides));
      }

      const res = await fetch(buildApiUrl('/api/admin/hospitals/import'), {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          Authorization: `Bearer ${adminToken}`,
          Accept: 'application/x-ndjson, application/json',
        },
        body: formData,
      });

      const contentType = (res.headers.get('content-type') || '').toLowerCase();
      if (contentType.includes('text/html') || res.url.includes('__cookie_check')) {
        await parseApiJsonResponse(res);
      }

      if (res.status === 401) {
        const errJson = await parseApiJsonResponse(res).catch(() => ({ error: undefined }));
        onAdminTokenChange(null);
        await fetchAuthStatus(null);
        throw new Error(errJson.error || 'Admin authentication expired.');
      }

      if (!res.ok) {
        const errJson = await parseApiJsonResponse(res).catch(() => ({ error: undefined }));
        throw new Error(errJson.error || `Hospital import failed (HTTP ${res.status}).`);
      }

      const reader = res.body?.getReader();
      if (!reader) {
        throw new Error('Streaming response not available.');
      }

      const decoder = new TextDecoder();
      let buffer = '';
      let lastEvent: HospitalImportProgressEvent | null = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          try {
            const evt = JSON.parse(trimmed) as HospitalImportProgressEvent;
            lastEvent = evt;
            setImportProgress(evt);
            if (evt.type === 'error' && evt.error) {
              setImportError(evt.error);
            }
          } catch {
            // Ignore partial JSON line
          }
        }
      }

      if (buffer.trim()) {
        try {
          const evt = JSON.parse(buffer.trim()) as HospitalImportProgressEvent;
          lastEvent = evt;
          setImportProgress(evt);
          if (evt.type === 'error' && evt.error) {
            setImportError(evt.error);
          }
        } catch {
          // Ignore trailing noise
        }
      }

      if (lastEvent?.type === 'complete' && onImportComplete) {
        onImportComplete();
      }
    } catch (err) {
      setImportError(err instanceof Error ? err.message : 'Unable to complete CSV import.');
    } finally {
      setImporting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-8 text-sm text-slate-600">
        Verifying Admin Dashboard session...
      </div>
    );
  }

  // Gate: Initial Setup or Login
  if (!authStatus?.authenticated) {
    return (
      <div className="max-w-lg mx-auto bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="border-b border-slate-100 pb-4 space-y-1">
          <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
            <Lock className="w-4 h-4" />
            <span>Admin Dashboard · Protected Import Access</span>
          </div>
          <h2 className="text-lg font-semibold text-slate-900">
            {authStatus?.needsInitialSetup
              ? 'Set Initial Admin Passcode'
              : 'Admin Sign-In Required'}
          </h2>
          <p className="text-sm text-slate-600">
            {authStatus?.needsInitialSetup
              ? 'Claim an admin passcode (min. 8 characters) to protect the Import Hospital Dataset endpoint. You can also set ADMIN_PASSCODE in Settings → Secrets at any time.'
              : 'Enter your administrator passcode to upload, preview, and import official Indian hospital CSV datasets into Medi_Bridge.'}
          </p>
        </div>

        {authError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
            {authError}
          </div>
        )}

        {authStatus?.needsInitialSetup ? (
          <form onSubmit={handleInitialSetup} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                New Admin Passcode
              </label>
              <input
                type="password"
                required
                minLength={8}
                value={passcodeInput}
                onChange={(e) => setPasscodeInput(e.target.value)}
                placeholder="Minimum 8 characters"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Confirm Passcode
              </label>
              <input
                type="password"
                required
                minLength={8}
                value={confirmPasscodeInput}
                onChange={(e) => setConfirmPasscodeInput(e.target.value)}
                placeholder="Re-enter passcode"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <button
              type="submit"
              disabled={authSubmitting}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              {authSubmitting ? 'Setting Passcode...' : 'Claim Admin Access'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Admin Passcode
              </label>
              <input
                type="password"
                required
                value={passcodeInput}
                onChange={(e) => setPasscodeInput(e.target.value)}
                placeholder="Enter admin passcode"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <button
              type="submit"
              disabled={authSubmitting}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              {authSubmitting ? 'Verifying...' : 'Sign In to Admin Dashboard'}
            </button>
          </form>
        )}
      </div>
    );
  }

  const progressPct =
    importProgress && importProgress.totalRows > 0
      ? Math.round((importProgress.processedRows / importProgress.totalRows) * 100)
      : 0;

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-700">Admin Dashboard</p>
          <h2 className="text-lg font-semibold text-slate-900 mt-0.5">
            Import Hospital Dataset (CSV → MongoDB Atlas)
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            Upload official Indian hospital CSV files, verify the 10-row preview, and batch-import into{' '}
            <span className="font-mono text-slate-800">Medi_Bridge.Hospitals</span> with{' '}
            <span className="font-mono text-slate-800">verified: false</span> and duplicate skipping.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSignOut}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign Out
        </button>
      </section>

      {/* CSV Upload Control */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">1. Upload Official Hospital CSV File</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Supports UTF-8 CSV files up to 30 MB. Missing hospital fields are left blank (never invented).
            </p>
          </div>
          {selectedFile && (
            <span className="text-xs font-mono tabular-nums text-slate-700">
              {selectedFile.name} · {(selectedFile.size / 1024).toFixed(1)} KB
            </span>
          )}
        </div>

        <label className="block border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-6 text-center bg-slate-50 hover:bg-blue-50/40 transition-colors cursor-pointer">
          <input
            type="file"
            accept=".csv,text/csv"
            className="sr-only"
            onChange={(e) => handleFileChange(e.target.files?.[0] || null)}
          />
          <Upload className="w-7 h-7 text-blue-700 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-900">
            {selectedFile ? 'Choose a different CSV file' : 'Click to select a hospital dataset (.csv)'}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Columns auto-map to name, state, district, city, pincode, address, phone, facilityType, latitude, longitude
          </p>
        </label>

        {previewLoading && (
          <div className="text-sm text-blue-700 flex items-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>Parsing CSV on the server and generating 10-record preview...</span>
          </div>
        )}

        {previewError && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
            {previewError}
          </div>
        )}
      </section>

      {/* Column Mapping & 10-Row Preview */}
      {previewData && (
        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
                <FileSpreadsheet className="w-4 h-4" />
                <span>2. Automatic Column Mapping &amp; 10-Record Preview</span>
              </div>
              <p className="text-xs text-slate-600 mt-1 tabular-nums">
                Detected <strong>{previewData.totalRows.toLocaleString()}</strong> total rows across{' '}
                <strong>{previewData.headers.length}</strong> CSV columns · Target:{' '}
                <span className="font-mono">
                  {previewData.targetDatabase}.{previewData.targetCollection}
                </span>
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <Database className="w-4 h-4 text-blue-700" />
              <span
                className={
                  previewData.databaseConnected
                    ? 'font-semibold text-emerald-700'
                    : 'font-semibold text-amber-700'
                }
              >
                {previewData.databaseConnected
                  ? 'MongoDB Atlas Connected'
                  : 'MongoDB Atlas Not Connected'}
              </span>
            </div>
          </div>

          {!previewData.databaseConnected && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 flex items-start gap-2.5 text-xs text-amber-950">
              <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <span>
                Your backend is not currently connected to MongoDB Atlas (<span className="font-mono">Medi_Bridge</span>). Preview works offline, but live import requires an active Atlas connection.
              </span>
            </div>
          )}

          {/* Column Mapping Controls */}
          <div>
            <p className="text-xs font-semibold text-slate-800 mb-2">
              Detected Field Mapping (Adjust if Needed)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {TARGET_FIELD_LABELS.map(({ key, label, required }) => {
                const mappedValue = previewData.columnMapping[key] || '';
                return (
                  <div key={key} className="bg-slate-50 border border-slate-200 rounded-lg p-2.5">
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      {label} {required && <span className="text-red-600">*</span>}
                    </label>
                    <select
                      value={mappedValue}
                      onChange={(e) => handleOverrideChange(key, e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      <option value="">(Unmapped / Leave empty)</option>
                      {previewData.headers.map((h) => (
                        <option key={h} value={h}>
                          {h}
                        </option>
                      ))}
                    </select>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 10-Record Preview Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-slate-800">
                Preview of First {previewData.previewRows.length} Records (All Imported With{' '}
                <span className="font-mono">verified: false</span>)
              </p>
              {previewData.invalidRowCountInPreview > 0 && (
                <span className="text-xs text-amber-700 font-medium">
                  {previewData.invalidRowCountInPreview} preview row(s) missing hospital name (will fail safely)
                </span>
              )}
            </div>

            <div className="border border-slate-200 rounded-xl overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-700">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">#</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">Source ID</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">Hospital Name</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">Facility Type</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">State / District / City</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">PIN Code</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">Address</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">Phone</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">Lat / Lng</th>
                    <th className="py-2.5 px-3 font-semibold whitespace-nowrap">Verified</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {previewData.previewRows.map((row) => (
                    <tr key={row.rowNumber} className={row.valid ? 'hover:bg-slate-50' : 'bg-red-50/60'}>
                      <td className="py-2 px-3 font-mono tabular-nums text-slate-500">
                        {row.rowNumber}
                      </td>
                      <td className="py-2 px-3 font-mono tabular-nums text-slate-600 whitespace-nowrap">
                        {row.sourceId || '—'}
                      </td>
                      <td className="py-2 px-3 font-medium text-slate-900 min-w-[180px]">
                        {row.name || <span className="text-red-700">Missing name</span>}
                      </td>
                      <td className="py-2 px-3 text-slate-700 whitespace-nowrap">
                        {row.facilityType || '—'}
                      </td>
                      <td className="py-2 px-3 text-slate-700 min-w-[160px]">
                        {[row.city, row.district, row.state].filter(Boolean).join(', ') || '—'}
                      </td>
                      <td className="py-2 px-3 font-mono tabular-nums text-slate-700 whitespace-nowrap">
                        {row.pincode || '—'}
                      </td>
                      <td className="py-2 px-3 text-slate-600 max-w-[220px] truncate" title={row.address}>
                        {row.address || '—'}
                      </td>
                      <td className="py-2 px-3 font-mono tabular-nums text-slate-700 whitespace-nowrap">
                        {row.phone || '—'}
                      </td>
                      <td className="py-2 px-3 font-mono tabular-nums text-slate-600 whitespace-nowrap">
                        {row.latitude !== null && row.longitude !== null
                          ? `${row.latitude}, ${row.longitude}`
                          : '—'}
                      </td>
                      <td className="py-2 px-3 font-mono text-amber-700 whitespace-nowrap">
                        false
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Import Action Row */}
          <div className="pt-2 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100">
            <p className="text-xs text-slate-500">
              Batch size: 500 records/batch · Preserves all existing records · Skips duplicate{' '}
              <span className="font-mono">sourceId</span> / fingerprints.
            </p>
            <button
              type="button"
              onClick={handleImport}
              disabled={importing || !previewData.databaseConnected || !previewData.columnMapping.name}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              {importing
                ? 'Importing Batches into MongoDB...'
                : `Import ${previewData.totalRows.toLocaleString()} Rows to Medi_Bridge`}
            </button>
          </div>
        </section>
      )}

      {/* Import Error */}
      {importError && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-2.5 text-sm text-red-800">
          <ShieldAlert className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
          <span>{importError}</span>
        </div>
      )}

      {/* Batch Progress & Counts */}
      {importProgress && (
        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {importProgress.type === 'complete' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              ) : (
                <RefreshCw className="w-5 h-5 text-blue-700 animate-spin" />
              )}
              <h3 className="text-base font-semibold text-slate-900">
                {importProgress.type === 'complete'
                  ? 'Hospital Dataset Import Complete'
                  : `Importing Batch ${importProgress.currentBatch} of ${importProgress.totalBatches}...`}
              </h3>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-600">
              {importProgress.processedRows.toLocaleString()} /{' '}
              {importProgress.totalRows.toLocaleString()} rows ({progressPct}%)
            </span>
          </div>

          <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-700 transition-all duration-150"
              style={{ width: `${progressPct}%` }}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="border border-emerald-200 bg-emerald-50 rounded-xl p-4">
              <p className="text-xs font-medium text-emerald-800">Inserted Records</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-emerald-950 mt-1">
                {importProgress.insertedCount.toLocaleString()}
              </p>
              <p className="text-xs text-emerald-700 mt-0.5">Added with verified=false</p>
            </div>

            <div className="border border-amber-200 bg-amber-50 rounded-xl p-4">
              <p className="text-xs font-medium text-amber-800">Skipped Duplicates</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-amber-950 mt-1">
                {importProgress.skippedCount.toLocaleString()}
              </p>
              <p className="text-xs text-amber-700 mt-0.5">Existing records preserved</p>
            </div>

            <div className="border border-red-200 bg-red-50 rounded-xl p-4">
              <p className="text-xs font-medium text-red-800">Failed Rows</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-red-950 mt-1">
                {importProgress.failedCount.toLocaleString()}
              </p>
              <p className="text-xs text-red-700 mt-0.5">Missing required fields or write error</p>
            </div>
          </div>

          {importProgress.sampleErrors.length > 0 && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-1.5">
              <p className="text-xs font-semibold text-slate-800">
                Sample Row Issues (showing up to {importProgress.sampleErrors.length})
              </p>
              <ul className="text-xs font-mono text-slate-600 space-y-1 max-h-40 overflow-y-auto">
                {importProgress.sampleErrors.map((msg, idx) => (
                  <li key={idx}>{msg}</li>
                ))}
              </ul>
            </div>
          )}

          {importProgress.type === 'complete' && (onGoToHospitalFinder || onGoToVerification) && (
            <div className="pt-1 flex flex-wrap justify-end gap-2">
              {onGoToVerification && (
                <button
                  type="button"
                  onClick={onGoToVerification}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap cursor-pointer"
                >
                  Verify Imported Hospitals
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
              {onGoToHospitalFinder && (
                <button
                  type="button"
                  onClick={onGoToHospitalFinder}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg whitespace-nowrap cursor-pointer"
                >
                  Search Imported Hospitals in Hospital Finder
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </section>
      )}
    </div>
  );
};
