import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  Bell,
  BellOff,
  Calendar,
  CheckCircle2,
  Clock,
  Edit3,
  KeyRound,
  LogOut,
  Pill,
  Plus,
  SkipForward,
  Trash2,
  UserPlus,
} from 'lucide-react';
import { apiFetchJson } from '../utils/apiClient';
import type {
  AuthenticatedUser,
  MedicineReminderRecord,
  PatientAccountProfile,
  ReminderActionStatus,
} from '../types/healthcare';

interface MedicineReminderProps {
  userToken: string | null;
  activeUser: AuthenticatedUser | null;
  activePatient?: PatientAccountProfile | null;
  onGoToPatientAuth?: (mode: 'login' | 'register') => void;
  onUserAuthSuccess: (user: AuthenticatedUser, token: string) => void;
  onUserSignOut: () => void;
}

type BrowserNotifState = 'granted' | 'denied' | 'default' | 'unsupported';

function getBrowserNotifState(): BrowserNotifState {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission;
}

function todayIso(): string {
  return new Date().toISOString().split('T')[0];
}

function addDaysIso(baseIso: string, days: number): string {
  const d = new Date(`${baseIso}T00:00:00`);
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

function isReminderUpcoming(reminder: MedicineReminderRecord): boolean {
  const today = todayIso();
  if (reminder.endDate < today) return false;
  if (reminder.status === 'completed' || reminder.status === 'skipped') return false;
  return true;
}

export const MedicineReminder: React.FC<MedicineReminderProps> = ({
  userToken,
  activeUser,
  activePatient = null,
  onGoToPatientAuth,
  onUserAuthSuccess,
  onUserSignOut,
}) => {
  // User authentication state
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [authFullName, setAuthFullName] = useState('');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Reminder data & form state
  const [reminders, setReminders] = useState<MedicineReminderRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [reminderName, setReminderName] = useState('');
  const [medicineName, setMedicineName] = useState('');
  const [prescribedSchedule, setPrescribedSchedule] = useState('');
  const [startDate, setStartDate] = useState(todayIso);
  const [endDate, setEndDate] = useState(() => addDaysIso(todayIso(), 7));
  const [timeInput, setTimeInput] = useState('08:00');
  const [reminderTimes, setReminderTimes] = useState<string[]>(['08:00']);
  const [dateInput, setDateInput] = useState('');
  const [selectedDates, setSelectedDates] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Browser notification state (never requests automatically, never sends without permission)
  const [notifPermission, setNotifPermission] = useState<BrowserNotifState>(getBrowserNotifState);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [notifFeedback, setNotifFeedback] = useState<string | null>(null);
  const firedNotifsRef = useRef<Set<string>>(new Set());

  const isAuthenticated = Boolean(activePatient || (userToken && activeUser));

  const getAuthHeaders = (
    tokenToUse = userToken,
    extra: Record<string, string> = {}
  ): Record<string, string> => {
    if (tokenToUse) {
      return { ...extra, Authorization: `Bearer ${tokenToUse}` };
    }
    return extra;
  };

  const fetchReminders = async (tokenToUse = userToken) => {
    if (!tokenToUse && !activePatient) return;
    setLoading(true);
    setError(null);
    try {
      const json = await apiFetchJson<{ reminders?: MedicineReminderRecord[] }>(
        '/api/reminders',
        { headers: getAuthHeaders(tokenToUse) },
        'Unable to load reminders.'
      );
      setReminders(Array.isArray(json.reminders) ? json.reminders : []);
    } catch (err) {
      if ((err as { status?: number })?.status === 401) {
        onUserSignOut();
      }
      setError(err instanceof Error ? err.message : 'Unable to load reminders.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (userToken || activePatient) {
      fetchReminders(userToken);
    } else {
      setReminders([]);
      setNotificationsEnabled(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userToken, activePatient?.patientId]);

  // Foreground notification dispatcher (strictly gated on granted permission + explicit opt-in)
  useEffect(() => {
    if (!isAuthenticated || !notificationsEnabled || notifPermission !== 'granted') {
      return;
    }

    const checkDueReminders = () => {
      if (typeof window === 'undefined' || !('Notification' in window)) return;
      if (Notification.permission !== 'granted') return;

      const now = new Date();
      const currentDate = now.toISOString().split('T')[0];
      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const currentTime = `${hh}:${mm}`;

      for (const rem of reminders) {
        if (rem.status !== 'pending') continue;
        if (currentDate < rem.startDate || currentDate > rem.endDate) continue;
        if (rem.selectedDates.length > 0 && !rem.selectedDates.includes(currentDate)) continue;
        if (!rem.reminderTimes.includes(currentTime)) continue;

        const key = `${rem.id}:${currentDate}:${currentTime}`;
        if (firedNotifsRef.current.has(key)) continue;
        firedNotifsRef.current.add(key);

        try {
          new Notification(`Medicine Reminder: ${rem.reminderName}`, {
            body: `${rem.medicineName} — Schedule: ${rem.prescribedSchedule}`,
          });
        } catch {
          // Browser restricted Notification constructor
        }
      }
    };

    checkDueReminders();
    const timer = window.setInterval(checkDueReminders, 30000);
    return () => window.clearInterval(timer);
  }, [isAuthenticated, notificationsEnabled, notifPermission, reminders]);

  const handleRequestNotifications = async () => {
    setNotifFeedback(null);
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setNotifPermission('unsupported');
      setNotificationsEnabled(false);
      setNotifFeedback(
        'Browser notifications are not supported in this browser or embedded window. You can still view and track all upcoming reminders on this page.'
      );
      return;
    }

    try {
      const result = await Notification.requestPermission();
      setNotifPermission(result);
      if (result === 'granted') {
        setNotificationsEnabled(true);
        setNotifFeedback('Browser notifications enabled for this session.');
      } else if (result === 'denied') {
        setNotificationsEnabled(false);
        setNotifFeedback(
          'Notification permission was blocked. Please enable notifications in your browser site settings if you want alerts.'
        );
      } else {
        setNotificationsEnabled(false);
        setNotifFeedback('Notification permission was dismissed. Reminders will not alert automatically.');
      }
    } catch {
      setNotifPermission('unsupported');
      setNotificationsEnabled(false);
      setNotifFeedback(
        'Browser notifications are unavailable in this environment. Upcoming reminders remain visible here.'
      );
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSubmitting(true);
    try {
      const endpoint = authMode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const body =
        authMode === 'register'
          ? { fullName: authFullName, email: authEmail, password: authPassword }
          : { email: authEmail, password: authPassword };

      const json = await apiFetchJson<{ user: AuthenticatedUser; token: string }>(
        endpoint,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        },
        'Authentication failed.'
      );
      setAuthPassword('');
      onUserAuthSuccess(json.user, json.token);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Unable to sign in.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setReminderName('');
    setMedicineName('');
    setPrescribedSchedule('');
    const today = todayIso();
    setStartDate(today);
    setEndDate(addDaysIso(today, 7));
    setTimeInput('08:00');
    setReminderTimes(['08:00']);
    setDateInput('');
    setSelectedDates([]);
    setNotes('');
    setFormError(null);
  };

  const handleAddTime = () => {
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(timeInput)) return;
    if (!reminderTimes.includes(timeInput) && reminderTimes.length < 8) {
      setReminderTimes((prev) => [...prev, timeInput].sort());
    }
  };

  const handleAddDate = () => {
    if (!dateInput) return;
    if (dateInput < startDate || dateInput > endDate) {
      setFormError('Selected date must be between the start date and end date.');
      return;
    }
    setFormError(null);
    if (!selectedDates.includes(dateInput)) {
      setSelectedDates((prev) => [...prev, dateInput].sort());
    }
    setDateInput('');
  };

  const handleSaveReminder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated) return;
    setFormError(null);
    if (endDate < startDate) {
      setFormError('End date cannot be earlier than start date.');
      return;
    }
    if (reminderTimes.length === 0) {
      setFormError('Add at least one reminder time.');
      return;
    }

    setSaving(true);
    try {
      const url = editingId
        ? `/api/reminders/${encodeURIComponent(editingId)}`
        : '/api/reminders';
      const method = editingId ? 'PATCH' : 'POST';
      await apiFetchJson<{ reminder: MedicineReminderRecord }>(
        url,
        {
          method,
          headers: getAuthHeaders(userToken, { 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            reminderName,
            medicineName,
            prescribedSchedule,
            reminderTimes,
            selectedDates,
            startDate,
            endDate,
            notes,
          }),
        },
        'Unable to save reminder.'
      );

      resetForm();
      await fetchReminders(userToken);
    } catch (err) {
      if ((err as { status?: number })?.status === 401) {
        onUserSignOut();
      }
      setFormError(err instanceof Error ? err.message : 'Unable to save reminder.');
    } finally {
      setSaving(false);
    }
  };

  const handleStartEdit = (rem: MedicineReminderRecord) => {
    setEditingId(rem.id);
    setReminderName(rem.reminderName);
    setMedicineName(rem.medicineName);
    setPrescribedSchedule(rem.prescribedSchedule);
    setStartDate(rem.startDate);
    setEndDate(rem.endDate);
    setReminderTimes(rem.reminderTimes.length > 0 ? rem.reminderTimes : ['08:00']);
    setSelectedDates(rem.selectedDates || []);
    setNotes(rem.notes || '');
    setFormError(null);
  };

  const handleStatusChange = async (id: string, status: ReminderActionStatus) => {
    if (!isAuthenticated) return;
    setError(null);
    try {
      await apiFetchJson<{ reminder: MedicineReminderRecord }>(
        `/api/reminders/${encodeURIComponent(id)}`,
        {
          method: 'PATCH',
          headers: getAuthHeaders(userToken, { 'Content-Type': 'application/json' }),
          body: JSON.stringify({ status }),
        },
        'Unable to update reminder status.'
      );
      await fetchReminders(userToken);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update reminder status.');
    }
  };

  const handleDeleteReminder = async (id: string) => {
    if (!isAuthenticated) return;
    setError(null);
    try {
      await apiFetchJson<{ deleted: boolean }>(
        `/api/reminders/${encodeURIComponent(id)}`,
        {
          method: 'DELETE',
          headers: getAuthHeaders(userToken),
        },
        'Unable to delete reminder.'
      );
      if (editingId === id) {
        resetForm();
      }
      await fetchReminders(userToken);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to delete reminder.');
    }
  };

  const upcomingReminders = useMemo(
    () => reminders.filter(isReminderUpcoming),
    [reminders]
  );

  // Authentication Gate
  if (!isAuthenticated) {
    return (
      <div className="max-w-xl mx-auto space-y-6">
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-sm text-amber-950">
            <p className="font-semibold">Personal Doctor or Pharmacist Schedule Only</p>
            <p className="text-amber-900 mt-0.5">
              MediBridge AI never recommends medicines or generates dosages. Enter only the medication schedule provided by your doctor or pharmacist.
            </p>
          </div>
        </div>

        {onGoToPatientAuth && (
          <section className="bg-blue-50 border border-blue-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-semibold text-blue-950">
                Use Your MediBridge Patient ID
              </h3>
              <p className="text-xs text-blue-900 mt-0.5">
                Log in with your Patient ID or register to link medicine reminders directly to your patient account.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 shrink-0">
              <button
                type="button"
                onClick={() => onGoToPatientAuth('login')}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer whitespace-nowrap"
              >
                Patient Login
              </button>
              <button
                type="button"
                onClick={() => onGoToPatientAuth('register')}
                className="px-3.5 py-2 text-xs font-semibold text-blue-800 bg-white hover:bg-blue-100 border border-blue-300 rounded-lg cursor-pointer whitespace-nowrap"
              >
                Patient Register
              </button>
            </div>
          </section>
        )}

        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div className="border-b border-slate-100 pb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">Medicine Reminder</h2>
              <p className="text-sm text-slate-600 mt-0.5">
                Sign in or create a MediBridge account to save and manage your personal medication reminders securely.
              </p>
            </div>
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setAuthError(null);
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                  authMode === 'login' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode('register');
                  setAuthError(null);
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                  authMode === 'register' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Create Account
              </button>
            </div>
          </div>

          {authError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
              {authError}
            </div>
          )}

          <form onSubmit={handleAuthSubmit} className="space-y-4">
            {authMode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Full Name <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  minLength={2}
                  value={authFullName}
                  onChange={(e) => setAuthFullName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Email Address <span className="text-red-600">*</span>
              </label>
              <input
                type="email"
                required
                value={authEmail}
                onChange={(e) => setAuthEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Password <span className="text-red-600">*</span>
              </label>
              <input
                type="password"
                required
                minLength={8}
                value={authPassword}
                onChange={(e) => setAuthPassword(e.target.value)}
                placeholder="Minimum 8 characters"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <button
              type="submit"
              disabled={authSubmitting}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
            >
              {authMode === 'register' ? (
                <>
                  <UserPlus className="w-4 h-4" />
                  {authSubmitting ? 'Creating Account...' : 'Create Account & Continue'}
                </>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  {authSubmitting ? 'Signing In...' : 'Sign In to Reminders'}
                </>
              )}
            </button>
          </form>
        </section>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Account Bar */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-700">
            {activePatient
              ? `Signed in as ${activePatient.fullName} · Patient ID: ${activePatient.patientId}`
              : `Signed in as ${activeUser?.fullName} (${activeUser?.email})`}
          </p>
          <h2 className="text-lg font-semibold text-slate-900 mt-0.5">Medicine Reminder</h2>
          <p className="text-sm text-slate-600">
            Track medications strictly according to the schedule given by your doctor or pharmacist.
          </p>
        </div>

        <button
          type="button"
          onClick={onUserSignOut}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign Out
        </button>
      </section>

      {/* Safety Notice + Browser Notification Permission Control */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm text-amber-950">
            <p className="font-semibold">Doctor / Pharmacist Schedule Required</p>
            <p className="text-amber-900 mt-0.5">
              MediBridge AI never recommends dosages or frequencies. Only record instructions confirmed by your qualified healthcare provider.
            </p>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between gap-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              {notifPermission === 'granted' && notificationsEnabled ? (
                <Bell className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <BellOff className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
              )}
              <div>
                <p className="text-sm font-semibold text-slate-900">Browser Notifications</p>
                <p className="text-xs text-slate-600 mt-0.5">
                  {notifPermission === 'unsupported'
                    ? 'Browser notifications are unavailable in this browser or preview frame.'
                    : notifPermission === 'denied'
                    ? 'Permission denied in browser settings. Notifications will not be sent.'
                    : notifPermission === 'granted'
                    ? notificationsEnabled
                      ? 'Notifications allowed and active while this tab is open.'
                      : 'Permission granted. Toggle alerts on when you want active reminders.'
                    : 'Notifications require your explicit permission before any alert is sent.'}
                </p>
              </div>
            </div>

            {notifPermission === 'granted' ? (
              <button
                type="button"
                onClick={() => setNotificationsEnabled((v) => !v)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg border whitespace-nowrap shrink-0 cursor-pointer ${
                  notificationsEnabled
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-blue-700 text-white border-blue-700'
                }`}
              >
                {notificationsEnabled ? 'Pause Alerts' : 'Enable Alerts'}
              </button>
            ) : (
              <button
                type="button"
                onClick={handleRequestNotifications}
                disabled={notifPermission === 'unsupported'}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
              >
                Enable Notifications
              </button>
            )}
          </div>
          {notifFeedback && (
            <p className="text-xs text-blue-800 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
              {notifFeedback}
            </p>
          )}
        </div>
      </div>

      {/* Main Grid: Create/Edit Form + Upcoming & All Reminders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Add / Edit Reminder Form */}
        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4 h-fit">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-base font-semibold text-slate-900">
              {editingId ? 'Edit Medicine Reminder' : 'Add Medicine Reminder'}
            </h3>
            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="text-xs font-medium text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                Cancel Edit
              </button>
            )}
          </div>

          {formError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-xs text-red-800">
              {formError}
            </div>
          )}

          <form onSubmit={handleSaveReminder} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Reminder Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                minLength={2}
                value={reminderName}
                onChange={(e) => setReminderName(e.target.value)}
                placeholder="e.g., Morning Blood Pressure Tablet"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Medicine Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                minLength={2}
                value={medicineName}
                onChange={(e) => setMedicineName(e.target.value)}
                placeholder="e.g., Prescribed tablet name"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Schedule Provided by Doctor or Pharmacist <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                minLength={2}
                value={prescribedSchedule}
                onChange={(e) => setPrescribedSchedule(e.target.value)}
                placeholder="Enter exact instruction from your prescription"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Start Date <span className="text-red-600">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  End Date <span className="text-red-600">*</span>
                </label>
                <input
                  type="date"
                  required
                  min={startDate}
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>
            </div>

            {/* Reminder Times */}
            <div className="space-y-2">
              <label className="block text-xs font-medium text-slate-700">
                Reminder Times <span className="text-red-600">*</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="time"
                  value={timeInput}
                  onChange={(e) => setTimeInput(e.target.value)}
                  className="flex-1 px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
                <button
                  type="button"
                  onClick={handleAddTime}
                  className="inline-flex items-center gap-1 px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Time
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {reminderTimes.map((t) => (
                  <span
                    key={t}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono tabular-nums bg-slate-100 text-slate-800 rounded-md border border-slate-200"
                  >
                    {t}
                    {reminderTimes.length > 1 && (
                      <button
                        type="button"
                        onClick={() => setReminderTimes((prev) => prev.filter((x) => x !== t))}
                        aria-label={`Remove ${t}`}
                        className="text-slate-500 hover:text-red-700 cursor-pointer"
                      >
                        ×
                      </button>
                    )}
                  </span>
                ))}
              </div>
            </div>

            {/* Specific Reminder Dates (Optional) */}
            <div className="space-y-2">
              <label className="block text-xs font-medium text-slate-700">
                Specific Reminder Dates (Optional — leave blank for every day in range)
              </label>
              <div className="flex gap-2">
                <input
                  type="date"
                  min={startDate}
                  max={endDate}
                  value={dateInput}
                  onChange={(e) => setDateInput(e.target.value)}
                  className="flex-1 px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
                <button
                  type="button"
                  onClick={handleAddDate}
                  disabled={!dateInput}
                  className="inline-flex items-center gap-1 px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 disabled:opacity-50 border border-blue-200 rounded-lg cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Date
                </button>
              </div>
              {selectedDates.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {selectedDates.map((d) => (
                    <span
                      key={d}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono tabular-nums bg-blue-50 text-blue-800 rounded-md border border-blue-200"
                    >
                      {d}
                      <button
                        type="button"
                        onClick={() => setSelectedDates((prev) => prev.filter((x) => x !== d))}
                        aria-label={`Remove ${d}`}
                        className="text-blue-600 hover:text-red-700 cursor-pointer"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Personal Notes (Optional)
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g., With water, keep in cool dry place"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
            >
              {saving
                ? 'Saving Reminder...'
                : editingId
                ? 'Save Reminder Changes'
                : 'Save Medicine Reminder'}
            </button>
          </form>
        </section>

        {/* Right: Upcoming & Saved Reminders */}
        <section className="lg:col-span-7 space-y-5">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
              {error}
            </div>
          )}

          {/* Upcoming Summary Strip */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-700" />
                <h3 className="text-base font-semibold text-slate-900">Upcoming Reminders</h3>
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {upcomingReminders.length} active
              </span>
            </div>

            {loading ? (
              <div className="space-y-2 animate-pulse">
                <div className="h-16 bg-slate-100 rounded-lg" />
                <div className="h-16 bg-slate-100 rounded-lg" />
              </div>
            ) : upcomingReminders.length > 0 ? (
              <div className="space-y-2.5">
                {upcomingReminders.map((rem) => (
                  <div
                    key={rem.id}
                    className="border border-blue-200 bg-blue-50/40 rounded-lg p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <p className="text-sm font-semibold text-slate-900">
                        {rem.reminderName} ·{' '}
                        <span className="text-blue-700">{rem.medicineName}</span>
                      </p>
                      <p className="text-xs text-slate-700">
                        Schedule: {rem.prescribedSchedule}
                      </p>
                      <p className="text-xs font-mono tabular-nums text-slate-600">
                        Times: {rem.reminderTimes.join(', ')} · {rem.startDate} to {rem.endDate}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleStatusChange(rem.id, 'completed')}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md whitespace-nowrap cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Complete
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStatusChange(rem.id, 'skipped')}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-md whitespace-nowrap cursor-pointer"
                      >
                        <SkipForward className="w-3.5 h-3.5" />
                        Skip
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-600 py-2">
                No pending upcoming reminders. Add a reminder using your doctor or pharmacist schedule on the left.
              </p>
            )}
          </div>

          {/* All Reminders List */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <Pill className="w-4 h-4 text-blue-700" />
                <h3 className="text-base font-semibold text-slate-900">All Saved Reminders</h3>
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {reminders.length} total
              </span>
            </div>

            {reminders.length > 0 ? (
              <div className="space-y-3">
                {reminders.map((rem) => (
                  <article
                    key={rem.id}
                    className="border border-slate-200 rounded-xl p-4 space-y-3"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 font-semibold border rounded ${
                              rem.status === 'completed'
                                ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                                : rem.status === 'skipped'
                                ? 'text-amber-800 bg-amber-50 border-amber-200'
                                : 'text-blue-800 bg-blue-50 border-blue-200'
                            }`}
                          >
                            {rem.status === 'completed'
                              ? 'Completed'
                              : rem.status === 'skipped'
                              ? 'Skipped'
                              : 'Pending'}
                          </span>
                          <span className="font-mono tabular-nums text-slate-500">
                            {rem.reminderTimes.join(', ')}
                          </span>
                        </div>
                        <h4 className="text-base font-semibold text-slate-900">
                          {rem.reminderName}
                        </h4>
                        <p className="text-sm font-medium text-blue-700">{rem.medicineName}</p>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleStartEdit(rem)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-blue-700 border border-slate-200 rounded-lg cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteReminder(rem.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 border border-red-200 rounded-lg cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          Delete
                        </button>
                      </div>
                    </div>

                    <div className="text-xs text-slate-600 space-y-1 bg-slate-50 rounded-lg p-3">
                      <p>
                        <strong>Doctor / Pharmacist Schedule:</strong> {rem.prescribedSchedule}
                      </p>
                      <p className="flex items-center gap-1.5 font-mono tabular-nums">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>
                          {rem.startDate} to {rem.endDate}
                          {rem.selectedDates.length > 0
                            ? ` · Specific dates: ${rem.selectedDates.join(', ')}`
                            : ' · Daily within range'}
                        </span>
                      </p>
                      {rem.notes && (
                        <p>
                          <strong>Notes:</strong> {rem.notes}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <span className="text-xs text-slate-500">
                        {rem.lastActionAt
                          ? `Last marked ${rem.status} on ${new Date(rem.lastActionAt).toLocaleString()}`
                          : 'Not marked yet'}
                      </span>
                      <div className="flex items-center gap-2">
                        {rem.status !== 'completed' && (
                          <button
                            type="button"
                            onClick={() => handleStatusChange(rem.id, 'completed')}
                            className="px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md cursor-pointer"
                          >
                            Mark Completed
                          </button>
                        )}
                        {rem.status !== 'skipped' && (
                          <button
                            type="button"
                            onClick={() => handleStatusChange(rem.id, 'skipped')}
                            className="px-2.5 py-1 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-md cursor-pointer"
                          >
                            Mark Skipped
                          </button>
                        )}
                        {rem.status !== 'pending' && (
                          <button
                            type="button"
                            onClick={() => handleStatusChange(rem.id, 'pending')}
                            className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
                          >
                            Reset Pending
                          </button>
                        )}
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              !loading && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 text-center text-xs text-slate-600">
                  You have no saved medicine reminders yet.
                </div>
              )
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
