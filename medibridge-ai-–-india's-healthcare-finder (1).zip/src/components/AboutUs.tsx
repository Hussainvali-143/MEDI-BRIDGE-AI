import React from 'react';
import { AlertCircle, Building2, HeartHandshake, Pill, ShieldCheck } from 'lucide-react';

export const AboutUs: React.FC = () => {
  return (
    <div className="space-y-6">
      <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
          <HeartHandshake className="w-4 h-4" />
          <span>About MediBridge AI</span>
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
          Transparent Healthcare Information &amp; Assistance for India
        </h2>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-3xl">
          MediBridge AI is designed to help patients and families across India locate healthcare facilities, review educational medicine information, manage personal doctor-prescribed medication reminders, and access quick national emergency dialing guidance—without inventing clinical claims.
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-2">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <h3 className="text-base font-semibold text-slate-900">Verified vs. Unverified Clarity</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Every hospital and medicine record clearly displays whether it has been verified against an official source or remains unverified. Records are never auto-verified or fabricated.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-2">
          <Building2 className="w-5 h-5 text-blue-700" />
          <h3 className="text-base font-semibold text-slate-900">India-Wide Hospital Discovery</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Search hospitals across Indian States, Districts, Cities, and 6-digit PIN codes with preserved database integrity and official source attribution on verified entries.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-2">
          <Pill className="w-5 h-5 text-blue-700" />
          <h3 className="text-base font-semibold text-slate-900">Non-Prescriptive Medicine Guidance</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Medicine information and personal reminders strictly support patient understanding and adherence to schedules provided by your licensed doctor or pharmacist.
          </p>
        </div>
      </section>

      <section className="bg-amber-50 border border-amber-200 rounded-xl p-5 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div className="text-sm text-amber-950 space-y-1">
          <p className="font-semibold">Clinical &amp; Emergency Boundaries</p>
          <p className="text-amber-900">
            MediBridge AI does not diagnose medical conditions, prescribe medicines, generate dosages, or dispatch ambulances. Always consult a qualified healthcare professional for medical advice, and dial <strong>112</strong> directly in any emergency.
          </p>
        </div>
      </section>
    </div>
  );
};
