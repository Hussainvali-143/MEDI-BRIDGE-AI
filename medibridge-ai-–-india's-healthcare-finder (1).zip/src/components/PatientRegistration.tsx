import React, { useEffect, useState } from 'react';
import { CalendarPlus, CheckCircle2, Copy, Search, UserCheck, UserPlus } from 'lucide-react';
import { INDIAN_STATES_AND_UTS } from '../data/indianLocations';
import { apiFetchJson } from '../utils/apiClient';
import type { PatientRecord } from '../types/healthcare';

interface PatientRegistrationProps {
  activePatient: PatientRecord | null;
  onPatientSelected: (patient: PatientRecord) => void;
  onProceedToBooking: (patient: PatientRecord) => void;
}

export const PatientRegistration: React.FC<PatientRegistrationProps> = ({
  activePatient,
  onPatientSelected,
  onProceedToBooking,
}) => {
  const [fullName, setFullName] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('Female');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');
  const [emergencyContact, setEmergencyContact] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [district, setDistrict] = useState('');
  const [state, setState] = useState('');
  const [pinCode, setPinCode] = useState('');
  const [allergiesOrConditions, setAllergiesOrConditions] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [createdPatient, setCreatedPatient] = useState<PatientRecord | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  const [lookupQuery, setLookupQuery] = useState('');
  const [patients, setPatients] = useState<PatientRecord[]>([]);
  const [lookupLoading, setLookupLoading] = useState(true);

  const fetchPatients = async (q = '') => {
    setLookupLoading(true);
    try {
      const params = new URLSearchParams();
      if (q.trim()) params.set('q', q.trim());
      const json = await apiFetchJson<{ patients?: PatientRecord[] }>(
        `/api/patients/lookup?${params.toString()}`,
        { method: 'GET' },
        'Unable to look up patient records.'
      );
      if (Array.isArray(json.patients)) {
        setPatients(json.patients);
      }
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Unable to look up patient records.');
    } finally {
      setLookupLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients('');
  }, []);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError(null);
    try {
      const json = await apiFetchJson<{ patient: PatientRecord }>(
        '/api/patients/register',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fullName,
            age: Number(age),
            gender,
            phone,
            email,
            bloodGroup,
            emergencyContact,
            address,
            city,
            district,
            state,
            pinCode,
            allergiesOrConditions,
          }),
        },
        'Failed to register patient.'
      );

      const patient = json.patient;
      setCreatedPatient(patient);
      onPatientSelected(patient);
      setFullName('');
      setAge('');
      setPhone('');
      setEmail('');
      setBloodGroup('');
      setEmergencyContact('');
      setAddress('');
      setCity('');
      setDistrict('');
      setState('');
      setPinCode('');
      setAllergiesOrConditions('');
      fetchPatients('');
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Registration failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCopyId = async (id: string) => {
    try {
      await navigator.clipboard.writeText(id);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left: Registration Form */}
      <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
            <UserPlus className="w-4 h-4" />
            <span>Patient Onboarding</span>
          </div>
          <h2 className="text-lg font-semibold text-slate-900 mt-1">
            Register Patient &amp; Generate Unique Patient ID
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            Creates a unique MediBridge Patient ID (<span className="font-mono">MB-IN-...</span>) for appointment requests without modifying existing records.
          </p>
        </div>

        {createdPatient && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-emerald-950">
                    Patient Registered Successfully
                  </p>
                  <p className="text-xs text-emerald-800 mt-0.5">
                    {createdPatient.fullName} · {createdPatient.city}, {createdPatient.state}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleCopyId(createdPatient.patientId)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-emerald-900 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-100 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                {copiedId ? 'Copied' : 'Copy ID'}
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-emerald-200 rounded-lg px-3.5 py-2.5">
              <div>
                <p className="text-xs text-slate-500">Unique Patient ID</p>
                <p className="text-base font-mono font-semibold tabular-nums text-slate-900">
                  {createdPatient.patientId}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onProceedToBooking(createdPatient)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
              >
                <CalendarPlus className="w-3.5 h-3.5" />
                Book Appointment Now
              </button>
            </div>
          </div>
        )}

        {submitError && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 text-sm text-red-800">
            {submitError}
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Full Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Patient's full legal name"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Age (Years) <span className="text-red-600">*</span>
              </label>
              <input
                type="number"
                required
                min={0}
                max={125}
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="e.g., 34"
                className="w-full px-3 py-2 text-sm tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Gender <span className="text-red-600">*</span>
              </label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              >
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Non-Binary / Other">Non-Binary / Other</option>
                <option value="Prefer not to say">Prefer not to say</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Mobile / Phone Number <span className="text-red-600">*</span>
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="e.g., +91 9876543210"
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Email Address (Optional)
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="patient@example.com"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Blood Group</label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              >
                <option value="">Select (Optional)</option>
                {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                  <option key={bg} value={bg}>
                    {bg}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Emergency Contact Number
              </label>
              <input
                type="tel"
                value={emergencyContact}
                onChange={(e) => setEmergencyContact(e.target.value)}
                placeholder="Family / guardian phone"
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Residential Street Address
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="House / Street / Locality"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                State / UT <span className="text-red-600">*</span>
              </label>
              <select
                required
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              >
                <option value="">Select State / UT</option>
                {INDIAN_STATES_AND_UTS.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">District</label>
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                placeholder="District"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                City / Town <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="City or town"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                6-Digit PIN Code <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                inputMode="numeric"
                maxLength={6}
                pattern="\d{6}"
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="e.g., 560001"
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Known Allergies or Chronic Conditions (Optional)
              </label>
              <input
                type="text"
                value={allergiesOrConditions}
                onChange={(e) => setAllergiesOrConditions(e.target.value)}
                placeholder="e.g., Penicillin allergy, Type 2 Diabetes"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="w-full sm:w-auto px-6 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg transition-colors cursor-pointer"
            >
              {submitting ? 'Registering Patient...' : 'Register & Generate Patient ID'}
            </button>
          </div>
        </form>
      </section>

      {/* Right: Patient ID Lookup */}
      <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4 h-fit">
        <div className="border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
            <UserCheck className="w-4 h-4" />
            <span>Patient Directory</span>
          </div>
          <h3 className="text-base font-semibold text-slate-900 mt-1">
            Look Up Existing Patient ID
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            Search by Patient ID, phone number, or full name to select a patient for appointment requests.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchPatients(lookupQuery);
          }}
          className="flex gap-2"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={lookupQuery}
              onChange={(e) => setLookupQuery(e.target.value)}
              placeholder="MB-IN-2026-... or phone"
              className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>
          <button
            type="submit"
            className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
          >
            Find
          </button>
        </form>

        {lookupLoading ? (
          <div className="space-y-2.5 animate-pulse">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-slate-100 rounded-lg" />
            ))}
          </div>
        ) : patients.length > 0 ? (
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
            {patients.map((pt) => {
              const isSelected = activePatient?.patientId === pt.patientId;
              return (
                <div
                  key={pt.patientId}
                  className={`p-3.5 flex items-center justify-between gap-3 ${
                    isSelected ? 'bg-blue-50' : 'bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="min-w-0">
                    <p className="text-xs font-mono font-semibold tabular-nums text-blue-700">
                      {pt.patientId}
                    </p>
                    <p className="text-sm font-semibold text-slate-900 truncate">{pt.fullName}</p>
                    <p className="text-xs text-slate-500 tabular-nums truncate">
                      {pt.age} yrs · {pt.gender} · {pt.city}, {pt.state}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onPatientSelected(pt);
                      onProceedToBooking(pt);
                    }}
                    className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-white border border-blue-200 hover:bg-blue-700 hover:text-white rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {isSelected ? 'Book Visit' : 'Select & Book'}
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-center text-xs text-slate-600">
            No registered patient records matched your search yet. Register a patient on the left to generate a unique Patient ID.
          </div>
        )}
      </section>
    </div>
  );
};
