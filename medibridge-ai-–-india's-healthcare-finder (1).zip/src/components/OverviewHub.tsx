import React, { useState } from 'react';
import {
  ArrowRight,
  Bell,
  Building2,
  PhoneCall,
  Pill,
  ShieldAlert,
  ShieldCheck,
} from 'lucide-react';
import { COMMON_MEDICINE_EXAMPLES } from '../data/indianLocations';
import type { DatabaseStatus } from '../types/healthcare';

export type NavSection =
  | 'home'
  | 'hospitals'
  | 'medicines'
  | 'reminders'
  | 'sos'
  | 'patient-register'
  | 'patient-login'
  | 'patient-dashboard'
  | 'appointments'
  | 'about'
  | 'contact'
  | 'admin-import'
  | 'admin-verify';

interface OverviewHubProps {
  dbStatus: DatabaseStatus | null;
  retryingDb?: boolean;
  onRetryConnection?: () => void;
  onNavigate: (section: NavSection) => void;
  onQuickMedicine: (name: string) => void;
}

export const OverviewHub: React.FC<OverviewHubProps> = ({
  dbStatus,
  retryingDb = false,
  onRetryConnection,
  onNavigate,
  onQuickMedicine,
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  const modules: Array<{
    id: NavSection;
    title: string;
    description: string;
    icon: React.ReactNode;
    cta: string;
    accent?: 'blue' | 'red';
  }> = [
    {
      id: 'hospitals',
      title: 'India Hospital Finder',
      description:
        'Search hospitals by State, District, City & PIN code with strict separation of verified official-source entries and unverified records.',
      icon: <Building2 className="w-5 h-5 text-blue-700" />,
      cta: 'Find Hospitals',
    },
    {
      id: 'medicines',
      title: 'Medicine Details',
      description:
        'Search by medicine name, generic composition, or brand name for educational details, precautions, and verified vs unverified status.',
      icon: <Pill className="w-5 h-5 text-blue-700" />,
      cta: 'Search Medicines',
    },
    {
      id: 'reminders',
      title: 'Medicine Reminder',
      description:
        'Organize your doctor- or pharmacist-provided schedule with dates, times, completion tracking, and opt-in browser notifications.',
      icon: <Bell className="w-5 h-5 text-blue-700" />,
      cta: 'Manage Reminders',
    },
    {
      id: 'sos',
      title: 'Emergency SOS (112)',
      description:
        'Quickly access India national emergency 112 and helpline references with a confirmation step before initiating a phone call.',
      icon: <ShieldAlert className="w-5 h-5 text-red-600" />,
      cta: 'Open Emergency SOS',
      accent: 'red',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Split Clinical Hero */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-semibold text-blue-700 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>MediBridge AI · India&apos;s Clinical Healthcare Finder</span>
            </p>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight leading-tight">
              Verified Healthcare Navigation, Medicine Education &amp; Personal Reminders Across India
            </h1>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl">
              Locate hospitals by State, District, City, and PIN code with transparent separation between verified{' '}
              <span className="font-mono text-slate-800">Medi_Bridge</span> records and unverified public sources—alongside{' '}
              <span className="font-mono text-slate-800">MedicineInfo</span> details, personal medicine reminders, and Emergency SOS (112) guidance.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('hospitals')}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Find Hospitals Across India
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('sos')}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <PhoneCall className="w-4 h-4" />
              Emergency SOS (112)
            </button>
            <button
              type="button"
              onClick={() => onNavigate('reminders')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              Medicine Reminder
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 relative min-h-[220px] bg-gradient-to-br from-blue-50 via-white to-blue-100 border-t lg:border-t-0 lg:border-l border-slate-200">
          {!imgFailed ? (
            <img
              src="/src/assets/images/medibridge_clinical_hub_1795369671438.jpg"
              alt="Modern Indian multi-specialty hospital atrium in blue and white"
              referrerPolicy="no-referrer"
              onError={() => setImgFailed(true)}
              className="w-full h-full object-cover lg:absolute lg:inset-0"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center">
              <Building2 className="w-10 h-10 text-blue-700 mb-2" />
              <p className="text-sm font-semibold text-slate-800">MediBridge AI Clinical Hub</p>
              <p className="text-xs text-slate-500 mt-1">Verified Healthcare Navigation</p>
            </div>
          )}
        </div>
      </section>

      {/* Database & Registry Summary Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Database Status</p>
          <p className={`text-base font-semibold mt-1 ${dbStatus?.connected ? 'text-emerald-700' : 'text-amber-700'}`}>
            {dbStatus?.connected ? 'Medi_Bridge Connected' : 'Connection Attention Needed'}
          </p>
          <p className="text-xs text-slate-500 mt-0.5 truncate">
            {dbStatus?.connected
              ? `${dbStatus.collections.length} collections · Records preserved`
              : dbStatus?.envVarsDetected?.mongodbUriSet
              ? `Env detected (${dbStatus.envVarsDetected.mongodbDbName})`
              : 'MONGODB_URI not detected'}
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Hospitals in Medi_Bridge</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {dbStatus?.counts.hospitals ?? 0}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Verified &amp; unverified directory</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <p className="text-xs font-medium text-slate-500">Medicines in MedicineInfo</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {dbStatus?.counts.medicines ?? 0}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Educational medicine records</p>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-xl p-4">
          <p className="text-xs font-medium text-red-700">India National Emergency</p>
          <p className="text-2xl font-bold font-mono tabular-nums text-red-800 mt-1">112</p>
          <button
            type="button"
            onClick={() => onNavigate('sos')}
            className="text-xs font-semibold text-red-700 hover:underline mt-0.5 cursor-pointer"
          >
            Open Emergency SOS →
          </button>
        </div>
      </section>

      {/* Live MongoDB Diagnostics Card */}
      {dbStatus && (
        <section
          className={`rounded-xl border p-4 flex flex-col sm:flex-row sm:items-start justify-between gap-4 ${
            dbStatus.connected
              ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
              : 'bg-amber-50 border-amber-200 text-amber-950'
          }`}
        >
          <div className="space-y-1.5 text-sm">
            <div className="flex flex-wrap items-center gap-2 font-semibold">
              <span>
                {dbStatus.connected
                  ? `Connected to MongoDB Atlas (${dbStatus.databaseName})`
                  : `MongoDB Atlas Connection Status (${dbStatus.databaseName})`}
              </span>
              <span className="text-xs font-mono font-normal opacity-80">
                · URI: {dbStatus.envVarsDetected?.mongodbUriSet ? `Detected (${dbStatus.envVarsDetected.mongodbUriScheme})` : 'Missing'}
                {' · '}DB: {dbStatus.envVarsDetected?.mongodbDbName || dbStatus.databaseName}
              </span>
            </div>

            {dbStatus.connected ? (
              <p className="text-xs text-emerald-900">
                Existing collections detected: {dbStatus.collections.length > 0 ? dbStatus.collections.join(', ') : 'None yet'}. All existing records are preserved.
              </p>
            ) : (
              <>
                {dbStatus.diagnosticHint && (
                  <p className="text-xs text-amber-950 leading-relaxed">
                    {dbStatus.diagnosticHint}
                  </p>
                )}
                <p className="text-xs font-mono text-amber-900/90 break-all">
                  Driver response: {dbStatus.message}
                </p>
              </>
            )}
          </div>

          {onRetryConnection && (
            <button
              type="button"
              onClick={onRetryConnection}
              disabled={retryingDb}
              className="px-3.5 py-2 text-xs font-semibold bg-white text-slate-900 border border-slate-300 hover:bg-slate-50 disabled:opacity-50 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
            >
              {retryingDb ? 'Testing Connection...' : 'Retry Connection'}
            </button>
          )}
        </section>
      )}

      {/* Core Modules Grid */}
      <section className="space-y-3">
        <h2 className="text-base font-semibold text-slate-900">Core Healthcare Modules</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {modules.map((mod) => (
            <div
              key={mod.id}
              className={`bg-white border rounded-xl p-5 flex flex-col justify-between gap-4 transition-colors ${
                mod.accent === 'red'
                  ? 'border-red-200 hover:border-red-300'
                  : 'border-slate-200 hover:border-blue-300'
              }`}
            >
              <div className="space-y-2">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                    mod.accent === 'red' ? 'bg-red-50' : 'bg-blue-50'
                  }`}
                >
                  {mod.icon}
                </div>
                <h3 className="text-base font-semibold text-slate-900">{mod.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{mod.description}</p>
              </div>

              <button
                type="button"
                onClick={() => onNavigate(mod.id)}
                className={`inline-flex items-center gap-1.5 text-xs font-semibold cursor-pointer w-fit ${
                  mod.accent === 'red'
                    ? 'text-red-700 hover:text-red-900'
                    : 'text-blue-700 hover:text-blue-900'
                }`}
              >
                {mod.cta}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Educational Lookups */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-slate-900">Quick Medicine Lookups</h3>
          <p className="text-xs text-slate-600">
            Select a common medicine name to check verified or unverified details, precautions, and safety warnings.
          </p>
          <div className="flex flex-wrap gap-2">
            {COMMON_MEDICINE_EXAMPLES.map((med) => (
              <button
                key={med}
                type="button"
                onClick={() => onQuickMedicine(med)}
                className="px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
              >
                {med}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-semibold text-slate-900">Emergency &amp; Patient Support</h3>
          <p className="text-xs text-slate-600">
            MediBridge AI is an informational directory and personal schedule tool—it does not replace medical professionals or dispatch emergency ambulances.
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => onNavigate('sos')}
              className="px-3 py-1.5 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg transition-colors cursor-pointer"
            >
              Emergency SOS (112)
            </button>
            <button
              type="button"
              onClick={() => onNavigate('about')}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              About Us
            </button>
            <button
              type="button"
              onClick={() => onNavigate('contact')}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
