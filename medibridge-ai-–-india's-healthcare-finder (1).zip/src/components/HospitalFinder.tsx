import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Building2,
  ExternalLink,
  Globe,
  MapPin,
  Phone,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { FACILITY_TYPES, INDIAN_STATES_AND_UTS } from '../data/indianLocations';
import { apiFetchJson } from '../utils/apiClient';
import type {
  HospitalRecord,
  HospitalSearchResponse,
  WebHospitalSearchResponse,
} from '../types/healthcare';

export interface HospitalFilters {
  q: string;
  state: string;
  district: string;
  city: string;
  pinCode: string;
  facilityType: string;
  verificationFilter: 'all' | 'verified' | 'unverified';
}

interface HospitalFinderProps {
  filters: HospitalFilters;
  onFiltersChange: (next: HospitalFilters) => void;
  searchTrigger: number;
}

export const HospitalFinder: React.FC<HospitalFinderProps> = ({
  filters,
  onFiltersChange,
  searchTrigger,
}) => {
  const [data, setData] = useState<HospitalSearchResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [webData, setWebData] = useState<WebHospitalSearchResponse | null>(null);
  const [webLoading, setWebLoading] = useState<boolean>(false);
  const [webError, setWebError] = useState<string | null>(null);

  const fetchHospitals = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (filters.q.trim()) params.set('q', filters.q.trim());
      if (filters.state) params.set('state', filters.state);
      if (filters.district.trim()) params.set('district', filters.district.trim());
      if (filters.city.trim()) params.set('city', filters.city.trim());
      if (filters.pinCode.trim()) params.set('pinCode', filters.pinCode.trim());
      if (filters.facilityType) params.set('facilityType', filters.facilityType);

      const queryString = params.toString();
      const verifiedPath = queryString
        ? `/api/hospitals/verified?${queryString}`
        : '/api/hospitals/verified';
      const unverifiedPath = queryString
        ? `/api/hospitals/unverified?${queryString}`
        : '/api/hospitals/unverified';

      interface SeparateHospitalResponse {
        hospitals: HospitalRecord[];
        databaseConnected: boolean;
        databaseName: string;
        availableStates?: string[];
        availableFacilityTypes?: string[];
      }

      const [verifiedRes, unverifiedRes] = await Promise.all([
        apiFetchJson<SeparateHospitalResponse>(
          verifiedPath,
          { method: 'GET' },
          'Unable to load verified hospitals.'
        ),
        apiFetchJson<SeparateHospitalResponse>(
          unverifiedPath,
          { method: 'GET' },
          'Unable to load unverified hospitals.'
        ),
      ]);

      setData({
        verified: verifiedRes.hospitals || [],
        unverified: unverifiedRes.hospitals || [],
        databaseConnected: Boolean(verifiedRes.databaseConnected || unverifiedRes.databaseConnected),
        databaseName: verifiedRes.databaseName || unverifiedRes.databaseName || 'Medi_Bridge',
        availableStates:
          verifiedRes.availableStates || unverifiedRes.availableStates || [],
        availableFacilityTypes:
          verifiedRes.availableFacilityTypes || unverifiedRes.availableFacilityTypes || [],
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to fetch hospitals.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHospitals();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchTrigger]);

  const handlePublicWebLookup = async () => {
    setWebLoading(true);
    setWebError(null);
    try {
      const json = await apiFetchJson<WebHospitalSearchResponse>(
        '/api/hospitals/web-search',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            q: filters.q,
            state: filters.state,
            district: filters.district,
            city: filters.city,
            pinCode: filters.pinCode,
            facilityType: filters.facilityType,
          }),
        },
        'Public directory search failed.'
      );
      setWebData(json);
    } catch (err) {
      setWebError(err instanceof Error ? err.message : 'Unable to search public directory.');
    } finally {
      setWebLoading(false);
    }
  };

  const hasAnyFilter = Boolean(
    filters.q || filters.state || filters.district || filters.city || filters.pinCode || filters.facilityType
  );

  const stateOptions = Array.from(
    new Set([...INDIAN_STATES_AND_UTS, ...(data?.availableStates ?? [])])
  ).filter(Boolean);
  const facilityTypeOptions = Array.from(
    new Set([...(data?.availableFacilityTypes ?? []), ...FACILITY_TYPES])
  ).filter((t) => Boolean(t) && t !== '0');

  const verifiedList =
    filters.verificationFilter === 'unverified' ? [] : data?.verified ?? [];
  const dbUnverifiedList =
    filters.verificationFilter === 'verified' ? [] : data?.unverified ?? [];
  const webUnverifiedList =
    filters.verificationFilter === 'verified' ? [] : webData?.results ?? [];

  const renderHospitalCard = (hospital: HospitalRecord) => {
    const verificationLink = hospital.officialSourceUrl || hospital.sourceUrl;
    return (
      <article
        key={hospital.id}
        className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between gap-4 hover:border-blue-300 transition-colors"
      >
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span
                  className={`inline-flex items-center gap-1 px-2 py-0.5 font-semibold border rounded ${
                    hospital.verified
                      ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                      : 'text-amber-800 bg-amber-50 border-amber-200'
                  }`}
                >
                  {hospital.verified ? (
                    <>
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Verified
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Unverified
                    </>
                  )}
                </span>
                <span className="font-medium text-slate-600">{hospital.facilityType}</span>
              </div>
              <h3 className="text-base font-semibold text-slate-900 mt-1.5 leading-snug">
                {hospital.name}
              </h3>
            </div>
          </div>

          <div className="space-y-2 text-sm text-slate-600 pt-2 border-t border-slate-100">
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <p className="text-slate-700 leading-relaxed">{hospital.address}</p>
                <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
                  {[hospital.city, hospital.district, hospital.state].filter(Boolean).join(', ')}
                  {hospital.pinCode ? ` — PIN ${hospital.pinCode}` : ''}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-blue-600 shrink-0" />
              <span className="tabular-nums font-mono text-xs text-slate-800">
                {hospital.contactNumber}
              </span>
              {hospital.emergencyNumber && (
                <span className="text-xs text-slate-500 tabular-nums">
                  · Emergency: {hospital.emergencyNumber}
                </span>
              )}
            </div>

            {hospital.verified && hospital.officialSourceName && (
              <p className="text-xs text-emerald-800 pt-1">
                Checked against: <strong>{hospital.officialSourceName}</strong>
                {hospital.verifiedAt
                  ? ` · ${new Date(hospital.verifiedAt).toLocaleDateString()}`
                  : ''}
              </p>
            )}
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
          <span className="text-xs text-slate-500 truncate">{hospital.sourceLabel}</span>
          <div className="flex items-center gap-2 shrink-0">
            {verificationLink && (
              <a
                href={verificationLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-blue-700 hover:text-blue-900 bg-blue-50 border border-blue-200 rounded-lg transition-colors whitespace-nowrap"
              >
                Official Source
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>
      </article>
    );
  };

  return (
    <div className="space-y-6">
      {/* Location & Facility Filter Panel */}
      <section className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">India Hospital Finder</h2>
            <p className="text-sm text-slate-600">
              Search verified Medi_Bridge records by State, District, City, and 6-digit PIN code.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePublicWebLookup}
              disabled={webLoading || !hasAnyFilter}
              title={!hasAnyFilter ? 'Enter a State, District, City, PIN code, or Hospital name first' : 'Search grounded public directories'}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg border border-blue-200 transition-colors whitespace-nowrap cursor-pointer"
            >
              <Globe className="w-4 h-4" />
              {webLoading ? 'Searching Public Web...' : 'Search Public Web Directory (Unverified)'}
            </button>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchHospitals();
          }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3"
        >
          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Hospital Name or Keyword
            </label>
            <input
              type="text"
              value={filters.q}
              onChange={(e) => onFiltersChange({ ...filters, q: e.target.value })}
              placeholder="e.g., AIIMS, District Hospital, Apollo"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">State / UT</label>
            <select
              value={filters.state}
              onChange={(e) => onFiltersChange({ ...filters, state: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            >
              <option value="">All States</option>
              {stateOptions.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">District</label>
            <input
              type="text"
              value={filters.district}
              onChange={(e) => onFiltersChange({ ...filters, district: e.target.value })}
              placeholder="e.g., Ernakulam, Pune"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">City / Town</label>
            <input
              type="text"
              value={filters.city}
              onChange={(e) => onFiltersChange({ ...filters, city: e.target.value })}
              placeholder="e.g., Bengaluru, Kochi"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">PIN Code</label>
            <input
              type="text"
              inputMode="numeric"
              maxLength={6}
              value={filters.pinCode}
              onChange={(e) =>
                onFiltersChange({ ...filters, pinCode: e.target.value.replace(/\D/g, '').slice(0, 6) })
              }
              placeholder="e.g., 110029"
              className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div className="sm:col-span-2 lg:col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">Facility Type</label>
            <select
              value={filters.facilityType}
              onChange={(e) => onFiltersChange({ ...filters, facilityType: e.target.value })}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            >
              <option value="">All Facility Types</option>
              {facilityTypeOptions.map((ft) => (
                <option key={ft} value={ft}>
                  {ft}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-2 lg:col-span-2 flex items-end gap-1">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg w-full">
              {(['all', 'verified', 'unverified'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => onFiltersChange({ ...filters, verificationFilter: mode })}
                  className={`flex-1 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    filters.verificationFilter === mode
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {mode === 'all' ? 'All' : mode === 'verified' ? 'Verified' : 'Unverified'}
                </button>
              ))}
            </div>
          </div>

          <div className="sm:col-span-2 lg:col-span-2 flex items-end gap-2">
            <button
              type="submit"
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              <Search className="w-4 h-4" />
              Search Medi_Bridge
            </button>
            {hasAnyFilter && (
              <button
                type="button"
                onClick={() => {
                  const reset: HospitalFilters = {
                    q: '',
                    state: '',
                    district: '',
                    city: '',
                    pinCode: '',
                    facilityType: '',
                    verificationFilter: 'all',
                  };
                  onFiltersChange(reset);
                }}
                className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg whitespace-nowrap cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </form>
      </section>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {!loading && data && !data.databaseConnected && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-sm text-blue-950">
            <p className="font-semibold">Medi_Bridge MongoDB Atlas Not Connected Yet</p>
            <p className="text-blue-800 mt-0.5">
              To query your existing verified hospitals in <span className="font-mono">Medi_Bridge</span>, configure{' '}
              <span className="font-mono">MONGODB_URI</span> in <strong>Settings &gt; Secrets</strong>. In the meantime, enter a State, District, City, or PIN code above and click{' '}
              <strong>Search Public Web Directory (Unverified)</strong> to retrieve source-cited Indian hospitals without inventing records.
            </p>
          </div>
        </div>
      )}

      {/* Loading Skeleton */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4" aria-busy="true">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white border border-slate-200 rounded-xl p-5 space-y-3 animate-pulse">
              <div className="h-3 w-36 bg-slate-200 rounded" />
              <div className="h-5 w-64 bg-slate-200 rounded" />
              <div className="h-4 w-full bg-slate-100 rounded" />
              <div className="h-4 w-40 bg-slate-100 rounded" />
            </div>
          ))}
        </div>
      )}

      {/* SECTION 1: VERIFIED INFORMATION */}
      {!loading && filters.verificationFilter !== 'unverified' && (
        <section className="space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <h3 className="text-base font-semibold text-slate-900">
                Verified Hospital Information
              </h3>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500">
              {verifiedList.length} verified {verifiedList.length === 1 ? 'record' : 'records'}
            </span>
          </div>

          {verifiedList.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {verifiedList.map(renderHospitalCard)}
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl p-6 text-center space-y-2">
              <Building2 className="w-6 h-6 text-slate-400 mx-auto" />
              <p className="text-sm font-medium text-slate-800">
                {data?.databaseConnected
                  ? 'No verified hospitals in Medi_Bridge matched your current filters.'
                  : 'Verified hospital records will appear here once MONGODB_URI is connected.'}
              </p>
              <p className="text-xs text-slate-500 max-w-lg mx-auto">
                MediBridge AI strictly separates verified database records from unverified sources and never fabricates hospitals, phone numbers, or live availability.
              </p>
            </div>
          )}
        </section>
      )}

      {/* SECTION 2: UNVERIFIED INFORMATION (DB Unverified + Grounded Public Search) */}
      {!loading && filters.verificationFilter !== 'verified' && (
        <section className="space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              <h3 className="text-base font-semibold text-slate-900">
                Unverified Hospital Information
              </h3>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500">
              {dbUnverifiedList.length + webUnverifiedList.length} unverified{' '}
              {dbUnverifiedList.length + webUnverifiedList.length === 1 ? 'record' : 'records'}
            </span>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 text-xs text-amber-900">
            <strong>Verification Notice:</strong> Details in this section are either unverified database entries or retrieved from public web search results. Always confirm exact address, phone number, and doctor availability directly with the hospital.
          </div>

          {webError && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
              {webError}
            </div>
          )}

          {webLoading && (
            <div className="bg-white border border-slate-200 rounded-xl p-6 text-sm text-slate-600">
              Searching grounded public healthcare directories for matching hospitals...
            </div>
          )}

          {dbUnverifiedList.length + webUnverifiedList.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {dbUnverifiedList.map(renderHospitalCard)}
              {webUnverifiedList.map(renderHospitalCard)}
            </div>
          ) : (
            !webLoading && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 text-sm text-slate-600 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span>
                  No unverified records currently displayed. You can query public web directories for any Indian State, District, City, or PIN code.
                </span>
                <button
                  type="button"
                  onClick={handlePublicWebLookup}
                  disabled={!hasAnyFilter}
                  className="px-3.5 py-2 text-xs font-semibold text-blue-700 border border-blue-200 bg-blue-50 hover:bg-blue-100 disabled:opacity-50 rounded-lg whitespace-nowrap cursor-pointer"
                >
                  Run Public Web Lookup
                </button>
              </div>
            )
          )}

          {webData && webData.sources.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2">
              <p className="text-xs font-semibold text-slate-700">Public Search Grounding Sources</p>
              <ul className="flex flex-wrap gap-3">
                {webData.sources.map((src) => (
                  <li key={src.uri}>
                    <a
                      href={src.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-blue-700 hover:underline"
                    >
                      {src.title}
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      )}
    </div>
  );
};
