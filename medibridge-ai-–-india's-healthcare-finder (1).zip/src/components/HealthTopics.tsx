import React, { useEffect, useState } from 'react';
import { BookOpen, Search, ShieldCheck } from 'lucide-react';
import { COMMON_HEALTH_TOPICS } from '../data/indianLocations';
import { apiFetchJson } from '../utils/apiClient';
import type { HealthTopicResponse } from '../types/healthcare';

interface HealthTopicsProps {
  initialQuery?: string;
}

export const HealthTopics: React.FC<HealthTopicsProps> = ({ initialQuery = '' }) => {
  const [query, setQuery] = useState(initialQuery);
  const [data, setData] = useState<HealthTopicResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchTopic = async (topicName: string) => {
    const clean = topicName.trim();
    if (!clean) return;
    setLoading(true);
    setError(null);
    try {
      const json = await apiFetchJson<HealthTopicResponse>(
        '/api/health-topics/explain',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: clean }),
        },
        'Unable to load health topic.'
      );
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to fetch topic explanation.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      searchTopic(initialQuery);
    }
  }, [initialQuery]);

  return (
    <div className="space-y-6">
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">Health Topics Library</h2>
          <p className="text-sm text-slate-600">
            Search health conditions, preventive care topics, and public health guidance in plain language.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            searchTopic(query);
          }}
          className="flex flex-col sm:flex-row gap-3"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search health topics (e.g., Dengue Fever, Type 2 Diabetes, Hypertension)"
              className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>
          <button
            type="submit"
            disabled={loading || !query.trim()}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            {loading ? 'Loading Guide...' : 'Explore Topic'}
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-xs text-slate-500">Popular topics:</span>
          {COMMON_HEALTH_TOPICS.map((topic) => (
            <button
              key={topic}
              type="button"
              onClick={() => {
                setQuery(topic);
                searchTopic(topic);
              }}
              className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors cursor-pointer"
            >
              {topic}
            </button>
          ))}
        </div>
      </section>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {loading && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-5 w-52 bg-slate-200 rounded" />
          <div className="h-4 w-full bg-slate-100 rounded" />
          <div className="h-4 w-5/6 bg-slate-100 rounded" />
          <div className="h-24 w-full bg-slate-100 rounded" />
        </div>
      )}

      {!loading && data && (
        <div className="space-y-6">
          {data.curatedRecords.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-semibold text-slate-900">Medi_Bridge Curated Topics</h3>
              </div>
              <div className="grid grid-cols-1 gap-4">
                {data.curatedRecords.map((item) => (
                  <div key={item.id} className="bg-white border border-emerald-200 rounded-xl p-5 space-y-2">
                    <p className="text-xs font-semibold text-emerald-700">{item.category}</p>
                    <h4 className="text-base font-semibold text-slate-900">{item.title}</h4>
                    <p className="text-sm text-slate-700 leading-relaxed">{item.summary}</p>
                    {item.verifiedBy && (
                      <p className="text-xs text-slate-500">Reviewed by {item.verifiedBy}</p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}

          {data.educationalGuide && (
            <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
              <div className="border-b border-slate-100 pb-4">
                <p className="text-xs font-semibold text-blue-700">
                  Educational Health Guide · {data.educationalGuide.category}
                </p>
                <h3 className="text-xl font-semibold text-slate-900 mt-1">
                  {data.educationalGuide.topic}
                </h3>
                <p className="text-sm text-slate-700 leading-relaxed mt-2">
                  {data.educationalGuide.overview}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-slate-900">Common Causes &amp; Risk Factors</h4>
                  <ul className="list-disc list-inside text-sm text-slate-700 space-y-1.5">
                    {data.educationalGuide.commonCausesAndRiskFactors.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-slate-900">Common Symptoms</h4>
                  <ul className="list-disc list-inside text-sm text-slate-700 space-y-1.5">
                    {data.educationalGuide.commonSymptoms.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-slate-900">Preventive &amp; General Care</h4>
                  <ul className="list-disc list-inside text-sm text-slate-700 space-y-1.5">
                    {data.educationalGuide.preventiveAndSelfCareGuidance.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2 bg-blue-50 border border-blue-200 rounded-xl p-4">
                  <h4 className="text-sm font-semibold text-blue-950">When to Consult a Doctor</h4>
                  <ul className="list-disc list-inside text-sm text-blue-900 space-y-1.5">
                    {data.educationalGuide.whenToConsultDoctor.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <p className="text-xs text-slate-500 pt-2 border-t border-slate-100">
                {data.educationalGuide.disclaimer}
              </p>
            </section>
          )}
        </div>
      )}

      {!loading && !data && !error && (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-2">
          <BookOpen className="w-7 h-7 text-blue-600 mx-auto" />
          <p className="text-sm font-semibold text-slate-900">Explore reliable health education</p>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Select a topic above or enter any health condition to read clear educational summaries, risk factors, and guidance on when to seek medical care.
          </p>
        </div>
      )}
    </div>
  );
};
