import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  HeartPulse,
  Phone,
  PhoneCall,
  Plus,
  ShieldAlert,
  Trash2,
  UserCheck,
  X,
} from 'lucide-react';
import { apiFetchJson } from '../utils/apiClient';
import type {
  AuthenticatedUser,
  EmergencyContactRecord,
  PatientAccountProfile,
} from '../types/healthcare';

interface EmergencySOSProps {
  userToken: string | null;
  activeUser: AuthenticatedUser | null;
  activePatient?: PatientAccountProfile | null;
  onGoToHospitalFinder: () => void;
  onGoToSignIn: () => void;
}

interface PendingCallTarget {
  label: string;
  phone: string;
  isNationalEmergency?: boolean;
}

function sanitizeTelUri(phone: string): string {
  const cleaned = phone.replace(/[^+\d]/g, '');
  return `tel:${cleaned}`;
}

export const EmergencySOS: React.FC<EmergencySOSProps> = ({
  userToken,
  activeUser,
  activePatient = null,
  onGoToHospitalFinder,
  onGoToSignIn,
}) => {
  const [contacts, setContacts] = useState<EmergencyContactRecord[]>([]);
  const [loadingContacts, setLoadingContacts] = useState(false);
  const [contactError, setContactError] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [relationship, setRelationship] = useState('');
  const [phone, setPhone] = useState('');
  const [savingContact, setSavingContact] = useState(false);

  const [pendingCall, setPendingCall] = useState<PendingCallTarget | null>(null);
  const [callConfirmed, setCallConfirmed] = useState(false);

  const isAuthenticated = Boolean(userToken || activePatient);

  useEffect(() => {
    const loadContacts = async () => {
      if (!isAuthenticated) {
        setContacts([]);
        return;
      }
      setLoadingContacts(true);
      try {
        const headers: Record<string, string> = {};
        if (userToken) headers.Authorization = `Bearer ${userToken}`;
        const json = await apiFetchJson<{ contacts?: EmergencyContactRecord[] }>(
          '/api/sos-contacts',
          { headers },
          'Unable to load emergency contacts.'
        );
        if (Array.isArray(json.contacts)) {
          setContacts(json.contacts);
        }
      } catch (err) {
        setContactError(err instanceof Error ? err.message : 'Unable to load emergency contacts.');
      } finally {
        setLoadingContacts(false);
      }
    };
    loadContacts();
  }, [userToken, activePatient?.patientId, isAuthenticated]);

  const handleAddContact = async (e: React.FormEvent) => {
    e.preventDefault();
    setContactError(null);
    const cleanPhone = phone.trim();
    if (name.trim().length < 2) {
      setContactError('Contact name must be at least 2 characters.');
      return;
    }
    if (!/^[+\d\s()-]{3,20}$/.test(cleanPhone)) {
      setContactError('Enter a valid phone number.');
      return;
    }

    if (isAuthenticated) {
      setSavingContact(true);
      try {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (userToken) headers.Authorization = `Bearer ${userToken}`;
        const json = await apiFetchJson<{ contact: EmergencyContactRecord }>(
          '/api/sos-contacts',
          {
            method: 'POST',
            headers,
            body: JSON.stringify({
              name: name.trim(),
              relationship: relationship.trim() || 'Family / Emergency Contact',
              phone: cleanPhone,
            }),
          },
          'Unable to save contact.'
        );
        setContacts((prev) => [json.contact, ...prev]);
        setName('');
        setRelationship('');
        setPhone('');
      } catch (err) {
        setContactError(err instanceof Error ? err.message : 'Unable to save contact.');
      } finally {
        setSavingContact(false);
      }
      return;
    }

    // Immediate session-only storage if user is not signed in (never blocks SOS)
    const sessionContact: EmergencyContactRecord = {
      id: `LOCAL-${Date.now()}`,
      name: name.trim(),
      relationship: relationship.trim() || 'Family / Emergency Contact',
      phone: cleanPhone,
      createdAt: new Date().toISOString(),
      storageMode: 'session',
    };
    setContacts((prev) => [sessionContact, ...prev]);
    setName('');
    setRelationship('');
    setPhone('');
  };

  const handleRemoveContact = async (id: string) => {
    if (isAuthenticated && !id.startsWith('LOCAL-')) {
      try {
        const headers: Record<string, string> = {};
        if (userToken) headers.Authorization = `Bearer ${userToken}`;
        await apiFetchJson<{ deleted: boolean }>(
          `/api/sos-contacts/${encodeURIComponent(id)}`,
          {
            method: 'DELETE',
            headers,
          },
          'Unable to delete emergency contact.'
        );
      } catch (err) {
        setContactError(err instanceof Error ? err.message : 'Unable to delete emergency contact.');
        return;
      }
    }
    setContacts((prev) => prev.filter((c) => c.id !== id));
  };

  const openCallConfirmation = (target: PendingCallTarget) => {
    setCallConfirmed(false);
    setPendingCall(target);
  };

  return (
    <div className="space-y-6">
      {/* Critical Non-Dispatch Disclaimer */}
      <section className="bg-red-50 border-2 border-red-300 rounded-xl p-5 flex items-start gap-3">
        <ShieldAlert className="w-6 h-6 text-red-700 shrink-0 mt-0.5" />
        <div className="space-y-1 text-sm text-red-950">
          <h2 className="text-base font-bold text-red-900">
            MediBridge AI is NOT an Emergency Response Service
          </h2>
          <p className="text-red-900 leading-relaxed">
            This platform does <strong>not</strong> dispatch ambulances, police, or medical responders and cannot track your emergency automatically. In any life-threatening situation, dial <strong>112</strong> directly from your phone or visit the nearest hospital emergency department immediately.
          </p>
        </div>
      </section>

      {/* Primary Call 112 Hero Card */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div className="lg:col-span-7 space-y-3">
          <p className="text-xs font-semibold text-red-700 uppercase tracking-wide">
            India National Emergency Helpline
          </p>
          <div className="flex items-baseline gap-3">
            <span className="text-5xl font-bold font-mono tabular-nums text-red-700">112</span>
            <span className="text-sm text-slate-600">
              All-in-One Emergency Number (Police · Fire · Ambulance)
            </span>
          </div>
          <p className="text-sm text-slate-700 leading-relaxed">
            Use the button below to confirm and open your device&apos;s phone dialer for <strong>112</strong>. MediBridge AI never places calls automatically without your confirmation.
          </p>
          <div className="flex flex-wrap gap-3 pt-1 text-xs font-mono tabular-nums text-slate-700">
            <span className="px-2.5 py-1 bg-slate-100 rounded border border-slate-200">
              Ambulance: 108 / 102
            </span>
            <span className="px-2.5 py-1 bg-slate-100 rounded border border-slate-200">
              Health Helpline: 104
            </span>
            <span className="px-2.5 py-1 bg-slate-100 rounded border border-slate-200">
              Women Helpline: 1091 / 181
            </span>
          </div>
        </div>

        <div className="lg:col-span-5 flex flex-col gap-3">
          <button
            type="button"
            onClick={() =>
              openCallConfirmation({
                label: 'India National Emergency Helpline (112)',
                phone: '112',
                isNationalEmergency: true,
              })
            }
            className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-4 text-base font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl transition-colors cursor-pointer"
          >
            <PhoneCall className="w-5 h-5" />
            Call 112 Emergency
          </button>

          <button
            type="button"
            onClick={onGoToHospitalFinder}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-xl transition-colors cursor-pointer"
          >
            Find Nearby Hospitals in India
          </button>
        </div>
      </section>

      {/* Emergency Guidance + Personal Emergency Contacts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Guidance Screen */}
        <section className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <HeartPulse className="w-5 h-5 text-blue-700" />
            <h3 className="text-base font-semibold text-slate-900">Emergency Guidance Checklist</h3>
          </div>

          <ol className="space-y-3 text-sm text-slate-700 list-decimal list-inside">
            <li>
              <strong>Ensure immediate safety first:</strong> Check that the area around you and the patient is safe from traffic, fire, or electrical hazards.
            </li>
            <li>
              <strong>Dial 112 or 108 directly:</strong> Speak calmly, state your exact street address, PIN code, and nearest landmark, and stay on the line until the dispatcher confirms.
            </li>
            <li>
              <strong>Check responsiveness &amp; breathing:</strong> Gently tap the person and ask loudly if they are okay. If breathing normally but unconscious, place them carefully on their side unless a neck or spine injury is suspected.
            </li>
            <li>
              <strong>Do not give food or water</strong> to anyone who is unconscious, drowsy, having seizures, or experiencing chest pain.
            </li>
            <li>
              <strong>Prepare medical details:</strong> Keep the patient&apos;s current medications, known allergies, and approximate age ready for responders.
            </li>
          </ol>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3.5 text-xs text-blue-950">
            This guidance is general first-aid awareness only and does not replace directions given by an emergency medical dispatcher or attending physician.
          </div>
        </section>

        {/* Optional Personal Emergency Contacts */}
        <section className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-blue-700" />
              <h3 className="text-base font-semibold text-slate-900">
                Optional Personal Emergency Contacts
              </h3>
            </div>
            {!isAuthenticated && (
              <button
                type="button"
                onClick={onGoToSignIn}
                className="text-xs font-semibold text-blue-700 hover:underline cursor-pointer"
              >
                Patient Login to save
              </button>
            )}
          </div>

          <p className="text-xs text-slate-600">
            {activePatient
              ? `Contacts saved here are securely linked to Patient ID ${activePatient.patientId}.`
              : activeUser
              ? `Contacts saved here are securely associated with ${activeUser.email}.`
              : 'Add temporary contacts for quick access during this session, or log in with your Patient ID to persist contacts to your account.'}
          </p>

          {contactError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-xs text-red-800">
              {contactError}
            </div>
          )}

          <form onSubmit={handleAddContact} className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Contact Name"
              className="px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
            <input
              type="text"
              value={relationship}
              onChange={(e) => setRelationship(e.target.value)}
              placeholder="Relation (e.g., Spouse)"
              className="px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
            <div className="flex gap-2">
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Phone number"
                className="flex-1 min-w-0 px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
              <button
                type="submit"
                disabled={savingContact}
                className="inline-flex items-center gap-1 px-3 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add
              </button>
            </div>
          </form>

          {loadingContacts ? (
            <div className="h-16 bg-slate-100 rounded-lg animate-pulse" />
          ) : contacts.length > 0 ? (
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
              {contacts.map((c) => (
                <div
                  key={c.id}
                  className="p-3.5 flex flex-wrap items-center justify-between gap-3 bg-white"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900">
                      {c.name}{' '}
                      <span className="text-xs font-normal text-slate-500">
                        · {c.relationship}
                      </span>
                    </p>
                    <p className="text-xs font-mono tabular-nums text-slate-600">{c.phone}</p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() =>
                        openCallConfirmation({
                          label: `${c.name} (${c.relationship})`,
                          phone: c.phone,
                        })
                      }
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg cursor-pointer"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      Call
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveContact(c.id)}
                      aria-label={`Remove ${c.name}`}
                      className="p-1.5 text-slate-500 hover:text-red-700 border border-slate-200 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-center text-xs text-slate-600">
              No personal emergency contacts added yet.
            </div>
          )}
        </section>
      </div>

      {/* Confirmation Modal Before Initiating Any Call */}
      {pendingCall && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="sos-confirm-title"
        >
          <div className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2 text-red-700">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <h3 id="sos-confirm-title" className="text-base font-bold text-slate-900">
                  Confirm Before Placing Call
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setPendingCall(null)}
                aria-label="Close confirmation"
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-sm text-slate-700">
              <p>
                You are about to open your phone dialer to call:
              </p>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <p className="font-semibold text-slate-900">{pendingCall.label}</p>
                <p className="font-mono tabular-nums text-base font-bold text-red-700 mt-0.5">
                  {pendingCall.phone}
                </p>
              </div>
              {pendingCall.isNationalEmergency && (
                <p className="text-xs text-slate-600">
                  MediBridge AI does not dispatch emergency vehicles. Confirm below to launch your device dialer to 112, or dial 112 manually on your phone.
                </p>
              )}
            </div>

            {!callConfirmed ? (
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPendingCall(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => setCallConfirmed(true)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg cursor-pointer"
                >
                  Yes, Proceed to Call
                </button>
              </div>
            ) : (
              <div className="space-y-3 pt-2 border-t border-slate-100">
                <a
                  href={sanitizeTelUri(pendingCall.phone)}
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg"
                >
                  <PhoneCall className="w-4 h-4" />
                  Open Phone Dialer ({pendingCall.phone})
                </a>
                <p className="text-xs text-slate-500 text-center">
                  If a phone dialer is unavailable on this device, dial <strong>{pendingCall.phone}</strong> directly on your mobile phone.
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
