import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  FileText,
  Lock,
  Search,
  ShieldCheck,
  Upload,
  X,
} from 'lucide-react';
import { COMMON_LAB_TESTS } from '../data/indianLocations';
import type { HealthReportEducationResponse } from '../types/healthcare';

interface HealthReportEducationProps {
  initialTest?: string;
}

const MAX_REPORT_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB
const ALLOWED_EXTENSIONS = ['.pdf', '.jpg', '.jpeg', '.png'];
const ALLOWED_MIME_TYPES = new Set([
  'application/pdf',
  'image/jpeg',
  'image/jpg',
  'image/png',
]);

export async function parseHealthReportApiResponse<T>(
  res: Response
): Promise<T & { error?: string }> {
  const contentType = (res.headers.get('content-type') || '').toLowerCase();
  const rawText = await res.text();
  const looksLikeHtml =
    contentType.includes('text/html') ||
    /^\s*(?:<!doctype\s+html|<html[\s>])/i.test(rawText);
  const isCookieCheckRedirect =
    (res.redirected && res.url.includes('__cookie_check')) ||
    rawText.includes('__cookie_check') ||
    rawText.includes('_aistudio-iframe.js');

  if (contentType.includes('application/json') || contentType.includes('+json')) {
    if (!rawText.trim()) {
      throw new Error(`Server returned an empty JSON response (HTTP ${res.status}).`);
    }
    try {
      return JSON.parse(rawText) as T & { error?: string };
    } catch {
      throw new Error(
        `Server returned malformed JSON (HTTP ${res.status}). Please try again.`
      );
    }
  }

  if (isCookieCheckRedirect) {
    throw new Error(
      `Preview session verification intercepted the API request (HTTP ${res.status} HTML redirect). Please refresh the page or open the app in a new tab with cookies enabled, then try again.`
    );
  }

  if (looksLikeHtml) {
    throw new Error(
      `The server returned an HTML page instead of JSON (HTTP ${res.status}, Content-Type: ${contentType || 'text/html'}). Please refresh the page and try again.`
    );
  }

  if (!rawText.trim()) {
    throw new Error(`Server returned an empty response (HTTP ${res.status}).`);
  }

  if (contentType.startsWith('text/')) {
    const preview = rawText.trim().slice(0, 160);
    throw new Error(
      `Server returned ${contentType.split(';')[0]} instead of JSON (HTTP ${res.status}): ${preview}`
    );
  }

  // Fallback only if Content-Type header was stripped by an intermediary but payload is valid JSON
  const trimmed = rawText.trim();
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    try {
      return JSON.parse(trimmed) as T & { error?: string };
    } catch {
      // Fall through to structured non-JSON error below
    }
  }

  throw new Error(
    `Unexpected non-JSON response from server (HTTP ${res.status}, Content-Type: ${contentType || 'missing'}). Please try again.`
  );
}

export const HealthReportEducation: React.FC<HealthReportEducationProps> = ({
  initialTest = '',
}) => {
  const [mode, setMode] = useState<'search' | 'upload'>('search');
  const [testName, setTestName] = useState(initialTest);
  const [question, setQuestion] = useState('');

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [docQuestion, setDocQuestion] = useState('');
  const [consentChecked, setConsentChecked] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [data, setData] = useState<HealthReportEducationResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const educateTest = async (name: string, extraQ = question) => {
    const clean = name.trim();
    if (!clean) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/health-reports/educate', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({ testName: clean, question: extraQ.trim() || undefined }),
      });
      const json = await parseHealthReportApiResponse<HealthReportEducationResponse>(res);
      if (!res.ok) throw new Error(json.error || 'Unable to load test educational guide.');
      if (!json.educationalExplanation) {
        throw new Error(json.error || 'Invalid response payload from Health Report Education API.');
      }
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to explain medical test.');
    } finally {
      setLoading(false);
    }
  };

  const validateReportFile = (file: File): string | null => {
    const lowerName = file.name.toLowerCase();
    const hasAllowedExt = ALLOWED_EXTENSIONS.some((ext) => lowerName.endsWith(ext));
    const mime = (file.type || '').toLowerCase();
    const hasValidMime = !mime || ALLOWED_MIME_TYPES.has(mime);

    if (!hasAllowedExt || !hasValidMime) {
      return 'Unsupported file format. Please upload a PDF, JPG, JPEG, or PNG medical report.';
    }
    if (file.size === 0) {
      return 'The selected file is empty. Please choose a valid PDF, JPG, JPEG, or PNG report.';
    }
    if (file.size > MAX_REPORT_SIZE_BYTES) {
      return 'File exceeds the 10 MB limit. Please upload a smaller PDF or image file.';
    }
    return null;
  };

  const handleFileSelected = (file: File | null) => {
    setError(null);
    if (!file) {
      setSelectedFile(null);
      return;
    }
    const validationErr = validateReportFile(file);
    if (validationErr) {
      setSelectedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setError(validationErr);
      return;
    }
    setSelectedFile(file);
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedFile) {
      setError('Please select a PDF, JPG, JPEG, or PNG medical report file first.');
      return;
    }
    const validationErr = validateReportFile(selectedFile);
    if (validationErr) {
      setError(validationErr);
      return;
    }
    if (!consentChecked) {
      setError('Please confirm consent for temporary in-memory document processing before continuing.');
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('report', selectedFile);
      formData.append('consent', 'true');
      if (docQuestion.trim()) {
        formData.append('question', docQuestion.trim());
      }

      // Note: Browser sets multipart/form-data boundary automatically; do not set Content-Type manually.
      const res = await fetch('/api/health-reports/educate-document', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          Accept: 'application/json',
        },
        body: formData,
      });
      const json = await parseHealthReportApiResponse<HealthReportEducationResponse>(res);
      if (!res.ok) {
        throw new Error(json.error || 'Unable to process uploaded medical report.');
      }
      if (!json.educationalExplanation) {
        throw new Error(json.error || 'Invalid response payload from Health Report Education API.');
      }
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to process medical report.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialTest) {
      setMode('search');
      setTestName(initialTest);
      educateTest(initialTest, '');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialTest]);

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="space-y-6">
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">Health Report Education</h2>
            <p className="text-sm text-slate-600">
              Search common test names or upload a PDF/image medical report to learn what listed tests measure.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start sm:self-auto">
            <button
              type="button"
              onClick={() => {
                setMode('search');
                setError(null);
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                mode === 'search'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Search Test Name
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('upload');
                setError(null);
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                mode === 'upload'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Upload Report (PDF / Image)
            </button>
          </div>
        </div>

        {mode === 'search' ? (
          <>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                educateTest(testName, question);
              }}
              className="grid grid-cols-1 md:grid-cols-12 gap-3"
            >
              <div className="md:col-span-5">
                <label className="block text-xs font-medium text-slate-700 mb-1">Medical Test Name</label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={testName}
                    onChange={(e) => setTestName(e.target.value)}
                    placeholder="e.g., CBC, HbA1c, Lipid Profile, LFT, TSH"
                    className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                  />
                </div>
              </div>

              <div className="md:col-span-5">
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  General Question (Optional)
                </label>
                <input
                  type="text"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="e.g., Why is fasting needed before this test?"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
                />
              </div>

              <div className="md:col-span-2 flex items-end">
                <button
                  type="submit"
                  disabled={loading || !testName.trim()}
                  className="w-full px-4 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  {loading ? 'Explaining...' : 'Explain Test'}
                </button>
              </div>
            </form>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-xs text-slate-500">Common lab tests:</span>
              {COMMON_LAB_TESTS.map((test) => (
                <button
                  key={test}
                  type="button"
                  onClick={() => {
                    setTestName(test);
                    educateTest(test, question);
                  }}
                  className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors cursor-pointer"
                >
                  {test}
                </button>
              ))}
            </div>
          </>
        ) : (
          <form onSubmit={handleUploadSubmit} className="space-y-4">
            <label className="block border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-6 text-center bg-slate-50 hover:bg-blue-50/40 transition-colors cursor-pointer">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png"
                className="sr-only"
                onChange={(e) => handleFileSelected(e.target.files?.[0] || null)}
              />
              <Upload className="w-7 h-7 text-blue-700 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-900">
                {selectedFile ? 'Choose a different medical report' : 'Click to upload your medical report'}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Supported formats: PDF, JPG, JPEG, PNG · Maximum size: 10 MB
              </p>
            </label>

            {selectedFile && (
              <div className="flex items-center justify-between gap-3 bg-blue-50 border border-blue-200 rounded-lg px-4 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <FileText className="w-4 h-4 text-blue-700 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-900 truncate">{selectedFile.name}</p>
                    <p className="text-xs text-slate-600 font-mono tabular-nums">
                      {formatFileSize(selectedFile.size)} · {selectedFile.type || 'Verified extension'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                  aria-label="Remove selected file"
                  className="p-1 text-slate-500 hover:text-slate-900 rounded cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                General Educational Question (Optional)
              </label>
              <input
                type="text"
                value={docQuestion}
                onChange={(e) => setDocQuestion(e.target.value)}
                placeholder="e.g., What is the general purpose of the tests listed on this page?"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>

            <label className="flex items-start gap-2.5 p-3.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer">
              <input
                type="checkbox"
                checked={consentChecked}
                onChange={(e) => setConsentChecked(e.target.checked)}
                className="mt-0.5 w-4 h-4 accent-blue-700"
              />
              <span className="text-xs text-slate-700 leading-relaxed">
                <strong className="text-slate-900">Privacy &amp; Consent:</strong> I consent to temporary in-memory analysis of this medical report strictly to explain listed test terminology. The uploaded file is never saved to the database, stored on disk, or shared publicly.
              </span>
            </label>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="inline-flex items-center gap-1.5 text-xs text-slate-500">
                <Lock className="w-3.5 h-3.5 text-blue-700" />
                Processed in memory only · Not stored in Medi_Bridge
              </span>
              <button
                type="submit"
                disabled={loading || !selectedFile || !consentChecked}
                className="inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                {loading ? 'Analyzing Report Terms...' : 'Explain Tests in Report'}
              </button>
            </div>
          </form>
        )}
      </section>

      {/* Strict Non-Diagnostic Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
        <div className="text-sm text-blue-950">
          <p className="font-semibold">Educational Information Only — Does Not Diagnose Diseases</p>
          <p className="text-blue-900 mt-0.5">
            This module explains test names and laboratory terminology so you can have informed conversations with your doctor. Only a qualified physician can interpret your actual report values in the context of your medical history.
          </p>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {loading && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-5 w-56 bg-slate-200 rounded" />
          <div className="h-4 w-full bg-slate-100 rounded" />
          <div className="h-32 w-full bg-slate-100 rounded" />
        </div>
      )}

      {!loading && data && data.educationalExplanation && (
        <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
          {data.sourceType === 'document' && data.uploadedFileName && (
            <div className="flex items-center gap-2 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg px-3.5 py-2">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>
                Educational summary generated from temporary in-memory document <strong>{data.uploadedFileName}</strong>. Your file was discarded immediately and not stored.
              </span>
            </div>
          )}

          <div className="border-b border-slate-100 pb-4">
            <p className="text-xs font-semibold text-blue-700">
              {data.educationalExplanation.category}
              {data.educationalExplanation.commonAliases.length > 0 &&
                ` · Also known as: ${data.educationalExplanation.commonAliases.join(', ')}`}
            </p>
            <h3 className="text-xl font-semibold text-slate-900 mt-1">
              {data.educationalExplanation.testName}
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <h4 className="text-sm font-semibold text-slate-900">What This Test Measures</h4>
              <p className="text-sm text-slate-700 leading-relaxed">
                {data.educationalExplanation.whatItMeasures}
              </p>
            </div>
            <div className="space-y-1.5">
              <h4 className="text-sm font-semibold text-slate-900">General Clinical Purpose</h4>
              <p className="text-sm text-slate-700 leading-relaxed">
                {data.educationalExplanation.generalPurpose}
              </p>
            </div>
          </div>

          {data.educationalExplanation.commonParameters.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-slate-900">Common Parameters Explained</h4>
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left border-collapse text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-4 text-xs font-semibold text-slate-700 w-1/3">
                        Parameter
                      </th>
                      <th className="py-2.5 px-4 text-xs font-semibold text-slate-700">
                        General Role in the Body
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {data.educationalExplanation.commonParameters.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2.5 px-4 font-medium text-slate-900 align-top">
                          {row.parameter}
                        </td>
                        <td className="py-2.5 px-4 text-slate-700">{row.roleInBody}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-slate-900">General Preparation Notes</h4>
              <ul className="list-disc list-inside text-sm text-slate-700 space-y-1.5">
                {data.educationalExplanation.generalPreparationNotes.map((note, idx) => (
                  <li key={idx}>{note}</li>
                ))}
              </ul>
            </div>

            <div className="space-y-2 bg-slate-50 border border-slate-200 rounded-xl p-4">
              <h4 className="text-sm font-semibold text-slate-900">Questions to Ask Your Doctor</h4>
              <ul className="list-disc list-inside text-sm text-slate-700 space-y-1.5">
                {data.educationalExplanation.questionsForDoctor.map((q, idx) => (
                  <li key={idx}>{q}</li>
                ))}
              </ul>
            </div>
          </div>

          <p className="text-xs text-slate-500 pt-2 border-t border-slate-100">
            {data.educationalExplanation.nonDiagnosticNotice}
          </p>
        </section>
      )}

      {!loading && !data && !error && (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-2">
          <FileText className="w-7 h-7 text-blue-600 mx-auto" />
          <p className="text-sm font-semibold text-slate-900">Understand your lab test names</p>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Select a common diagnostic panel, enter a test name, or switch to Upload Report to analyze a PDF, JPG, JPEG, or PNG lab report without storing it.
          </p>
        </div>
      )}
    </div>
  );
};
