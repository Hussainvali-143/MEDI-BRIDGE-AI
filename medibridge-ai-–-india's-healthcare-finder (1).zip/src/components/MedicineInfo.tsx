import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Pill,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { COMMON_MEDICINE_EXAMPLES } from '../data/indianLocations';
import { apiFetchJson } from '../utils/apiClient';
import type { MedicineDatabaseRecord, MedicineLookupResponse } from '../types/healthcare';

interface MedicineInfoProps {
  initialQuery?: string;
}

export const MedicineInfo: React.FC<MedicineInfoProps> = ({ initialQuery = '' }) => {
  const [query, setQuery] = useState(initialQuery);
  const [data, setData] = useState<MedicineLookupResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchMedicine = async (term: string) => {
    const clean = term.trim();
    if (!clean) {
      setError('Please enter a medicine name, generic composition, or brand to search.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const json = await apiFetchJson<MedicineLookupResponse>(
        '/api/medicines/lookup',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: clean }),
        },
        'Unable to look up medicine.'
      );
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to retrieve medicine details.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      searchMedicine(initialQuery);
    }
  }, [initialQuery]);

  const renderMedicineCard = (med: MedicineDatabaseRecord) => (
    <article
      key={med.id}
      className={`bg-white border rounded-xl p-5 space-y-3 ${
        med.verified ? 'border-emerald-200' : 'border-amber-200'
      }`}
    >
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 font-semibold border rounded ${
                med.verified
                  ? 'text-emerald-800 bg-emerald-50 border-emerald-200'
                  : 'text-amber-800 bg-amber-50 border-amber-200'
              }`}
            >
              {med.verified ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Verified
                </>
              ) : (
                <>
                  <AlertTriangle className="w-3.5 h-3.5" />
                  Unverified
                </>
              )}
            </span>
            {med.matchType === 'exact' && (
              <span className="inline-flex items-center px-2 py-0.5 font-semibold text-blue-800 bg-blue-50 border border-blue-200 rounded">
                Exact Match
              </span>
            )}
            {med.matchType === 'related' && (
              <span className="inline-flex items-center px-2 py-0.5 font-semibold text-slate-700 bg-slate-100 border border-slate-300 rounded">
                Related Record
              </span>
            )}
            <span className="font-medium text-slate-600">
              {med.medicineCategory || med.drugClass}
            </span>
          </div>

          <h4 className="text-lg font-semibold text-slate-900 mt-1.5">{med.name}</h4>

          <div className="text-xs text-slate-600 mt-1 space-y-1">
            {(med.genericName || med.activeIngredients) && (
              <p>
                Generic / Active Composition:{' '}
                <span className="font-medium text-slate-800">
                  {med.activeIngredients || med.genericName}
                </span>
              </p>
            )}
            <div className="flex flex-wrap gap-x-4 gap-y-0.5">
              {med.strength && (
                <p>
                  Strength: <span className="font-medium text-slate-800">{med.strength}</span>
                </p>
              )}
              {(med.formulation || med.dosageForms) && (
                <p>
                  Formulation:{' '}
                  <span className="font-medium text-slate-800">
                    {med.formulation || med.dosageForms}
                  </span>
                </p>
              )}
              {med.packSize && (
                <p>
                  Pack Size: <span className="font-medium text-slate-800">{med.packSize}</span>
                </p>
              )}
            </div>
            {med.manufacturer && (
              <p>
                Manufacturer: <span className="font-medium text-slate-800">{med.manufacturer}</span>
              </p>
            )}
            {med.brandNames.length > 0 && (
              <p>
                Brand Name(s):{' '}
                <span className="font-medium text-slate-800">{med.brandNames.join(', ')}</span>
              </p>
            )}
            {med.verified && med.prescriptionClassification && (
              <p>
                Prescription Classification:{' '}
                <span className="font-medium text-emerald-800">
                  {med.prescriptionClassification}
                </span>
              </p>
            )}
            {med.matchNote && (
              <p className="text-amber-800 bg-amber-50/70 border border-amber-200 rounded px-2 py-1 mt-1">
                {med.matchNote}
              </p>
            )}
          </div>
        </div>

        <div className="text-right text-xs text-slate-500 space-y-0.5">
          <p>{med.officialSourceName || med.sourceLabel}</p>
          {med.sourceUrl && (
            <p>
              <a
                href={med.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-700 hover:underline"
              >
                Source Reference
              </a>
            </p>
          )}
          {med.lastCheckedDate && (
            <p className="text-slate-400">Checked: {med.lastCheckedDate}</p>
          )}
          {med.verified && med.verifiedBy && (
            <p className="text-emerald-700 mt-0.5">
              Reviewed by {med.verifiedBy}
              {med.verifiedDate ? ` · ${med.verifiedDate}` : ''}
            </p>
          )}
        </div>
      </div>

      {med.pharmacistNotes && (
        <p className="text-sm text-slate-700 leading-relaxed">{med.pharmacistNotes}</p>
      )}

      {med.commonUses.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-slate-800 mb-1">General Educational Uses</p>
          <ul className="list-disc list-inside text-sm text-slate-700 space-y-1">
            {med.commonUses.map((u, idx) => (
              <li key={idx}>{u}</li>
            ))}
          </ul>
        </div>
      )}

      {med.warnings.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <p className="text-xs font-semibold text-red-800 mb-1">Precautions &amp; Safety Warnings</p>
          <ul className="list-disc list-inside text-xs text-red-900 space-y-1">
            {med.warnings.map((w, idx) => (
              <li key={idx}>{w}</li>
            ))}
          </ul>
        </div>
      )}
    </article>
  );

  return (
    <div className="space-y-6">
      <section className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">Medicine Details</h2>
          <p className="text-sm text-slate-600">
            Search by medicine name, generic composition, or brand name to review{' '}
            <span className="font-mono text-slate-800">MedicineInfo</span> records and educational safety warnings.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            searchMedicine(query);
          }}
          className="flex flex-col sm:flex-row gap-3"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search generic, brand, strength, or manufacturer (e.g., Paracetamol 500mg, Dolo 650, Cipla)"
              className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>
          <button
            type="submit"
            disabled={loading || !query.trim()}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {loading ? 'Searching...' : 'Look Up Medicine'}
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-xs text-slate-500">Quick examples:</span>
          {COMMON_MEDICINE_EXAMPLES.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => {
                setQuery(item);
                searchMedicine(item);
              }}
              className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors cursor-pointer"
            >
              {item}
            </button>
          ))}
        </div>
      </section>

      {/* Mandatory Medical Advice & Non-Prescriptive Warning */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
        <div className="text-sm text-amber-950">
          <p className="font-semibold">Consult a Qualified Healthcare Professional Before Taking Any Medicine</p>
          <p className="text-amber-900 mt-0.5">
            MediBridge AI provides educational medicine information only. It does not recommend medicines, prescribe treatments, or generate dosages. Always consult a licensed physician or registered pharmacist before starting, changing, or stopping any medication.
          </p>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {loading && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-5 w-48 bg-slate-200 rounded" />
          <div className="h-4 w-full bg-slate-100 rounded" />
          <div className="h-4 w-3/4 bg-slate-100 rounded" />
          <div className="h-24 w-full bg-slate-100 rounded" />
        </div>
      )}

      {!loading && data && (
        <div className="space-y-6">
          {data.searchSummary && (
            <div
              className={`rounded-xl border p-3.5 text-sm ${
                data.exactMatchesCount === 0 && (data.relatedMatchesCount ?? 0) > 0
                  ? 'bg-amber-50 border-amber-200 text-amber-950'
                  : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              {data.searchSummary}
            </div>
          )}

          {/* SECTION 1: VERIFIED MEDICINE RECORDS */}
          <section className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-semibold text-slate-900">
                  Verified Medicine Information
                </h3>
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {data.verifiedRecords.length} verified{' '}
                {data.verifiedRecords.length === 1 ? 'record' : 'records'}
              </span>
            </div>

            {data.verifiedRecords.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {data.verifiedRecords.map(renderMedicineCard)}
              </div>
            ) : (
              <div className="bg-white border border-slate-200 rounded-xl p-4 text-sm text-slate-600">
                {data.databaseConnected
                  ? `No verified entry found for "${data.query}" in the Medi_Bridge MedicineInfo collection. Check unverified database records and educational notes below, and consult a qualified doctor or registered pharmacist.`
                  : 'Connect MONGODB_URI in Settings > Secrets to query verified records from your Medi_Bridge MedicineInfo collection.'}
              </div>
            )}
          </section>

          {/* SECTION 2: UNVERIFIED MEDICINE INFORMATION */}
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <h3 className="text-base font-semibold text-slate-900">
                  Unverified Medicine &amp; Educational Information
                </h3>
              </div>
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {data.unverifiedRecords.length} database{' '}
                {data.unverifiedRecords.length === 1 ? 'entry' : 'entries'}
                {data.educationalInfo ? ' + educational reference' : ''}
              </span>
            </div>

            {data.unverifiedRecords.length > 0 && (
              <div className="grid grid-cols-1 gap-4">
                {data.unverifiedRecords.map(renderMedicineCard)}
              </div>
            )}

            {data.aiNotice && (
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs text-slate-700">
                {data.aiNotice}
              </div>
            )}

            {data.educationalInfo && (
              <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
                <div className="border-b border-slate-100 pb-4">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Unverified · Educational Reference Only
                    </span>
                    <span className="font-medium text-blue-700">
                      {data.educationalInfo.drugClass}
                    </span>
                  </div>
                  <h4 className="text-xl font-semibold text-slate-900 mt-2">
                    {data.educationalInfo.medicineName}
                  </h4>
                  <p className="text-sm text-slate-600 mt-1">
                    Active Ingredient(s):{' '}
                    <span className="font-medium text-slate-800">
                      {data.educationalInfo.activeIngredients}
                    </span>
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h5 className="text-sm font-semibold text-slate-900">Common Educational Uses</h5>
                    <ul className="list-disc list-inside text-sm text-slate-700 space-y-1.5">
                      {data.educationalInfo.generalUses.map((u, idx) => (
                        <li key={idx}>{u}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-sm font-semibold text-slate-900">
                      General Safety &amp; Handling Guidance
                    </h5>
                    <p className="text-sm text-slate-700 leading-relaxed">
                      {data.educationalInfo.safetyAndStorageNotes}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-sm font-semibold text-slate-900">Possible Side Effects</h5>
                    <ul className="list-disc list-inside text-sm text-slate-700 space-y-1.5">
                      {data.educationalInfo.commonSideEffects.map((s, idx) => (
                        <li key={idx}>{s}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-sm font-semibold text-slate-900">
                      General Precautions &amp; Warnings
                    </h5>
                    <ul className="list-disc list-inside text-sm text-slate-700 space-y-1.5">
                      {data.educationalInfo.importantPrecautions.map((p, idx) => (
                        <li key={idx}>{p}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="bg-red-50 border border-red-200 rounded-lg p-4 space-y-1.5">
                  <h5 className="text-xs font-semibold text-red-900">
                    When to Seek Urgent Medical Attention
                  </h5>
                  <ul className="list-disc list-inside text-xs text-red-800 space-y-1">
                    {data.educationalInfo.whenToSeekUrgentHelp.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>

                <p className="text-xs text-slate-600 pt-2 border-t border-slate-100">
                  {data.educationalInfo.disclaimer}
                </p>
              </div>
            )}

            {data.unverifiedRecords.length === 0 && !data.educationalInfo && !data.aiNotice && (
              <div className="bg-white border border-slate-200 rounded-xl p-4 text-sm text-slate-600">
                No unverified entries matched &ldquo;{data.query}&rdquo; in your database.
              </div>
            )}
          </section>
        </div>
      )}

      {!loading && !data && !error && (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-2">
          <Pill className="w-7 h-7 text-blue-600 mx-auto" />
          <p className="text-sm font-semibold text-slate-900">
            Search any medicine, generic, or brand name
          </p>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Review verified and unverified MedicineInfo records alongside general precautions and safety warnings. Always consult a qualified healthcare professional before taking medicines.
          </p>
        </div>
      )}
    </div>
  );
};
