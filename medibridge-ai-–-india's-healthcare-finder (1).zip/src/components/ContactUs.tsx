import React, { useState } from 'react';
import { CheckCircle2, Mail, PhoneCall, Send, ShieldAlert } from 'lucide-react';
import { apiFetchJson } from '../utils/apiClient';

export const ContactUs: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedRef, setSubmittedRef] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmittedRef(null);
    setSubmitting(true);
    try {
      const json = await apiFetchJson<{ id?: string }>(
        '/api/contact',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, subject, message }),
        },
        'Unable to send your message.'
      );
      setSubmittedRef(json.id || 'Recorded');
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to send your message.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2 text-blue-700 text-xs font-semibold">
            <Mail className="w-4 h-4" />
            <span>Contact MediBridge AI</span>
          </div>
          <h2 className="text-lg font-semibold text-slate-900 mt-1">
            Report Directory Updates or General Support
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            Share corrections for hospital contact details, official source links, or platform feedback.
          </p>
        </div>

        {submittedRef && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start gap-2.5 text-sm text-emerald-950">
            <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Message Received</p>
              <p className="text-xs text-emerald-800 mt-0.5 font-mono tabular-nums">
                Reference ID: {submittedRef}
              </p>
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 text-sm text-red-800">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Full Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                minLength={2}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your full name"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Email Address <span className="text-red-600">*</span>
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Subject <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              required
              minLength={3}
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g., Hospital record update or feedback"
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Message <span className="text-red-600">*</span>
            </label>
            <textarea
              rows={4}
              required
              minLength={10}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Describe your inquiry or official hospital directory update..."
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-50 rounded-lg cursor-pointer"
          >
            <Send className="w-4 h-4" />
            {submitting ? 'Sending Message...' : 'Send Message'}
          </button>
        </form>
      </section>

      <section className="lg:col-span-5 space-y-4">
        <div className="bg-red-50 border border-red-200 rounded-xl p-5 space-y-2">
          <div className="flex items-center gap-2 text-red-800 font-semibold text-sm">
            <ShieldAlert className="w-5 h-5" />
            <span>Do Not Use This Form for Medical Emergencies</span>
          </div>
          <p className="text-xs text-red-900 leading-relaxed">
            This contact form is for non-urgent platform support and directory updates only. If someone requires urgent medical care, call <strong>112</strong> or <strong>108</strong> immediately.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-blue-700 font-semibold text-sm">
            <PhoneCall className="w-4 h-4" />
            <span>Public Indian Helplines</span>
          </div>
          <ul className="space-y-2 text-xs text-slate-700 font-mono tabular-nums">
            <li className="flex justify-between py-1.5 border-b border-slate-100">
              <span>National Emergency</span>
              <strong className="text-red-700">112</strong>
            </li>
            <li className="flex justify-between py-1.5 border-b border-slate-100">
              <span>Ambulance Service</span>
              <strong>108 / 102</strong>
            </li>
            <li className="flex justify-between py-1.5">
              <span>State Health Helpline</span>
              <strong>104</strong>
            </li>
          </ul>
        </div>
      </section>
    </div>
  );
};
